﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

public class ClsExtensoValor
{
    /// <summary>
    /// Função para escrever por extenso os valores em Real (em C# - suporta até R$ 9.999.999.999,99) 
    /// Rotina Criada para ler um número e transformá-lo em extenso 
    /// Limite máximo de 9 Bilhões (9.999.999.999,99).
    /// Não aceita números negativos.
    /// </summary>
    /// <param name="pdbl_Valor">Valor para converter em extenso. Limite máximo de 9 Bilhões (9.999.999.999,99).</param>
    /// <returns>String do valor por Extenso</returns>
    public string Extenso_Valor(decimal number)
    {
        int cent = 0;
            try
            {
                // se for =0 retorna 0 eros
                if (number == 0)
                {
                    return "Nenhuma Saca";
                }
                // Verifica a parte decimal, ou seja, os cêntimos
                cent = Convert.ToInt32(decimal.Round((number - (int)number) * 100, MidpointRounding.ToEven));
                // Verifica apenas a parte inteira
                //number = Convert.ToInt32(number);
                number = (int)number;
                // Caso existam cêntimos
                if (cent > 0)
                {
                    // Caso seja 1 não coloca "euros" mas sim "euro"
                    if (number == 1)
                    {
                        return "Uma Saca " + getDecimal(Convert.ToByte(cent));
                    }
                    // Caso o valor seja inferior a 1 euro
                    else if (number == 0)
                    {
                        return getDecimal(Convert.ToByte(cent));
                    }
                    else
                    {
                        return getInteger(number) + "Sacas ";
                    }
                }
                else
                {
                    // Caso seja 1 não coloca "euros" mas sim "euro"
                    if (number == 1)
                    {
                        return "Uma Saca";
                    }
                    else
                    {
                        return getInteger(number) + "Sacas";
                    }
                }
            }
            catch (Exception ex)
            {
                return "";
            }
        }

        public string getDecimal(byte number)
        {
            try
            {
                Convert.ToInt32(number);

                if (number == 0)
                {
                    return "";
                }

                if (number >= 1 && number <= 19)
                {
                    string[] strArray = {"Uma", "Duas", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", "Dez", 
                "Onze", "Doze", "Treze", "Quatorze", "Quinze", "Dezasseis", "Dezassete", "Dezoito", "Dezanove"};

                    return strArray[number - 1] + " ";
                }

                if (number >= 20 && number <= 99)
                {
                    string[] strArray = { "Vinte", "Trinta", "Quarenta", "Cinquenta", "Sessenta", "Setenta", "Oitenta", "Noventa" };

                    if ((number % 10) == 0)
                    {
                        return strArray[number / 10 - 2] + " ";
                    }
                    else
                    {
                        return strArray[number / 10 - 2] + " e " + getDecimal(Convert.ToByte(number % 10)) + " ";
                    }
                }

                else
                {
                    return "";
                }
            }

            catch (Exception ex)
            {
                return "";
            }
        }


        public string getInteger(decimal number)
        {

            try
            {
                number = (int)number;

                if (number < 0)
                {
                    return "-" + getInteger(-number);
                }

                if (number == 0)
                {
                    return "";
                }

                if (number >= 1 && number <= 19)
                {
                    string[] strArray = { "Uma", "Duas", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", "Dez", 
            "Onze", "Doze", "Treze", "Quatorze", "Quinze", "Dezasseis", "Dezassete", "Dezoito", "Dezanove" };

                    return strArray[Convert.ToInt32(number) - 1] + " ";
                }

                if (number >= 20 && number <= 99)
                {
                    string[] strArray = { "Vinte", "Trinta", "Quarenta", "Cinquenta", "Sessenta", "Setenta", "Oitenta", "Noventa" };

                    if ((number % 10) == 0)
                    {
                        return strArray[Convert.ToInt32(number) / 10 - 2] + " ";
                    }
                    else
                    {
                        return strArray[Convert.ToInt32(number) / 10 - 2] + " e " + getInteger(number % 10) + " ";
                    }
                }

                if (number == 100)
                {
                    return "Cem ";
                }

                if (number >= 101 && number <= 999)
                {
                    string[] strArray = { "Centa", "Duzentas", "Trezentas", "Quatrocentas", "Quinhentas", "Seiscentas", "Setecentas", "Oitocentas", "Novecentas" };

                    if ((number % 100) == 0)
                    {
                        return strArray[Convert.ToInt32(number) / 100 - 1] + " ";
                    }
                    else
                    {
                        return strArray[Convert.ToInt32(number) / 100 - 1] + " e " + getInteger(number % 100) + " ";
                    }
                }

                if (number >= 1000 && number <= 1999)
                {
                    int resto = Convert.ToInt32(number) % 1000;

                    if (resto == 0)
                    {
                        return "Mil ";
                    }
                    else
                    {
                        if (resto <= 100)
                        {
                            return "Mil e " + getInteger(number % 1000);
                        }

                        else
                        {
                            return "Mil " + getInteger(number % 1000);
                        }
                    }
                }


                if (number >= 2000 && number <= 999999)
                {
                    int resto = Convert.ToInt32(number) % 1000;

                    if (resto == 0)
                    {
                        return getInteger(number / 1000) + "Mil ";
                    }
                    else
                    {
                        if (resto <= 100)
                        {
                            return getInteger(number / 1000) + "Mil e " + getInteger(number % 1000);
                        }

                        else
                        {
                            return getInteger(number / 1000) + "Mil " + getInteger(number % 1000);
                        }
                    }
                }


                if (number >= 1000000 && number <= 1999999)
                {
                    int resto = Convert.ToInt32(number) % 1000000;

                    if (resto == 0)
                    {
                        return "Um Milhão ";
                    }
                    else
                    {
                        if (resto <= 100)
                        {
                            return getInteger(number / 1000000) + "Milhão e " + getInteger(number % 1000000);
                        }

                        else
                        {
                            return getInteger(number / 1000000) + "Milhão, " + getInteger(number % 1000000);
                        }
                    }
                }


                if (number >= 2000000 && number <= 999999999)
                {
                    int resto = Convert.ToInt32(number) % 1000000;

                    if (resto == 0)
                    {
                        return getInteger(number / 1000000) + " Milhões ";
                    }
                    else
                    {
                        if (resto <= 100)
                        {
                            return getInteger(number / 1000000) + "Milhões e " + getInteger(number % 1000000);
                        }

                        else
                        {
                            return getInteger(number / 1000000) + "Milhões, " + getInteger(number % 1000000);
                        }
                    }
                }

                if (number >= 1000000000 && number <= 1999999999)
                {
                    int resto = Convert.ToInt32(number) % 1000000000;

                    if (resto == 0)
                    {
                        return "Um Bilhão ";
                    }
                    else
                    {
                        if (resto <= 100)
                        {
                            return getInteger(number / 1000000000) + "Bilhão e " + getInteger(number % 1000000000);
                        }

                        else
                        {
                            return getInteger(number / 1000000000) + "Bilhão, " + getInteger(number % 1000000000);
                        }
                    }
                }


                else
                {
                    int resto = Convert.ToInt32(number) % 1000000000;

                    if (resto == 0)
                    {
                        return getInteger(number / 1000000000) + " Bilhões ";
                    }
                    else
                    {
                        if (resto <= 100)
                        {
                            return getInteger(number / 1000000000) + "Bilhões e " + getInteger(number % 1000000000);
                        }

                        else
                        {
                            return getInteger(number / 1000000000) + "Bilhões, " + getInteger(number % 1000000000);
                        }
                    }
                }

            }

            catch (Exception ex)
            {
                return "";
            }
        }

    }
