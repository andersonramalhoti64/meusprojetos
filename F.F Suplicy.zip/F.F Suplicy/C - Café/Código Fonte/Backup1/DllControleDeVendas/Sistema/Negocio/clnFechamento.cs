﻿using System;
using System.Collections.Generic;
using System.Text;
using DllControleDeVendas.Sistema.Globais;
using System.Data;
using System.Data.OleDb;

namespace DllControleDeVendas.Sistema.Negocio
{
    public class clnFechamento
    {
        private string _fechamento;
        private int _comprador;
        private int _vendendor;
        private int _armazen;
        private int _descarga;
        private double _preco;
        private DateTime _data;
        private int _qtSacos;
        private string _composicao;
        private string _modalidade;
        private string _ufprodutor;
        private string _condpagamento;
        private double _corretcomprador;
        private double _corretvendedor;
        private string _observacoes1;
        private string _obs1;
        private string _obs2;
        private string _obs3;
        private string _observacoes2;
        private string _tipoCafe;
        private string _corretor;
        private string _sacaria;
        private string _descricao;
        private string _matr;
        private string _preco_extenso;
        private string _sacas_extenso;

        public virtual string obs1
        {
            get { return _obs1; }
            set { _obs1 = value;}
        }
        public virtual string obs2
        {
            get { return _obs2; }
            set { _obs2= value; }
        }
        public virtual string obs3
        {
            get { return _obs3; }
            set { _obs3 = value; }
        }
        public virtual string fechamento
        {
            get
            {
                return this._fechamento;
            }
            set
            {
                this._fechamento = value;
            }
        }

        public virtual int comprador
        {
            get
            {
                return this._comprador;
            }
            set
            {
                this._comprador = value;
            }
        }

        public virtual int vendendor
        {
            get
            {
                return this._vendendor;
            }
            set
            {
                this._vendendor = value;
            }
        }

        public virtual int armazen
        {
            get
            {
                return this._armazen;
            }
            set
            {
                this._armazen = value;
            }
        }

        public virtual double preco
        {
            get
            {
                return this._preco;
            }
            set
            {
                this._preco = value;
            }
        }
        public virtual int descarga
        {
            get
            {
                return this._descarga;
            }
            set
            {
                this._descarga = value;
            }
        }
        public virtual DateTime data
        {
            get
            {
                return this._data;
            }
            set
            {
                this._data = value;
            }
        }

        public virtual int qtSacos
        {
            get
            {
                return this._qtSacos;
            }
            set
            {
                this._qtSacos = value;
            }
        }

        public virtual string composicao
        {
            get
            {
                return this._composicao;
            }
            set
            {
                this._composicao = value;
            }
        }

        public virtual string modalidade
        {
            get
            {
                return this._modalidade;
            }
            set
            {
                this._modalidade = value;
            }
        }

        public virtual string ufprodutor
        {
            get
            {
                return this._ufprodutor;
            }
            set
            {
                this._ufprodutor = value;
            }
        }

        public virtual string condpagamento
        {
            get
            {
                return this._condpagamento;
            }
            set
            {
                this._condpagamento = value;
            }
        }

        public virtual double corretcomprador
        {
            get
            {
                return this._corretcomprador;
            }
            set
            {
                this._corretcomprador = value;
            }
        }

        public virtual double corretvendedor
        {
            get
            {
                return this._corretvendedor;
            }
            set
            {
                this._corretvendedor = value;
            }
        }

        public virtual string observacoes1
        {
            get
            {
                return this._observacoes1;
            }
            set
            {
                this._observacoes1 = value;
            }
        }

        public virtual string observacoes2
        {
            get
            {
                return this._observacoes2;
            }
            set
            {
                this._observacoes2 = value;
            }
        }

        public virtual string tipoCafe
        {
            get
            {
                return this._tipoCafe;
            }
            set
            {
                this._tipoCafe = value;
            }
        }

        public virtual string corretor
        {
            get
            {
                return this._corretor;
            }
            set
            {
                this._corretor = value;
            }
        }

        public virtual string sacaria
        {
            get
            {
                return this._sacaria;
            }
            set
            {
                this._sacaria = value;
            }
        }

        public virtual string descricao
        {
            get
            {
                return this._descricao;
            }
            set
            {
                this._descricao = value;
            }
        }

        public virtual string matr
        {
            get
            {
                return this._matr;
            }
            set
            {
                this._matr = value;
            }
        }

        public virtual string preco_extenso
        {
            get
            {
                return this._preco_extenso;
            }
            set
            {
                this._preco_extenso = value;
            }
        }

        public virtual string sacas_extenso
        {
            get
            {
                return this._sacas_extenso;
            }
            set
            {
                this._sacas_extenso = value;
            }
        }
        public void Gravar()
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" INSERT INTO fechamentos ");
            strQuery.Append(" ( ");
            strQuery.Append(" fechamento ");
            strQuery.Append(", comprador ");
            strQuery.Append(", vendendor ");
            strQuery.Append(", armazen ");
            strQuery.Append(", descarga ");
            strQuery.Append(", preco ");
            strQuery.Append(", data ");
            strQuery.Append(", qtsacos ");
            strQuery.Append(", composicao ");
            strQuery.Append(", modalidade ");
            strQuery.Append(", ufprodutor ");
            strQuery.Append(", condpagamento ");
            strQuery.Append(", corretcomprador ");
            strQuery.Append(", corretvendedor ");
            strQuery.Append(", observacoes1 ");
            strQuery.Append(", observacoes2 ");
            strQuery.Append(", tipoCafe");
            strQuery.Append(", corretor");
            strQuery.Append(", sacaria");
            strQuery.Append(", descricao");
            strQuery.Append(", matr");
            strQuery.Append(", preco_extenso");
            strQuery.Append(", sacas_extenso");
            strQuery.Append(" ) ");
            strQuery.Append(" VALUES ( ");
            strQuery.Append(" '" + _fechamento + "' ");
            strQuery.Append(", " + _comprador + " ");
            strQuery.Append(", " + _vendendor + " ");
            strQuery.Append(", " + _armazen + " ");
            strQuery.Append(", " + _descarga + " ");
            strQuery.Append(", '" + _preco + "' ");
            strQuery.Append(", '" + _data.ToShortDateString() + "' ");
            strQuery.Append(", " + _qtSacos + " ");
            strQuery.Append(", '" + _composicao + "' ");
            strQuery.Append(", '" + _modalidade + "' ");
            strQuery.Append(", '" + _ufprodutor + "' ");
            strQuery.Append(", '" + _condpagamento + "' ");
            strQuery.Append(", '" + _corretcomprador + "' ");
            strQuery.Append(", '" + _corretvendedor + "' ");
            strQuery.Append(", '" + _observacoes1 + "' ");
            strQuery.Append(", '" + _observacoes2 + "' ");
            strQuery.Append(", '" + _tipoCafe + "' ");
            strQuery.Append(", " + _corretor + " ");
            strQuery.Append(", '" + _sacaria + "' ");
            strQuery.Append(", '" + _descricao + "' ");
            strQuery.Append(", " + _matr + " ");
            strQuery.Append(", '" + _preco_extenso + "' ");
            strQuery.Append(", '" + _sacas_extenso + "' ");
            strQuery.Append(" ); ");
            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public void Alterar()
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" UPDATE fechamentos ");
            strQuery.Append(" SET ");
            strQuery.Append("comprador = '" + _comprador + "' ");
            strQuery.Append(",vendendor = '" + _vendendor + "' ");
            strQuery.Append(",armazen = '" + _armazen + "' ");
            strQuery.Append(",descarga = '" + _descarga + "' ");
            strQuery.Append(",preco = '" + _preco + "' ");
            strQuery.Append(",data = '" + _data.ToShortDateString() + "' ");
            strQuery.Append(",qtSacos ='" + _qtSacos + "' ");
            strQuery.Append(",composicao = '" + _composicao + "' ");
            strQuery.Append(",modalidade = '" + _modalidade + "' ");
            strQuery.Append(",ufprodutor = '" + _ufprodutor + "' ");
            strQuery.Append(",condpagamento = '" + _condpagamento + "' ");
            strQuery.Append(",corretcomprador = '" + _corretcomprador + "' ");
            strQuery.Append(",corretvendedor = '" + _corretvendedor + "' ");
            strQuery.Append(",observacoes1 = '" + _observacoes1 + "' ");
            strQuery.Append(",observacoes2 = '" + _observacoes2 + "' ");
            strQuery.Append(",tipoCafe = '" + _tipoCafe + "' ");
            strQuery.Append(",corretor = " + _corretor + " ");
            strQuery.Append(",sacaria = '" + _sacaria + "' ");
            strQuery.Append(",descricao = '" + _descricao + "' ");
            strQuery.Append(",matr = '" + _matr + "' ");
            strQuery.Append(",preco_extenso = '" + _preco_extenso + "' ");
            strQuery.Append(",sacas_extenso = '" + _sacas_extenso + "' ");
            strQuery.Append(" WHERE ");
            strQuery.Append(" fechamento = '" + fechamento + "' ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public DataSet Listar(string strDescricao)
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" SELECT fechamento as Fechamento, data as Data, qtSacos as Sacas, preco as Preço, sacaria as Sacaria ");
            strQuery.Append(" FROM fechamentos ");

            if (!(strDescricao.Equals(string.Empty)))
            {
                strQuery.Append(" WHERE fechamento like '%" + strDescricao + "%' " + "ORDER BY fechamento DESC");
            }

            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataSet(strQuery.ToString());
        }

        public void Excluir(string Nfechamento)
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" DELETE FROM fechamentos ");
            strQuery.Append(" WHERE fechamento = '" + Nfechamento + "'");

            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public OleDbDataReader ListarCliente(string Nfechamento)
        {

            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" SELECT comprador,vendendor,armazen,descarga,preco,data,qtSacos,composicao,modalidade,ufprodutor,condpagamento,corretcomprador,corretvendedor,observacoes1,observacoes2,tipoCafe,corretor,sacaria,descricao,matr,sacas_extenso,preco_extenso");
            strQuery.Append(" FROM fechamentos ");
            strQuery.Append(" WHERE fechamento = '" + Nfechamento + "' ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataReader(strQuery.ToString());
        }
        public OleDbDataReader ListarComprador(string cli_ID)
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append("SELECT cli_NomeRazao ");
            strQuery.Append("FROM clientes ");
            strQuery.Append(" WHERE cli_Id Like " + cli_ID + " ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataReader(strQuery.ToString());
        }
        public OleDbDataReader ListarVendedor(string cli_ID)
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append("SELECT cli_NomeRazao ");
            strQuery.Append("FROM clientes ");
            strQuery.Append(" WHERE cli_Id Like " + cli_ID + " ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataReader(strQuery.ToString());
        }

        public OleDbDataReader ListarArmazen(string cli_ID)
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append("SELECT cli_NomeRazao ");
            strQuery.Append("FROM clientes ");
            strQuery.Append(" WHERE cli_Id Like " + cli_ID + " ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataReader(strQuery.ToString());
        }
        public OleDbDataReader ListarDescarga(string cli_ID)
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append("SELECT cli_NomeRazao ");
            strQuery.Append("FROM clientes ");
            strQuery.Append(" WHERE cli_Id Like " + cli_ID + " ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataReader(strQuery.ToString());
        }

        
    }
}
