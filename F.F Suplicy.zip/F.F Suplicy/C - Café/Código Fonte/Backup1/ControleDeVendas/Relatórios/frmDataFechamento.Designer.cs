﻿namespace ControleDeVendas.Relatórios
{
    partial class frmDataFechamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reportDataFech = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // reportDataFech
            // 
            this.reportDataFech.ActiveViewIndex = -1;
            this.reportDataFech.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.reportDataFech.DisplayGroupTree = false;
            this.reportDataFech.DisplayStatusBar = false;
            this.reportDataFech.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportDataFech.Location = new System.Drawing.Point(0, 0);
            this.reportDataFech.Name = "reportDataFech";
            this.reportDataFech.SelectionFormula = "";
            this.reportDataFech.ShowGroupTreeButton = false;
            this.reportDataFech.ShowRefreshButton = false;
            this.reportDataFech.Size = new System.Drawing.Size(496, 424);
            this.reportDataFech.TabIndex = 0;
            this.reportDataFech.ViewTimeSelectionFormula = "";
            // 
            // frmDataFechamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 424);
            this.Controls.Add(this.reportDataFech);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDataFechamento";
            this.ShowIcon = false;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmDataFechamento_Load);
            this.ResumeLayout(false);

        }

        #endregion

        public CrystalDecisions.Windows.Forms.CrystalReportViewer reportDataFech;
    }
}