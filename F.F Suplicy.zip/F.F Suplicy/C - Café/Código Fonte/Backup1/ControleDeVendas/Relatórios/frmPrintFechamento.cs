﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ControleDeVendas.Formulários.Cadastros.Fechamentos;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace ControleDeVendas.Relatórios
{
    public partial class frmPrintFechamento : ControleDeVendas.Formulários.Modelos.frmModelo
    {
        frmCadastroFechamento _frmPai;
        public frmPrintFechamento()
        {
            InitializeComponent();
        }
        public frmPrintFechamento(frmCadastroFechamento frmPai)
        {
            InitializeComponent();
            this._frmPai = frmPai;
        }

        private void frmPrintFechamento_Load(object sender, EventArgs e)
        {
            ReportDocument doc = new ReportDocument();
            doc.Load(@"I:\fechamento.rpt");

            ParameterField param;
            param = doc.ParameterFields["fechamento"];
            param.CurrentValues.AddValue(_frmPai.textoFechamento.Text);

            reportFechamento.ReportSource = doc;


        }

        private void reportFechamento_Load(object sender, EventArgs e)
        {

        }
    }
}
