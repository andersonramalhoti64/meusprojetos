﻿namespace ControleDeVendas.Relatórios
{
    partial class frmPrintFechamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reportFechamento = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.errErro)).BeginInit();
            this.SuspendLayout();
            // 
            // reportFechamento
            // 
            this.reportFechamento.ActiveViewIndex = -1;
            this.reportFechamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.reportFechamento.DisplayGroupTree = false;
            this.reportFechamento.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportFechamento.Location = new System.Drawing.Point(0, 0);
            this.reportFechamento.Name = "reportFechamento";
            this.reportFechamento.SelectionFormula = "";
            this.reportFechamento.ShowCloseButton = false;
            this.reportFechamento.ShowGroupTreeButton = false;
            this.reportFechamento.ShowRefreshButton = false;
            this.reportFechamento.Size = new System.Drawing.Size(567, 452);
            this.reportFechamento.TabIndex = 0;
            this.reportFechamento.ViewTimeSelectionFormula = "";
            this.reportFechamento.Load += new System.EventHandler(this.reportFechamento_Load);
            // 
            // frmPrintFechamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.ClientSize = new System.Drawing.Size(567, 452);
            this.Controls.Add(this.reportFechamento);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPrintFechamento";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmPrintFechamento_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errErro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer reportFechamento;
    }
}
