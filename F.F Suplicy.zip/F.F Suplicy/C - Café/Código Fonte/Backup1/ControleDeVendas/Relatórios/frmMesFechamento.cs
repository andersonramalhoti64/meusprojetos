﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.Shared;
using CrystalDecisions.CrystalReports.Engine;
using ControleDeVendas.Relatórios;

namespace ControleDeVendas.Relatórios
{
    public partial class frmMesFechamento : Form
    {
        public frmMesFechamento()
        {
            InitializeComponent();
        }

        private void frmMesFechamento_Load(object sender, EventArgs e)
        {
        }

        private void btnSelecionar_Click(object sender, EventArgs e)
        {
            
        }

        private void btnVisualizar_Click(object sender, EventArgs e)
        {
            if (dtInicial.Value > dtFinal.Value)
            {
                MessageBox.Show("A Data Inicial Não pode ser maior do que a final", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                try
                {
                    frmDataFechamento frmData = new frmDataFechamento();
                    ReportDocument doc = new ReportDocument();
                    doc.Load(@"I:\Mesfechamento.rpt");

                    ParameterField DataInicial, DataFinal;
                    DataInicial = doc.ParameterFields["DataInicial"];
                    DataFinal = doc.ParameterFields["DataFinal"];

                    DataInicial.CurrentValues.AddValue(dtInicial.Text);
                    DataFinal.CurrentValues.AddValue(dtFinal.Text);

                    frmData.reportDataFech.ReportSource = doc;

                    frmData.Show();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocorreu o seguinte erro imprimir: " + ex.Message);
                }
            }

        }
    }
}
