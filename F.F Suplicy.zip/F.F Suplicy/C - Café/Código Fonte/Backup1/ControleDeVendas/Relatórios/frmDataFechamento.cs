﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace ControleDeVendas.Relatórios
{
    public partial class frmDataFechamento : Form
    {
        public frmDataFechamento()
        {
            InitializeComponent();
        }

        private void frmDataFechamento_Load(object sender, EventArgs e)
        {

        }
    }
}
