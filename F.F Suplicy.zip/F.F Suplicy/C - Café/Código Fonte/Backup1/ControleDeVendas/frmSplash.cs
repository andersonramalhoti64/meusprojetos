﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControleDeVendas
{
    public partial class frmSplash : Form
    {
        private bool increase = true;

        public frmSplash()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void frmSplash_Load(object sender, EventArgs e)
        {
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();

            ControleDeVendas.Formulários.Sistema.frmMenu mnu = new ControleDeVendas.Formulários.Sistema.frmMenu();
            mnu.Show();
        }
    }
}
