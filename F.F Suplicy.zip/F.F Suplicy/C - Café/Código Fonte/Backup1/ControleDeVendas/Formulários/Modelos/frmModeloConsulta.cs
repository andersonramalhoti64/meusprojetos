using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControleDeVendas.Formul�rios.Modelos
{
    public partial class frmModeloConsulta : ControleDeVendas.Formul�rios.Modelos.frmModelo
    {
        public frmModeloConsulta()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {

        }

    }
}

