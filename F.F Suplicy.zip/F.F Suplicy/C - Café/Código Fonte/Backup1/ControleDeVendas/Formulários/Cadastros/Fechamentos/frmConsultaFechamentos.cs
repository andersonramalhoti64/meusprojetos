﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Globais;
using DllControleDeVendas.Sistema.Negocio;
using ControleDeVendas.Formulários.Cadastros.Fechamentos;
using ControleDeVendas.Relatórios;

namespace ControleDeVendas.Formulários.Cadastros.Fechamentos
{
    public partial class frmConsultaFechamentos : ControleDeVendas.Formulários.Modelos.frmModeloConsulta
    {
        public DataGridView dgvp
        {
            get { return dgdGrid; }
        }
        public frmConsultaFechamentos()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void frmConsultaFechamentos_Load(object sender, EventArgs e)
        {
            CarregaGrid();
        }
        private void CarregaGrid()
        {
            clnFechamento fechamento = new clnFechamento();
            dgdGrid.DataSource = fechamento.Listar(txtDescricao.Text).Tables[0];

            dgdGrid.Columns[0].Width = 78;
            dgdGrid.Columns[1].Width = 75;
            dgdGrid.Columns[2].Width = 70;
            dgdGrid.Columns[3].Width = 70;

        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            CarregaGrid();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            frmCadastroFechamento cadfech = new frmCadastroFechamento(this);
            cadfech.Operacao = clnFuncoesGerais.Operacao.Inclusao;
            cadfech.DataAtual.Text = DateTime.Now.ToShortDateString();
            cadfech.ShowDialog();
            CarregaGrid();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show("Deseja excluir o registro?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No))
            {
                return;
            }
            clnFechamento cldfechamento = new clnFechamento();
            cldfechamento.Excluir(dgdGrid.CurrentRow.Cells[0].Value.ToString());

            MessageBox.Show("Registro excluído com sucesso", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            CarregaGrid();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            frmCadastroFechamento frmCliente = new frmCadastroFechamento();
            frmCliente.Operacao = clnFuncoesGerais.Operacao.Alteracao;
            
            
            frmCliente.fechamento = dgdGrid.CurrentRow.Cells[0].Value.ToString();
            frmCliente.ShowDialog();
            CarregaGrid();
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
