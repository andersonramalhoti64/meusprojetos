namespace ControleDeVendas.Formul�rios.Cadastros.Cliente
{
    partial class frmClienteCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpDadosCliente = new System.Windows.Forms.GroupBox();
            this.txtCod = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCpfCnpj = new System.Windows.Forms.TextBox();
            this.lblCpfCnpj = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.grbEndereco = new System.Windows.Forms.GroupBox();
            this.txtBanco = new System.Windows.Forms.TextBox();
            this.txtInscEstadual = new System.Windows.Forms.TextBox();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.lblTelefones = new System.Windows.Forms.Label();
            this.txtCep = new System.Windows.Forms.TextBox();
            this.lblCep = new System.Windows.Forms.Label();
            this.cboUf = new System.Windows.Forms.ComboBox();
            this.lblUf = new System.Windows.Forms.Label();
            this.txtCidade = new System.Windows.Forms.TextBox();
            this.lblCidade = new System.Windows.Forms.Label();
            this.txtInd = new System.Windows.Forms.TextBox();
            this.lblBairro = new System.Windows.Forms.Label();
            this.txtLogradouro = new System.Windows.Forms.TextBox();
            this.lblLogradouro = new System.Windows.Forms.Label();
            this.grpCampos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errErro)).BeginInit();
            this.grpDadosCliente.SuspendLayout();
            this.grbEndereco.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpCampos
            // 
            this.grpCampos.Controls.Add(this.grbEndereco);
            this.grpCampos.Controls.Add(this.grpDadosCliente);
            this.grpCampos.Size = new System.Drawing.Size(504, 366);
            // 
            // btnSair
            // 
            this.btnSair.Image = global::ControleDeVendas.Properties.Resources.Edit_UndoHS1;
            this.btnSair.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSair.Location = new System.Drawing.Point(353, 384);
            this.btnSair.Size = new System.Drawing.Size(75, 35);
            this.btnSair.TabIndex = 1;
            this.btnSair.Text = "Sair - Esc";
            this.btnSair.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnNovo
            // 
            this.btnNovo.Image = global::ControleDeVendas.Properties.Resources.RecordHS;
            this.btnNovo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnNovo.Location = new System.Drawing.Point(434, 384);
            this.btnNovo.Size = new System.Drawing.Size(82, 35);
            this.btnNovo.TabIndex = 2;
            this.btnNovo.Text = "Gravar - F3";
            this.btnNovo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // grpDadosCliente
            // 
            this.grpDadosCliente.Controls.Add(this.txtCod);
            this.grpDadosCliente.Controls.Add(this.label4);
            this.grpDadosCliente.Controls.Add(this.txtCpfCnpj);
            this.grpDadosCliente.Controls.Add(this.lblCpfCnpj);
            this.grpDadosCliente.Controls.Add(this.txtNome);
            this.grpDadosCliente.Controls.Add(this.lblNome);
            this.grpDadosCliente.Location = new System.Drawing.Point(5, 18);
            this.grpDadosCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpDadosCliente.Name = "grpDadosCliente";
            this.grpDadosCliente.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpDadosCliente.Size = new System.Drawing.Size(492, 87);
            this.grpDadosCliente.TabIndex = 0;
            this.grpDadosCliente.TabStop = false;
            this.grpDadosCliente.Text = "Dados do cliente";
            // 
            // txtCod
            // 
            this.txtCod.Location = new System.Drawing.Point(76, 13);
            this.txtCod.Name = "txtCod";
            this.txtCod.Size = new System.Drawing.Size(57, 21);
            this.txtCod.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Cod:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtCpfCnpj
            // 
            this.txtCpfCnpj.Location = new System.Drawing.Point(76, 62);
            this.txtCpfCnpj.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCpfCnpj.MaxLength = 20;
            this.txtCpfCnpj.Name = "txtCpfCnpj";
            this.txtCpfCnpj.Size = new System.Drawing.Size(123, 21);
            this.txtCpfCnpj.TabIndex = 5;
            // 
            // lblCpfCnpj
            // 
            this.lblCpfCnpj.AutoSize = true;
            this.lblCpfCnpj.Location = new System.Drawing.Point(9, 65);
            this.lblCpfCnpj.Name = "lblCpfCnpj";
            this.lblCpfCnpj.Size = new System.Drawing.Size(68, 13);
            this.lblCpfCnpj.TabIndex = 4;
            this.lblCpfCnpj.Text = "CPF/CNPJ:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(76, 37);
            this.txtNome.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNome.MaxLength = 80;
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(295, 21);
            this.txtNome.TabIndex = 3;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(32, 40);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(45, 13);
            this.lblNome.TabIndex = 2;
            this.lblNome.Text = "Nome:";
            // 
            // grbEndereco
            // 
            this.grbEndereco.Controls.Add(this.txtBanco);
            this.grbEndereco.Controls.Add(this.txtInscEstadual);
            this.grbEndereco.Controls.Add(this.txtObs);
            this.grbEndereco.Controls.Add(this.label3);
            this.grbEndereco.Controls.Add(this.label2);
            this.grbEndereco.Controls.Add(this.label1);
            this.grbEndereco.Controls.Add(this.txtFax);
            this.grbEndereco.Controls.Add(this.lblEmail);
            this.grbEndereco.Controls.Add(this.txtTelefone);
            this.grbEndereco.Controls.Add(this.lblTelefones);
            this.grbEndereco.Controls.Add(this.txtCep);
            this.grbEndereco.Controls.Add(this.lblCep);
            this.grbEndereco.Controls.Add(this.cboUf);
            this.grbEndereco.Controls.Add(this.lblUf);
            this.grbEndereco.Controls.Add(this.txtCidade);
            this.grbEndereco.Controls.Add(this.lblCidade);
            this.grbEndereco.Controls.Add(this.txtInd);
            this.grbEndereco.Controls.Add(this.lblBairro);
            this.grbEndereco.Controls.Add(this.txtLogradouro);
            this.grbEndereco.Controls.Add(this.lblLogradouro);
            this.grbEndereco.Location = new System.Drawing.Point(5, 109);
            this.grbEndereco.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grbEndereco.Name = "grbEndereco";
            this.grbEndereco.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grbEndereco.Size = new System.Drawing.Size(492, 252);
            this.grbEndereco.TabIndex = 1;
            this.grbEndereco.TabStop = false;
            this.grbEndereco.Text = "Dados do cliente";
            // 
            // txtBanco
            // 
            this.txtBanco.Location = new System.Drawing.Point(87, 156);
            this.txtBanco.Name = "txtBanco";
            this.txtBanco.Size = new System.Drawing.Size(353, 21);
            this.txtBanco.TabIndex = 15;
            // 
            // txtInscEstadual
            // 
            this.txtInscEstadual.Location = new System.Drawing.Point(97, 178);
            this.txtInscEstadual.Name = "txtInscEstadual";
            this.txtInscEstadual.Size = new System.Drawing.Size(343, 21);
            this.txtInscEstadual.TabIndex = 17;
            // 
            // txtObs
            // 
            this.txtObs.Location = new System.Drawing.Point(97, 199);
            this.txtObs.Multiline = true;
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(376, 48);
            this.txtObs.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Insc. Estadual: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 202);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Obs:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 159);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Banco:";
            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(87, 110);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(284, 21);
            this.txtFax.TabIndex = 11;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(49, 113);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(32, 13);
            this.lblEmail.TabIndex = 10;
            this.lblEmail.Text = "Fax:";
            this.lblEmail.Click += new System.EventHandler(this.lblEmail_Click);
            // 
            // txtTelefone
            // 
            this.txtTelefone.Location = new System.Drawing.Point(87, 87);
            this.txtTelefone.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTelefone.MaxLength = 50;
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(284, 21);
            this.txtTelefone.TabIndex = 9;
            // 
            // lblTelefones
            // 
            this.lblTelefones.AutoSize = true;
            this.lblTelefones.Location = new System.Drawing.Point(15, 90);
            this.lblTelefones.Name = "lblTelefones";
            this.lblTelefones.Size = new System.Drawing.Size(67, 13);
            this.lblTelefones.TabIndex = 8;
            this.lblTelefones.Text = "Telefones:";
            // 
            // txtCep
            // 
            this.txtCep.Location = new System.Drawing.Point(291, 65);
            this.txtCep.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCep.MaxLength = 8;
            this.txtCep.Name = "txtCep";
            this.txtCep.Size = new System.Drawing.Size(80, 21);
            this.txtCep.TabIndex = 7;
            // 
            // lblCep
            // 
            this.lblCep.AutoSize = true;
            this.lblCep.Location = new System.Drawing.Point(253, 68);
            this.lblCep.Name = "lblCep";
            this.lblCep.Size = new System.Drawing.Size(35, 13);
            this.lblCep.TabIndex = 6;
            this.lblCep.Text = "Cep:";
            // 
            // cboUf
            // 
            this.cboUf.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboUf.FormattingEnabled = true;
            this.cboUf.Items.AddRange(new object[] {
            "AC",
            "AL",
            "AP",
            "AM",
            "BA",
            "CE",
            "DF",
            "ES",
            "GO",
            "MA",
            "MT",
            "MS",
            "MG",
            "PA",
            "PB",
            "PR",
            "PE",
            "PI",
            "RJ",
            "RN",
            "RS",
            "RO",
            "RR",
            "SC",
            "SP",
            "SE",
            "TO"});
            this.cboUf.Location = new System.Drawing.Point(87, 65);
            this.cboUf.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cboUf.Name = "cboUf";
            this.cboUf.Size = new System.Drawing.Size(151, 21);
            this.cboUf.TabIndex = 5;
            // 
            // lblUf
            // 
            this.lblUf.AutoSize = true;
            this.lblUf.Location = new System.Drawing.Point(56, 68);
            this.lblUf.Name = "lblUf";
            this.lblUf.Size = new System.Drawing.Size(26, 13);
            this.lblUf.TabIndex = 4;
            this.lblUf.Text = "UF:";
            // 
            // txtCidade
            // 
            this.txtCidade.Location = new System.Drawing.Point(87, 47);
            this.txtCidade.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCidade.MaxLength = 50;
            this.txtCidade.Name = "txtCidade";
            this.txtCidade.Size = new System.Drawing.Size(284, 21);
            this.txtCidade.TabIndex = 3;
            // 
            // lblCidade
            // 
            this.lblCidade.AutoSize = true;
            this.lblCidade.Location = new System.Drawing.Point(33, 50);
            this.lblCidade.Name = "lblCidade";
            this.lblCidade.Size = new System.Drawing.Size(52, 13);
            this.lblCidade.TabIndex = 2;
            this.lblCidade.Text = "Cidade:";
            // 
            // txtInd
            // 
            this.txtInd.Location = new System.Drawing.Point(87, 136);
            this.txtInd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtInd.MaxLength = 50;
            this.txtInd.Name = "txtInd";
            this.txtInd.Size = new System.Drawing.Size(284, 21);
            this.txtInd.TabIndex = 13;
            // 
            // lblBairro
            // 
            this.lblBairro.AutoSize = true;
            this.lblBairro.Location = new System.Drawing.Point(50, 139);
            this.lblBairro.Name = "lblBairro";
            this.lblBairro.Size = new System.Drawing.Size(31, 13);
            this.lblBairro.TabIndex = 12;
            this.lblBairro.Text = "Ind:";
            // 
            // txtLogradouro
            // 
            this.txtLogradouro.Location = new System.Drawing.Point(87, 21);
            this.txtLogradouro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtLogradouro.MaxLength = 80;
            this.txtLogradouro.Name = "txtLogradouro";
            this.txtLogradouro.Size = new System.Drawing.Size(386, 21);
            this.txtLogradouro.TabIndex = 1;
            // 
            // lblLogradouro
            // 
            this.lblLogradouro.AutoSize = true;
            this.lblLogradouro.Location = new System.Drawing.Point(4, 24);
            this.lblLogradouro.Name = "lblLogradouro";
            this.lblLogradouro.Size = new System.Drawing.Size(77, 13);
            this.lblLogradouro.TabIndex = 0;
            this.lblLogradouro.Text = "Logradouro:";
            // 
            // frmClienteCadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.ClientSize = new System.Drawing.Size(535, 436);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmClienteCadastro";
            this.Text = "Cadastro de Clientes";
            this.Load += new System.EventHandler(this.frmClienteCadastro_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmClienteCadastro_KeyDown);
            this.grpCampos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errErro)).EndInit();
            this.grpDadosCliente.ResumeLayout(false);
            this.grpDadosCliente.PerformLayout();
            this.grbEndereco.ResumeLayout(false);
            this.grbEndereco.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpDadosCliente;
        private System.Windows.Forms.TextBox txtCpfCnpj;
        private System.Windows.Forms.Label lblCpfCnpj;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.GroupBox grbEndereco;
        private System.Windows.Forms.Label lblLogradouro;
        private System.Windows.Forms.TextBox txtLogradouro;
        private System.Windows.Forms.Label lblBairro;
        private System.Windows.Forms.TextBox txtInd;
        private System.Windows.Forms.Label lblCidade;
        private System.Windows.Forms.TextBox txtCidade;
        private System.Windows.Forms.Label lblCep;
        private System.Windows.Forms.ComboBox cboUf;
        private System.Windows.Forms.Label lblUf;
        private System.Windows.Forms.TextBox txtCep;
        private System.Windows.Forms.TextBox txtTelefone;
        private System.Windows.Forms.Label lblTelefones;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBanco;
        private System.Windows.Forms.TextBox txtInscEstadual;
        private System.Windows.Forms.TextBox txtObs;
        private System.Windows.Forms.TextBox txtCod;
        private System.Windows.Forms.Label label4;
    }
}
