﻿namespace ControleDeVendas.Formulários.Cadastros.Fechamentos
{
    partial class frmCadastroFechamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCorretor = new System.Windows.Forms.TextBox();
            this.txtVendedor = new System.Windows.Forms.TextBox();
            this.txtModalidade = new System.Windows.Forms.TextBox();
            this.txtFechamento = new System.Windows.Forms.TextBox();
            this.txtComprador = new System.Windows.Forms.TextBox();
            this.txtQtSacas = new System.Windows.Forms.TextBox();
            this.txtCVendedor = new System.Windows.Forms.TextBox();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.txtCondPagamento = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtPrecoExtenso = new System.Windows.Forms.TextBox();
            this.txtObservacoes = new System.Windows.Forms.TextBox();
            this.txtTipoCafe = new System.Windows.Forms.TextBox();
            this.txtSacasExtenso = new System.Windows.Forms.TextBox();
            this.txtArmazen = new System.Windows.Forms.TextBox();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtCComprador = new System.Windows.Forms.TextBox();
            this.txtAutonomo = new System.Windows.Forms.TextBox();
            this.txtUfProdutor = new System.Windows.Forms.TextBox();
            this.txtComposicao = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtSacaria = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtNomeComprador = new System.Windows.Forms.TextBox();
            this.txtNomeVendedor = new System.Windows.Forms.TextBox();
            this.txtNomeArmazen = new System.Windows.Forms.TextBox();
            this.btnImprimir = new System.Windows.Forms.Button();
            this.txtDescarga = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtNomeDescarga = new System.Windows.Forms.TextBox();
            this.grpCampos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errErro)).BeginInit();
            this.SuspendLayout();
            // 
            // grpCampos
            // 
            this.grpCampos.Controls.Add(this.txtNomeDescarga);
            this.grpCampos.Controls.Add(this.txtNomeArmazen);
            this.grpCampos.Controls.Add(this.txtNomeVendedor);
            this.grpCampos.Controls.Add(this.txtNomeComprador);
            this.grpCampos.Controls.Add(this.label8);
            this.grpCampos.Controls.Add(this.txtSacaria);
            this.grpCampos.Controls.Add(this.label23);
            this.grpCampos.Controls.Add(this.label12);
            this.grpCampos.Controls.Add(this.label22);
            this.grpCampos.Controls.Add(this.label21);
            this.grpCampos.Controls.Add(this.label20);
            this.grpCampos.Controls.Add(this.label19);
            this.grpCampos.Controls.Add(this.label18);
            this.grpCampos.Controls.Add(this.label17);
            this.grpCampos.Controls.Add(this.label16);
            this.grpCampos.Controls.Add(this.label15);
            this.grpCampos.Controls.Add(this.label14);
            this.grpCampos.Controls.Add(this.label13);
            this.grpCampos.Controls.Add(this.label11);
            this.grpCampos.Controls.Add(this.label10);
            this.grpCampos.Controls.Add(this.label9);
            this.grpCampos.Controls.Add(this.label7);
            this.grpCampos.Controls.Add(this.label6);
            this.grpCampos.Controls.Add(this.label5);
            this.grpCampos.Controls.Add(this.label4);
            this.grpCampos.Controls.Add(this.label3);
            this.grpCampos.Controls.Add(this.label2);
            this.grpCampos.Controls.Add(this.label1);
            this.grpCampos.Controls.Add(this.txtComposicao);
            this.grpCampos.Controls.Add(this.txtUfProdutor);
            this.grpCampos.Controls.Add(this.txtAutonomo);
            this.grpCampos.Controls.Add(this.txtCComprador);
            this.grpCampos.Controls.Add(this.txtMatricula);
            this.grpCampos.Controls.Add(this.txtDescarga);
            this.grpCampos.Controls.Add(this.txtDescricao);
            this.grpCampos.Controls.Add(this.txtArmazen);
            this.grpCampos.Controls.Add(this.txtSacasExtenso);
            this.grpCampos.Controls.Add(this.txtTipoCafe);
            this.grpCampos.Controls.Add(this.txtObservacoes);
            this.grpCampos.Controls.Add(this.txtPrecoExtenso);
            this.grpCampos.Controls.Add(this.txtData);
            this.grpCampos.Controls.Add(this.txtCondPagamento);
            this.grpCampos.Controls.Add(this.txtPreco);
            this.grpCampos.Controls.Add(this.txtCVendedor);
            this.grpCampos.Controls.Add(this.txtQtSacas);
            this.grpCampos.Controls.Add(this.txtComprador);
            this.grpCampos.Controls.Add(this.txtFechamento);
            this.grpCampos.Controls.Add(this.txtModalidade);
            this.grpCampos.Controls.Add(this.txtVendedor);
            this.grpCampos.Controls.Add(this.txtCorretor);
            this.grpCampos.Size = new System.Drawing.Size(643, 450);
            this.grpCampos.Enter += new System.EventHandler(this.grpCampos_Enter);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(499, 468);
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnNovo
            // 
            this.btnNovo.Location = new System.Drawing.Point(580, 468);
            this.btnNovo.TabIndex = 1;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // txtCorretor
            // 
            this.txtCorretor.Location = new System.Drawing.Point(102, 352);
            this.txtCorretor.MaxLength = 6;
            this.txtCorretor.Name = "txtCorretor";
            this.txtCorretor.Size = new System.Drawing.Size(65, 21);
            this.txtCorretor.TabIndex = 43;
            // 
            // txtVendedor
            // 
            this.txtVendedor.Location = new System.Drawing.Point(93, 64);
            this.txtVendedor.MaxLength = 5;
            this.txtVendedor.Name = "txtVendedor";
            this.txtVendedor.Size = new System.Drawing.Size(72, 21);
            this.txtVendedor.TabIndex = 8;
            this.txtVendedor.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txtModalidade
            // 
            this.txtModalidade.Location = new System.Drawing.Point(84, 167);
            this.txtModalidade.MaxLength = 120;
            this.txtModalidade.Name = "txtModalidade";
            this.txtModalidade.Size = new System.Drawing.Size(180, 21);
            this.txtModalidade.TabIndex = 25;
            // 
            // txtFechamento
            // 
            this.txtFechamento.Location = new System.Drawing.Point(93, 14);
            this.txtFechamento.MaxLength = 7;
            this.txtFechamento.Name = "txtFechamento";
            this.txtFechamento.Size = new System.Drawing.Size(72, 21);
            this.txtFechamento.TabIndex = 1;
            // 
            // txtComprador
            // 
            this.txtComprador.Location = new System.Drawing.Point(93, 38);
            this.txtComprador.MaxLength = 5;
            this.txtComprador.Name = "txtComprador";
            this.txtComprador.Size = new System.Drawing.Size(72, 21);
            this.txtComprador.TabIndex = 5;
            this.txtComprador.TextChanged += new System.EventHandler(this.txtComprador_TextChanged);
            // 
            // txtQtSacas
            // 
            this.txtQtSacas.Location = new System.Drawing.Point(67, 141);
            this.txtQtSacas.MaxLength = 5;
            this.txtQtSacas.Name = "txtQtSacas";
            this.txtQtSacas.Size = new System.Drawing.Size(56, 21);
            this.txtQtSacas.TabIndex = 17;
            // 
            // txtCVendedor
            // 
            this.txtCVendedor.Location = new System.Drawing.Point(587, 191);
            this.txtCVendedor.MaxLength = 4;
            this.txtCVendedor.Name = "txtCVendedor";
            this.txtCVendedor.Size = new System.Drawing.Size(46, 21);
            this.txtCVendedor.TabIndex = 33;
            // 
            // txtPreco
            // 
            this.txtPreco.Location = new System.Drawing.Point(195, 141);
            this.txtPreco.MaxLength = 7;
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(100, 21);
            this.txtPreco.TabIndex = 19;
            // 
            // txtCondPagamento
            // 
            this.txtCondPagamento.Location = new System.Drawing.Point(388, 167);
            this.txtCondPagamento.MaxLength = 70;
            this.txtCondPagamento.Name = "txtCondPagamento";
            this.txtCondPagamento.Size = new System.Drawing.Size(240, 21);
            this.txtCondPagamento.TabIndex = 27;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(238, 14);
            this.txtData.MaxLength = 11;
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(100, 21);
            this.txtData.TabIndex = 3;
            // 
            // txtPrecoExtenso
            // 
            this.txtPrecoExtenso.Location = new System.Drawing.Point(130, 413);
            this.txtPrecoExtenso.MaxLength = 150;
            this.txtPrecoExtenso.Name = "txtPrecoExtenso";
            this.txtPrecoExtenso.Size = new System.Drawing.Size(498, 21);
            this.txtPrecoExtenso.TabIndex = 49;
            this.txtPrecoExtenso.TextChanged += new System.EventHandler(this.txtPrecoExtenso_TextChanged);
            // 
            // txtObservacoes
            // 
            this.txtObservacoes.Location = new System.Drawing.Point(102, 221);
            this.txtObservacoes.MaxLength = 450;
            this.txtObservacoes.Multiline = true;
            this.txtObservacoes.Name = "txtObservacoes";
            this.txtObservacoes.Size = new System.Drawing.Size(531, 98);
            this.txtObservacoes.TabIndex = 35;
            // 
            // txtTipoCafe
            // 
            this.txtTipoCafe.Location = new System.Drawing.Point(587, 325);
            this.txtTipoCafe.MaxLength = 4;
            this.txtTipoCafe.Name = "txtTipoCafe";
            this.txtTipoCafe.Size = new System.Drawing.Size(41, 21);
            this.txtTipoCafe.TabIndex = 41;
            // 
            // txtSacasExtenso
            // 
            this.txtSacasExtenso.Location = new System.Drawing.Point(130, 384);
            this.txtSacasExtenso.MaxLength = 150;
            this.txtSacasExtenso.Name = "txtSacasExtenso";
            this.txtSacasExtenso.Size = new System.Drawing.Size(498, 21);
            this.txtSacasExtenso.TabIndex = 47;
            // 
            // txtArmazen
            // 
            this.txtArmazen.Location = new System.Drawing.Point(93, 88);
            this.txtArmazen.MaxLength = 5;
            this.txtArmazen.Name = "txtArmazen";
            this.txtArmazen.Size = new System.Drawing.Size(72, 21);
            this.txtArmazen.TabIndex = 11;
            this.txtArmazen.TextChanged += new System.EventHandler(this.txtArmazen_TextChanged);
            // 
            // txtDescricao
            // 
            this.txtDescricao.Location = new System.Drawing.Point(84, 191);
            this.txtDescricao.MaxLength = 199;
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(250, 21);
            this.txtDescricao.TabIndex = 29;
            this.txtDescricao.Text = "CONFORME AMOSTRA EM PODER DO COMPRADOR";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(433, 325);
            this.txtMatricula.MaxLength = 5;
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(63, 21);
            this.txtMatricula.TabIndex = 39;
            this.txtMatricula.Text = "931";
            // 
            // txtCComprador
            // 
            this.txtCComprador.Location = new System.Drawing.Point(440, 191);
            this.txtCComprador.MaxLength = 4;
            this.txtCComprador.Name = "txtCComprador";
            this.txtCComprador.Size = new System.Drawing.Size(45, 21);
            this.txtCComprador.TabIndex = 31;
            this.txtCComprador.TextChanged += new System.EventHandler(this.textBox19_TextChanged);
            // 
            // txtAutonomo
            // 
            this.txtAutonomo.Location = new System.Drawing.Point(102, 325);
            this.txtAutonomo.MaxLength = 220;
            this.txtAutonomo.Name = "txtAutonomo";
            this.txtAutonomo.Size = new System.Drawing.Size(256, 21);
            this.txtAutonomo.TabIndex = 37;
            // 
            // txtUfProdutor
            // 
            this.txtUfProdutor.Location = new System.Drawing.Point(388, 141);
            this.txtUfProdutor.MaxLength = 2;
            this.txtUfProdutor.Name = "txtUfProdutor";
            this.txtUfProdutor.Size = new System.Drawing.Size(44, 21);
            this.txtUfProdutor.TabIndex = 21;
            // 
            // txtComposicao
            // 
            this.txtComposicao.Location = new System.Drawing.Point(526, 141);
            this.txtComposicao.MaxLength = 30;
            this.txtComposicao.Name = "txtComposicao";
            this.txtComposicao.Size = new System.Drawing.Size(107, 21);
            this.txtComposicao.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Fechamento:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Comprador:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(303, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "UF Produtor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 416);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 13);
            this.label4.TabIndex = 48;
            this.label4.Text = "Preço por Extenso:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(364, 328);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 38;
            this.label5.Text = "Matricula:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 224);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 13);
            this.label6.TabIndex = 34;
            this.label6.Text = "Observações: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 387);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 13);
            this.label7.TabIndex = 46;
            this.label7.Text = "Sacas Por Extenso:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(35, 355);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 13);
            this.label9.TabIndex = 42;
            this.label9.Text = "Corretor:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 328);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 13);
            this.label10.TabIndex = 36;
            this.label10.Text = "C/ Autonomo: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(514, 328);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 13);
            this.label11.TabIndex = 40;
            this.label11.Text = "Tipo Café:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(498, 194);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 13);
            this.label13.TabIndex = 32;
            this.label13.Text = "C. Vendedor:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(340, 194);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 13);
            this.label14.TabIndex = 30;
            this.label14.Text = "C. Comprador:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 194);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 13);
            this.label15.TabIndex = 28;
            this.label15.Text = "Descrição:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(270, 170);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(114, 13);
            this.label16.TabIndex = 26;
            this.label16.Text = "Cond. Pagamento:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(2, 170);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(76, 13);
            this.label17.TabIndex = 24;
            this.label17.Text = "Modalidade:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(438, 144);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 13);
            this.label18.TabIndex = 22;
            this.label18.Text = "Composição:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(129, 144);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(63, 13);
            this.label19.TabIndex = 18;
            this.label19.Text = "Preço R$:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(2, 144);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 13);
            this.label20.TabIndex = 16;
            this.label20.Text = "QtSacas:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(195, 17);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(39, 13);
            this.label21.TabIndex = 2;
            this.label21.Text = "Data:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(2, 91);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(87, 13);
            this.label22.TabIndex = 10;
            this.label22.Text = "Loc. Retirada:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(20, 67);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(67, 13);
            this.label23.TabIndex = 7;
            this.label23.Text = "Vendedor:";
            // 
            // txtSacaria
            // 
            this.txtSacaria.Location = new System.Drawing.Point(258, 352);
            this.txtSacaria.MaxLength = 20;
            this.txtSacaria.Name = "txtSacaria";
            this.txtSacaria.Size = new System.Drawing.Size(100, 21);
            this.txtSacaria.TabIndex = 45;
            this.txtSacaria.Text = "ENSACADO";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 355);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 44;
            this.label8.Text = "Sacaria:";
            // 
            // txtNomeComprador
            // 
            this.txtNomeComprador.Enabled = false;
            this.txtNomeComprador.Location = new System.Drawing.Point(171, 38);
            this.txtNomeComprador.Name = "txtNomeComprador";
            this.txtNomeComprador.ReadOnly = true;
            this.txtNomeComprador.Size = new System.Drawing.Size(466, 21);
            this.txtNomeComprador.TabIndex = 6;
            // 
            // txtNomeVendedor
            // 
            this.txtNomeVendedor.Enabled = false;
            this.txtNomeVendedor.Location = new System.Drawing.Point(171, 64);
            this.txtNomeVendedor.Name = "txtNomeVendedor";
            this.txtNomeVendedor.ReadOnly = true;
            this.txtNomeVendedor.Size = new System.Drawing.Size(466, 21);
            this.txtNomeVendedor.TabIndex = 9;
            // 
            // txtNomeArmazen
            // 
            this.txtNomeArmazen.Enabled = false;
            this.txtNomeArmazen.Location = new System.Drawing.Point(172, 88);
            this.txtNomeArmazen.Name = "txtNomeArmazen";
            this.txtNomeArmazen.ReadOnly = true;
            this.txtNomeArmazen.Size = new System.Drawing.Size(465, 21);
            this.txtNomeArmazen.TabIndex = 12;
            // 
            // btnImprimir
            // 
            this.btnImprimir.Location = new System.Drawing.Point(21, 468);
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(75, 23);
            this.btnImprimir.TabIndex = 3;
            this.btnImprimir.Text = "Imprimir";
            this.btnImprimir.UseVisualStyleBackColor = true;
            this.btnImprimir.Click += new System.EventHandler(this.btnImprimir_Click);
            // 
            // txtDescarga
            // 
            this.txtDescarga.Location = new System.Drawing.Point(93, 112);
            this.txtDescarga.MaxLength = 5;
            this.txtDescarga.Name = "txtDescarga";
            this.txtDescarga.Size = new System.Drawing.Size(72, 21);
            this.txtDescarga.TabIndex = 14;
            this.txtDescarga.TextChanged += new System.EventHandler(this.txtDescarga_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 115);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 13);
            this.label12.TabIndex = 13;
            this.label12.Text = "Descarga:";
            // 
            // txtNomeDescarga
            // 
            this.txtNomeDescarga.Enabled = false;
            this.txtNomeDescarga.Location = new System.Drawing.Point(172, 112);
            this.txtNomeDescarga.Name = "txtNomeDescarga";
            this.txtNomeDescarga.ReadOnly = true;
            this.txtNomeDescarga.Size = new System.Drawing.Size(465, 21);
            this.txtNomeDescarga.TabIndex = 15;
            // 
            // frmCadastroFechamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.ClientSize = new System.Drawing.Size(667, 519);
            this.Controls.Add(this.btnImprimir);
            this.Name = "frmCadastroFechamento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fechamento";
            this.Load += new System.EventHandler(this.frmCadastroFechamento_Load);
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.btnImprimir, 0);
            this.Controls.SetChildIndex(this.btnNovo, 0);
            this.Controls.SetChildIndex(this.grpCampos, 0);
            this.grpCampos.ResumeLayout(false);
            this.grpCampos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errErro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtVendedor;
        private System.Windows.Forms.TextBox txtCorretor;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtComposicao;
        private System.Windows.Forms.TextBox txtUfProdutor;
        private System.Windows.Forms.TextBox txtAutonomo;
        private System.Windows.Forms.TextBox txtCComprador;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtDescricao;
        private System.Windows.Forms.TextBox txtArmazen;
        private System.Windows.Forms.TextBox txtSacasExtenso;
        private System.Windows.Forms.TextBox txtTipoCafe;
        private System.Windows.Forms.TextBox txtObservacoes;
        private System.Windows.Forms.TextBox txtPrecoExtenso;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtCondPagamento;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.TextBox txtCVendedor;
        private System.Windows.Forms.TextBox txtQtSacas;
        private System.Windows.Forms.TextBox txtComprador;
        private System.Windows.Forms.TextBox txtFechamento;
        private System.Windows.Forms.TextBox txtModalidade;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSacaria;
        private System.Windows.Forms.TextBox txtNomeComprador;
        private System.Windows.Forms.TextBox txtNomeArmazen;
        private System.Windows.Forms.TextBox txtNomeVendedor;
        private System.Windows.Forms.Button btnImprimir;
        private System.Windows.Forms.TextBox txtNomeDescarga;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtDescarga;
    }
}
