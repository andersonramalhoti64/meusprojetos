using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Negocio;
using DllControleDeVendas.Sistema.Globais;

namespace ControleDeVendas.Formul�rios.Cadastros.Cliente
{
    public partial class frmClienteCadastro : ControleDeVendas.Formul�rios.Modelos.frmModeloCadastro
    {
        public frmClienteCadastro()
        {
            InitializeComponent();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (txtCod.Text.Equals(string.Empty))
            {
                errErro.SetError(txtCod, "Digite um C�digo");
                return;
            }
            else
            {
                errErro.SetError(txtCod, "");
            }
            
            if (txtNome.Text.Equals(string.Empty))
            {
                errErro.SetError(txtNome, "Digite um nome");
                return;
            }
            else
            {
                errErro.SetError(txtNome, "");
            }
            if (txtCpfCnpj.Text.Equals(string.Empty))
            {
                errErro.SetError(txtCpfCnpj, "Digite um CPF/CNPJ");
                return;
            }
            else
            {
                errErro.SetError(txtCpfCnpj, "");
            }
            if (txtLogradouro.Text.Equals(string.Empty))
            {
                errErro.SetError(txtLogradouro, "Digite um logradouro");
                return;
            }
            else
            {
                errErro.SetError(txtLogradouro, "");
            }
            if (txtInd.Text.Equals(string.Empty))
            {
                errErro.SetError(txtInd, "Digite um bairro");
                return;
            }
            else
            {
                errErro.SetError(txtInd, "");
            }
            if (txtCidade.Text.Equals(string.Empty))
            {
                errErro.SetError(txtCidade, "Digite uma cidade");
                return;
            }
            else
            {
                errErro.SetError(txtCidade, "");
            }
            if (cboUf.Text.Equals(string.Empty))
            {
                errErro.SetError(cboUf, "Selecione uma UF");
                return;
            }
            else
            {
                errErro.SetError(cboUf, "");
            }
            if (txtCep.Text.Equals(string.Empty))
            {
                errErro.SetError(txtCep, "Digite um CEP");
                return;
            }
            else
            {
                errErro.SetError(txtCep, "");
            }
            if (txtBanco.Text.Equals(string.Empty))
            {
                errErro.SetError(txtCep, "Digite um Banco");
                return;
            }
            else
            {
                errErro.SetError(txtBanco, "");
            }
            if (txtInscEstadual.Text.Equals(string.Empty))
            {
                errErro.SetError(txtCep, "Digite a Inscri��o Estadual");
                return;
            }
            else
            {
                errErro.SetError(txtInscEstadual, "");
            }
            
            clnCliente cldCliente = new clnCliente();
            cldCliente.cli_Id = Int32.Parse(txtCod.Text);
            cldCliente.cli_Ind = txtInd.Text;
            cldCliente.cli_CEP = txtCep.Text;
            cldCliente.cli_Cidade = txtCidade.Text;
            cldCliente.cli_CNPJCPF = txtCpfCnpj.Text;
            cldCliente.cli_DtCadastro = DateTime.Now;
            cldCliente.cli_Email = txtFax.Text;
            cldCliente.cli_Fones = txtTelefone.Text;
            cldCliente.cli_Logradouro = txtLogradouro.Text;
            cldCliente.cli_NomeRazao = txtNome.Text;
            cldCliente.cli_Uf = cboUf.Text;
            cldCliente.cli_banco = txtBanco.Text;
            cldCliente.cli_insc = txtInscEstadual.Text;
            cldCliente.cli_obs = txtObs.Text;
            if (Operacao == clnFuncoesGerais.Operacao.Inclusao)
            {
                cldCliente.Gravar();
            }
            else if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
            {
                cldCliente.cli_Id = Codigo;
                cldCliente.Alterar();
            }
            MessageBox.Show("Registro gravado com sucesso", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void frmClienteCadastro_Load(object sender, EventArgs e)
        {
            if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
            {
                clnCliente clncliente = new clnCliente();
                System.Data.OleDb.OleDbDataReader drDados;
                drDados = clncliente.ListarCliente(Codigo);
                if (drDados.HasRows)
                {
                    drDados.Read();
                    txtNome.Text = drDados["cli_NomeRazao"].ToString();
                    txtCpfCnpj.Text = drDados["cli_CNPJCPF"].ToString();
                    txtLogradouro.Text = drDados["cli_Logradouro"].ToString();
                    txtInd.Text = drDados["cli_Ind"].ToString();
                    txtCidade.Text = drDados["cli_Cidade"].ToString();
                    cboUf.Text = drDados["cli_Uf"].ToString();
                    txtCep.Text = drDados["cli_CEP"].ToString();
                    txtFax.Text = drDados["cli_Fax"].ToString();
                    txtTelefone.Text = drDados["cli_Fones"].ToString();
                    txtInscEstadual.Text = drDados["cli_insc"].ToString();
                    txtBanco.Text = drDados["cli_banco"].ToString();
                    txtObs.Text = drDados["cli_obs"].ToString();
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }

        private void frmClienteCadastro_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                btnSair_Click(sender, e);
            else if (e.KeyCode == Keys.F3)
                btnNovo_Click(sender, e);
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}

