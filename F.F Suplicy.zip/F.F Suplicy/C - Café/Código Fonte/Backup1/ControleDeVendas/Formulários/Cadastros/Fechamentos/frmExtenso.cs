﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas;
using DllControleDeVendas.Sistema.Globais;

namespace ControleDeVendas.Formulários.Cadastros.Fechamentos
{
    public partial class frmExtenso : ControleDeVendas.Formulários.Modelos.frmModelo
    {
        public frmExtenso()
        {
            InitializeComponent();
        }

        private void btnEscrever_Click(object sender, EventArgs e)
        {
            try
            {
                ClsExtenso extenso = new ClsExtenso();
                txtExtenso.Text = extenso.Extenso_Valor(decimal.Parse(txtValor.Text));
            }
            catch(Exception ex)
            {
                MessageBox.Show("Valor Inválido: " + ex.Message + "Favor digitar somente números decimais", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void txtValor_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void frmExtenso_Load(object sender, EventArgs e)
        {
            txtValor.Focus();
        }
    }
}
