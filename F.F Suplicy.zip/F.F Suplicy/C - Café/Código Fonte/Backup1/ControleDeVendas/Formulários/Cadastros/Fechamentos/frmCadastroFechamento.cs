﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Negocio;
using DllControleDeVendas.Sistema.Globais;
using ControleDeVendas.Relatórios;

namespace ControleDeVendas.Formulários.Cadastros.Fechamentos
{
    public partial class frmCadastroFechamento : ControleDeVendas.Formulários.Modelos.frmModeloCadastro
    {
        public virtual TextBox textoFechamento
        {
            get { return txtFechamento; }
        }
        public virtual TextBox DataAtual
        {
            get { return txtData; }
        }
        private frmConsultaFechamentos _frmPai;
        public frmCadastroFechamento()
        {
            InitializeComponent();
        }
        public frmCadastroFechamento(frmConsultaFechamentos frmPai)
        {
            InitializeComponent();
            this._frmPai = frmPai;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            EscreverExtenso();
            try
            {

                clnFechamento clnfechamento = new clnFechamento();
                
                clnfechamento.fechamento = txtFechamento.Text;
                clnfechamento.armazen = int.Parse(txtArmazen.Text);
                clnfechamento.composicao = txtComposicao.Text;
                clnfechamento.comprador = int.Parse(txtComprador.Text);
                clnfechamento.vendendor = int.Parse(txtVendedor.Text);
                clnfechamento.descarga = int.Parse(txtDescarga.Text);
                clnfechamento.condpagamento = txtCondPagamento.Text;
                clnfechamento.corretcomprador = Double.Parse(txtCComprador.Text);
                clnfechamento.corretor = txtCorretor.Text;
                clnfechamento.corretvendedor = Double.Parse(txtCVendedor.Text);
                clnfechamento.data = DateTime.Parse(txtData.Text);
                clnfechamento.descricao = txtDescricao.Text;
                clnfechamento.matr = txtMatricula.Text;
                clnfechamento.modalidade = txtModalidade.Text;
                clnfechamento.observacoes1 = txtObservacoes.Text;
                clnfechamento.observacoes2 = txtAutonomo.Text;
                clnfechamento.preco = double.Parse(txtPreco.Text);
                clnfechamento.qtSacos = int.Parse(txtQtSacas.Text);
                clnfechamento.sacaria = txtSacaria.Text;
                clnfechamento.tipoCafe = txtTipoCafe.Text;
                clnfechamento.ufprodutor = txtUfProdutor.Text;
                clnfechamento.preco_extenso = txtPrecoExtenso.Text;
                clnfechamento.sacas_extenso = txtSacasExtenso.Text;


                if (Operacao == clnFuncoesGerais.Operacao.Inclusao)
                {
                    Maiuscula();
                    clnfechamento.Gravar();
                    
                }
                else if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
                {
                    Maiuscula();
                    clnfechamento.fechamento = fechamento;    
                    clnfechamento.Alterar();
                }
                MessageBox.Show("Registro gravado com sucesso", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnImprimir_Click(sender, e);
                this.Close();
            }
            catch(Exception exe)
            {
                MessageBox.Show("Ocorreu o erro: "+exe.Message,this.Text,MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            clnFechamento compvendarmazen = new clnFechamento();

            if (!txtVendedor.Text.Equals(String.Empty))
            {
                System.Data.OleDb.OleDbDataReader drVendedor;
                drVendedor = compvendarmazen.ListarVendedor(txtVendedor.Text);

                if (drVendedor.HasRows)
                {
                    drVendedor.Read();
                    txtNomeVendedor.Text = drVendedor["cli_NomeRazao"].ToString();
                }
            }

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void grpCampos_Enter(object sender, EventArgs e)
        {

        }

        private void frmCadastroFechamento_Load(object sender, EventArgs e)
        {
            try
            {
                if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
                {
                    clnFechamento clnfechamento = new clnFechamento();
                    System.Data.OleDb.OleDbDataReader drDados;
                    System.Data.OleDb.OleDbDataReader drComprador;
                    System.Data.OleDb.OleDbDataReader drVendedor;
                    System.Data.OleDb.OleDbDataReader drArmazen;
                    System.Data.OleDb.OleDbDataReader drDescarga;

                    drDados = clnfechamento.ListarCliente(fechamento);
                    txtFechamento.Text = fechamento;
                    if (drDados.HasRows)
                    {
                        drDados.Read();
                        txtComprador.Text = drDados["comprador"].ToString();
                        txtArmazen.Text = drDados["armazen"].ToString();
                        txtVendedor.Text = drDados["vendendor"].ToString();
                        txtDescricao.Text = drDados["descricao"].ToString();
                        txtDescarga.Text = drDados["descarga"].ToString();
                        txtData.Text = drDados["data"].ToString();
                        txtUfProdutor.Text = drDados["ufprodutor"].ToString();
                        txtQtSacas.Text = drDados["qtsacos"].ToString();
                        txtSacaria.Text = drDados["sacaria"].ToString();
                        txtMatricula.Text = drDados["matr"].ToString();
                        txtObservacoes.Text = drDados["observacoes1"].ToString();
                        txtCorretor.Text = drDados["corretor"].ToString();
                        txtCVendedor.Text = drDados["corretvendedor"].ToString();
                        txtCondPagamento.Text = drDados["condpagamento"].ToString();
                        txtCComprador.Text = drDados["corretcomprador"].ToString();
                        txtPreco.Text = drDados["preco"].ToString();
                        txtModalidade.Text = drDados["modalidade"].ToString();
                        txtComposicao.Text = drDados["composicao"].ToString();
                        txtAutonomo.Text = drDados["observacoes2"].ToString();
                        txtTipoCafe.Text = drDados["tipocafe"].ToString();
                        txtSacasExtenso.Text = drDados["sacas_extenso"].ToString();
                        txtPrecoExtenso.Text = drDados["preco_extenso"].ToString();

                    }
                    drComprador = clnfechamento.ListarComprador(txtComprador.Text);
                    drVendedor = clnfechamento.ListarVendedor(txtVendedor.Text);
                    drArmazen = clnfechamento.ListarArmazen(txtArmazen.Text);
                    drDescarga = clnfechamento.ListarDescarga(txtDescarga.Text);

                    if (!txtComprador.Text.Equals(String.Empty))
                    {
                        if (drComprador.HasRows)
                        {
                            drComprador.Read();
                            txtNomeComprador.Text = drComprador["cli_NomeRazao"].ToString();
                        }
                    }

                    if (!txtVendedor.Text.Equals(String.Empty))
                    {
                        if (drVendedor.HasRows)
                        {
                            drVendedor.Read();
                            txtNomeVendedor.Text = drVendedor["cli_NomeRazao"].ToString();
                        }
                    }

                    if (!txtArmazen.Text.Equals(String.Empty))
                    {
                        if (drArmazen.HasRows)
                        {
                            drArmazen.Read();
                            txtNomeArmazen.Text = drArmazen["cli_NomeRazao"].ToString();
                        }
                    }
                    if (!txtDescarga.Text.Equals(String.Empty))
                    {
                        if (drDescarga.HasRows)
                        {
                            drArmazen.Read();
                            txtNomeDescarga.Text = drDescarga["cli_NomeRazao"].ToString();
                        }
                    }
                }
                frmCadastroFechamento textoEmCima = new frmCadastroFechamento();
                textoEmCima.Text = "Fechamento -" + txtFechamento.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu o erro: " + ex.Message,this.Text,MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
        }
        private void EscreverExtenso()
        {
            ClsExtensoValor extvalor = new ClsExtensoValor();
            ClsExtenso extenso = new ClsExtenso();

            try
            {
                txtSacasExtenso.Text = extvalor.Extenso_Valor(decimal.Parse(txtQtSacas.Text));
                //Alteração na Inclusão do Preço por Extenso 20/07/2010
                txtPrecoExtenso.Text = extenso.Extenso_Valor(decimal.Parse(txtPreco.Text));
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "erro");
            }
        }
        private void Maiuscula()
        {
            foreach (Control cxaTexto in frmCadastroFechamento.ActiveForm.Controls)
            {
                if (cxaTexto is TextBox)
                    cxaTexto.Text.ToUpper();
            }
        }

        private void txtComprador_TextChanged(object sender, EventArgs e)
        {
            clnFechamento compvendarmazen = new clnFechamento();
            
            if (!txtComprador.Text.Equals(String.Empty))
            {
                System.Data.OleDb.OleDbDataReader drComprador;
                drComprador = compvendarmazen.ListarComprador(txtComprador.Text);

                if (drComprador.HasRows)
                {
                    drComprador.Read();
                    txtNomeComprador.Text = drComprador["cli_NomeRazao"].ToString();
                }
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            frmPrintFechamento frmPrintFechamentos = new frmPrintFechamento(this);
            frmPrintFechamentos.ShowDialog();
        }

        private void txtArmazen_TextChanged(object sender, EventArgs e)
        {
            clnFechamento compvendarmazen = new clnFechamento();

            if (!txtVendedor.Text.Equals(String.Empty))
            {
                System.Data.OleDb.OleDbDataReader drComprador;
                drComprador = compvendarmazen.ListarArmazen(txtArmazen.Text);

                if (drComprador.HasRows)
                {
                    drComprador.Read();
                    txtNomeArmazen.Text = drComprador["cli_NomeRazao"].ToString();
                }
            }
        }

        private void txtDescarga_TextChanged(object sender, EventArgs e)
        {
            clnFechamento compvendarmazen = new clnFechamento();

            if (!txtDescarga.Text.Equals(String.Empty))
            {
                System.Data.OleDb.OleDbDataReader drDescarga;
                drDescarga = compvendarmazen.ListarDescarga(txtDescarga.Text);

                if (drDescarga.HasRows)
                {
                    drDescarga.Read();
                    txtNomeDescarga.Text = drDescarga["cli_NomeRazao"].ToString();
                }
            }
        }

        private void txtPrecoExtenso_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
