using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ControleDeVendas.Formul�rios.Cadastros.Cliente;
using ControleDeVendas.Formul�rios.Cadastros.Fechamentos;
using DllControleDeVendas.Sistema.Negocio;

namespace ControleDeVendas.Formul�rios.Sistema
{
    public partial class frmMenu : ControleDeVendas.Formul�rios.Modelos.frmModelo
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmClienteConsulta frmCliente = new frmClienteConsulta();
            frmCliente.ShowDialog();
        }

        private void categoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void produtoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void vendasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSobre Sobre = new frmSobre();
            Sobre.ShowDialog();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void inclus�oConsultaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConsultaFechamentos fechamentos = new frmConsultaFechamentos();
            fechamentos.ShowDialog();
        }

        private void extensoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExtenso extenso = new frmExtenso();
            extenso.ShowDialog();
        }

        private void lIGAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmLiga LIGA = new frmLiga();
            LIGA.ShowDialog();
        }

        private void fechamentoDoMesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ControleDeVendas.Relat�rios.frmMesFechamento Mesfec = new ControleDeVendas.Relat�rios.frmMesFechamento();
            Mesfec.ShowDialog();
        }

        private void frmMenu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        
    }
}

