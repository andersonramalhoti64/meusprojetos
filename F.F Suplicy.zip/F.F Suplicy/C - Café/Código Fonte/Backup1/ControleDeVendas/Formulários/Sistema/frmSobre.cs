﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace ControleDeVendas.Formulários.Sistema
{
    partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
            this.Text = "Sobre";
        }

        private void frmSobre_Load(object sender, EventArgs e)
        {
            labelVersion.Text = "1.0.0.";
            labelProductName.Text = "Controle de Café - F.F. Suplicy";
            labelCopyright.Text = "Copyright 2009";
            labelCompanyName.Text = "F.F. Suplicy Corretagens de Café";
        }

        private void textBoxDescription_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
