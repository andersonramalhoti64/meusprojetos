﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControleDeVendas.Formulários.Sistema
{
    public partial class frmLiga : Form
    {
        public frmLiga()
        {
            InitializeComponent();
        }

        private void textBox35_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmLiga_Load(object sender, EventArgs e)
        {

        }

        private void txtNVias_TextChanged(object sender, EventArgs e)
        {
            if (txtNVias.Text == string.Empty || txtNVias.Text.Equals(typeof(string)))
            { txtNVias.Text = "0"; 
              txtNVias.SelectAll(); 
            }

        }

        private void frmLiga_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                SendKeys.Send("{Tab}");
        }

        private void txtLotes1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtGramas1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void txtGramas2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLotes2_TextChanged(object sender, EventArgs e)
        {
            
        }
        private int SomarTextBoxes()
        {
            foreach (Control cxaTexto1a15 in grp1a15.Controls)
            {
                if (cxaTexto1a15 is TextBox && cxaTexto1a15.Text == string.Empty)
                    cxaTexto1a15.Text = "0";
            }
            foreach (Control cxaTexto16a30 in grp16a30.Controls)
            {
                if (cxaTexto16a30 is TextBox && cxaTexto16a30.Text == string.Empty)
                    cxaTexto16a30.Text = "0";
            }
            foreach (Control cxaTexto31a45 in grp31a45.Controls)
            {
                if (cxaTexto31a45 is TextBox & cxaTexto31a45.Text == string.Empty)
                    cxaTexto31a45.Text = "0";
            }

            int totalGp1 = (Int32.Parse(txtLotes1.Text) + Int32.Parse(txtLotes2.Text) + Int32.Parse(txtLotes3.Text) + Int32.Parse(txtLotes4.Text)
                 + Int32.Parse(txtLotes5.Text) + Int32.Parse(txtLotes6.Text) + Int32.Parse(txtLotes7.Text) + Int32.Parse(txtLotes8.Text)
                 + Int32.Parse(txtLotes9.Text) + Int32.Parse(txtLotes10.Text) + Int32.Parse(txtLotes11.Text) + Int32.Parse(txtLotes12.Text)
                 + Int32.Parse(txtLotes13.Text) + Int32.Parse(txtLotes14.Text) + Int32.Parse(txtLotes15.Text));

            int totalGp2 = (Int32.Parse(txtLotes16.Text) + Int32.Parse(txtLotes17.Text) + Int32.Parse(txtLotes18.Text) + Int32.Parse(txtLotes19.Text)
                 + Int32.Parse(txtLotes20.Text) + Int32.Parse(txtLotes21.Text) + Int32.Parse(txtLotes22.Text) + Int32.Parse(txtLotes23.Text)
                 + Int32.Parse(txtLotes24.Text) + Int32.Parse(txtLotes25.Text) + Int32.Parse(txtLotes26.Text) + Int32.Parse(txtLotes27.Text)
                 + Int32.Parse(txtLotes28.Text) + Int32.Parse(txtLotes29.Text) + Int32.Parse(txtLotes30.Text));

            int totalGp3 = (Int32.Parse(txtLotes31.Text) + Int32.Parse(txtLotes32.Text) + Int32.Parse(txtLotes33.Text) + Int32.Parse(txtLotes34.Text)
                 + Int32.Parse(txtLotes35.Text) + Int32.Parse(txtLotes36.Text) + Int32.Parse(txtLotes37.Text) + Int32.Parse(txtLotes38.Text)
                 + Int32.Parse(txtLotes39.Text) + Int32.Parse(txtLotes40.Text) + Int32.Parse(txtLotes41.Text) + Int32.Parse(txtLotes42.Text)
                 + Int32.Parse(txtLotes43.Text) + Int32.Parse(txtLotes44.Text) + Int32.Parse(txtLotes45.Text));

            int total = totalGp1 + totalGp2 + totalGp3;

            return total;
        }
        private void ZerarSemErros()
        {
            foreach (Control text in grp1a15.Controls)
            {
                if (text is TextBox && text.Name.Substring(0, 4) != "txtG" && text.Name.Substring(0, 4) != "txtP")
                {
                    text.Text = "0";
                }
            }
            foreach (Control text in grp16a30.Controls)
            {
                if (text is TextBox && text.Name.Substring(0, 4) != "txtG" && text.Name.Substring(0, 4) != "txtP")
                {
                    text.Text = "0";
                }
            }
            foreach (Control text in grp31a45.Controls)
            {
                if (text is TextBox && text.Name.Substring(0, 4) != "txtG" && text.Name.Substring(0, 4) != "txtP")
                {
                    text.Text = "0";
                }
            }
        }
        private double TotalGramas(TextBox cxaTexto)
        {
            double total;
            double g = Double.Parse(txtTotGramas.Text);
            double sacas = Double.Parse(txtTotSacas.Text);

            total = (g / sacas) * Double.Parse(cxaTexto.Text);

            return total;
        }

        private void txtLotes3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLotes4_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtLotes5_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtLotes6_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLotes7_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLotes8_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLotes9_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLotes10_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLotes11_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtLotes12_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtLotes13_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLotes14_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtLotes15_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           
            txtTotGramas.Text = (Int32.Parse(txtNVias.Text) * 300).ToString();
            txtTotSacas.Text = SomarTextBoxes().ToString(); 

            //parte 1
            txtGramas1.Text = string.Format("{0:f2}", TotalGramas(txtLotes1));
            txtGramas2.Text = string.Format("{0:f2}", TotalGramas(txtLotes2));
            txtGramas3.Text = string.Format("{0:f2}", TotalGramas(txtLotes3));
            txtGramas4.Text = string.Format("{0:f2}", TotalGramas(txtLotes4));
            txtGramas5.Text = string.Format("{0:f2}", TotalGramas(txtLotes5));
            txtGramas6.Text = string.Format("{0:f2}", TotalGramas(txtLotes6));
            txtGramas7.Text = string.Format("{0:f2}", TotalGramas(txtLotes7));
            txtGramas8.Text = string.Format("{0:f2}", TotalGramas(txtLotes8));
            txtGramas9.Text = string.Format("{0:f2}", TotalGramas(txtLotes9));
            txtGramas10.Text = string.Format("{0:f2}", TotalGramas(txtLotes10));
            txtGramas11.Text = string.Format("{0:f2}", TotalGramas(txtLotes11));
            txtGramas12.Text = string.Format("{0:f2}", TotalGramas(txtLotes12));
            txtGramas13.Text = string.Format("{0:f2}", TotalGramas(txtLotes13));
            txtGramas14.Text = string.Format("{0:f2}", TotalGramas(txtLotes14));
            txtGramas15.Text = string.Format("{0:f2}", TotalGramas(txtLotes15));
           
            //parte 2
            txtGramas16.Text = string.Format("{0:f2}", TotalGramas(txtLotes16));
            txtGramas17.Text = string.Format("{0:f2}", TotalGramas(txtLotes17));
            txtGramas18.Text = string.Format("{0:f2}", TotalGramas(txtLotes18));
            txtGramas19.Text = string.Format("{0:f2}", TotalGramas(txtLotes19));
            txtGramas20.Text = string.Format("{0:f2}", TotalGramas(txtLotes20));
            txtGramas21.Text = string.Format("{0:f2}", TotalGramas(txtLotes21));
            txtGramas22.Text = string.Format("{0:f2}", TotalGramas(txtLotes22));
            txtGramas23.Text = string.Format("{0:f2}", TotalGramas(txtLotes23));
            txtGramas24.Text = string.Format("{0:f2}", TotalGramas(txtLotes24));
            txtGramas25.Text = string.Format("{0:f2}", TotalGramas(txtLotes25));
            txtGramas26.Text = string.Format("{0:f2}", TotalGramas(txtLotes26));
            txtGramas27.Text = string.Format("{0:f2}", TotalGramas(txtLotes27));
            txtGramas28.Text = string.Format("{0:f2}", TotalGramas(txtLotes28));
            txtGramas29.Text = string.Format("{0:f2}", TotalGramas(txtLotes29));
            txtGramas30.Text = string.Format("{0:f2}", TotalGramas(txtLotes30));

            //parte 3
            txtGramas31.Text = string.Format("{0:f2}", TotalGramas(txtLotes31));
            txtGramas32.Text = string.Format("{0:f2}", TotalGramas(txtLotes32));
            txtGramas33.Text = string.Format("{0:f2}", TotalGramas(txtLotes33));
            txtGramas34.Text = string.Format("{0:f2}", TotalGramas(txtLotes34));
            txtGramas35.Text = string.Format("{0:f2}", TotalGramas(txtLotes35));
            txtGramas36.Text = string.Format("{0:f2}", TotalGramas(txtLotes36));
            txtGramas37.Text = string.Format("{0:f2}", TotalGramas(txtLotes37));
            txtGramas38.Text = string.Format("{0:f2}", TotalGramas(txtLotes38));
            txtGramas39.Text = string.Format("{0:f2}", TotalGramas(txtLotes39));
            txtGramas40.Text = string.Format("{0:f2}", TotalGramas(txtLotes40));
            txtGramas41.Text = string.Format("{0:f2}", TotalGramas(txtLotes41));
            txtGramas42.Text = string.Format("{0:f2}", TotalGramas(txtLotes42));
            txtGramas43.Text = string.Format("{0:f2}", TotalGramas(txtLotes43));
            txtGramas44.Text = string.Format("{0:f2}", TotalGramas(txtLotes44));
            txtGramas45.Text = string.Format("{0:f2}", TotalGramas(txtLotes45));
        }

        private void btnApagarTudo_Click(object sender, EventArgs e)
        {
            foreach (Control cxaTexto1a15 in grp1a15.Controls)
            {
                if (cxaTexto1a15 is TextBox)
                    cxaTexto1a15.Text = string.Empty;
            }
            foreach (Control cxaTexto16a30 in grp16a30.Controls)
            {
                if (cxaTexto16a30 is TextBox)
                    cxaTexto16a30.Text = string.Empty;
            }
            foreach (Control cxaTexto31a45 in grp31a45.Controls)
            {
                if (cxaTexto31a45 is TextBox)
                    cxaTexto31a45.Text = string.Empty;
            }
            
            txtTotGramas.Text = string.Empty;
            txtTotSacas.Text = string.Empty;
            txtNVias.Text = string.Empty;

            txtNVias.Focus();
        }
        private void printLiga_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //int i = 0;
            Pen Caneta = new Pen(Brushes.Black);
            Graphics g = e.Graphics;
            string Titulo = "* F. F. SUPLICY C. M. LTDA. *";
            int posY = 0;
            
            Font fonteMensagem = new Font("Times New Roman",12,FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            
            g.DrawString(Titulo, fonteMensagem, Brushes.Black, 270, 40);
            g.DrawString("===============================", fonteMensagem, Brushes.Black, 250, posY = posY + 60);
            g.DrawString("", fonteMensagem, Brushes.Black, 200, posY = posY + 15);
            g.DrawString("LIGA DE AMOSTRAS",fonteMensagem,Brushes.Black,290,posY = posY + 15);
            g.DrawString("-------------------------------", fonteMensagem, Brushes.Black, 290, posY = posY + 10);
            g.DrawString("", fonteMensagem, Brushes.Black, 320, posY = posY + 25);

            foreach (Control cxaTexto in grp1a15.Controls)
            {
                 if (cxaTexto is TextBox && Double.Parse(cxaTexto.Text) > 0 && cxaTexto.Name.Substring(0, 4) == "txtL")
                 {
                        //if (i <= 9)
                            g.DrawString("Lote ______ " + " = " + cxaTexto.Text, fonteMensagem, Brushes.Black, 50, posY = posY + 20);
                       // else
                         //   g.DrawString("Lote -   " + i.ToString() + " = " + cxaTexto.Text, fonteMensagem, Brushes.Black, 50, posY = posY + 20);
                 }
                }
            
            foreach (Control cxaTexto in grp16a30.Controls)
            {
                if (cxaTexto is TextBox && Double.Parse(cxaTexto.Text) > 0 && cxaTexto.Name.Substring(0, 4) == "txtL")
                {
                    g.DrawString("Lote ______ " + " = " + cxaTexto.Text, fonteMensagem, Brushes.Black, 50, posY = posY + 20);
                }
            }
            foreach (Control cxaTexto in grp31a45.Controls)
            {
                if (cxaTexto is TextBox && Double.Parse(cxaTexto.Text) > 0 && cxaTexto.Name.Substring(0, 4) == "txtL")
                {
                    g.DrawString("Lote ______ " + " = " + cxaTexto.Text, fonteMensagem, Brushes.Black, 50, posY = posY + 20);
                }
            }

            posY = 125;

            foreach (Control cxaTexto in grp1a15.Controls)
            {
                if (cxaTexto is TextBox && Double.Parse(cxaTexto.Text) > 0 && cxaTexto.Name.Substring(0, 4) == "txtG")
                {
                    g.DrawString("     Sacas = " + cxaTexto.Text + "     Gramas", fonteMensagem, Brushes.Black, 180, posY = posY + 20);
                }
            }
            foreach (Control cxaTexto in grp16a30.Controls)
            {
                if (cxaTexto is TextBox && Double.Parse(cxaTexto.Text) > 0 && cxaTexto.Name.Substring(0, 4) == "txtG")
                {
                    g.DrawString("     Sacas = " + cxaTexto.Text + "     Gramas", fonteMensagem, Brushes.Black, 180, posY = posY + 20);
                }
            }
            foreach (Control cxaTexto in grp31a45.Controls)
            {
                if (cxaTexto is TextBox && Double.Parse(cxaTexto.Text) > 0 && cxaTexto.Name.Substring(0, 4) == "txtG")
                {
                    g.DrawString("     Sacas = " + cxaTexto.Text + "     Gramas", fonteMensagem, Brushes.Black, 180, posY = posY + 20);
                }
            }

            g.DrawString("Total de Sacas = " + txtTotSacas.Text + "   " + txtNVias.Text + " Via(s)" + " = 300 Gramas",fonteMensagem,Brushes.Black,50, posY = posY+ 40);      
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            button1_Click_1(sender, e);

            if (Int32.Parse(txtNVias.Text) > 0 && Int32.Parse(txtTotSacas.Text) > 0)
            {
                previewPrintLiga.ShowDialog();
            }
            else
            {
                MessageBox.Show("Não ha quantidade de vias ou sacas definidas", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNVias.Focus();
            }
        }

        private void grp31a45_Enter(object sender, EventArgs e)
        {

        }

        private void previewPrintLiga_Load(object sender, EventArgs e)
        {

        }
    }
}
