﻿namespace ControleDeVendas.Formulários.Sistema
{
    partial class frmLiga
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLiga));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.txtNVias = new System.Windows.Forms.TextBox();
            this.txtPen15 = new System.Windows.Forms.TextBox();
            this.txtPen14 = new System.Windows.Forms.TextBox();
            this.txtPen1 = new System.Windows.Forms.TextBox();
            this.txtPen2 = new System.Windows.Forms.TextBox();
            this.txtPen3 = new System.Windows.Forms.TextBox();
            this.txtPen5 = new System.Windows.Forms.TextBox();
            this.txtPen4 = new System.Windows.Forms.TextBox();
            this.txtPen6 = new System.Windows.Forms.TextBox();
            this.txtPen7 = new System.Windows.Forms.TextBox();
            this.txtPen8 = new System.Windows.Forms.TextBox();
            this.txtPen9 = new System.Windows.Forms.TextBox();
            this.txtPen10 = new System.Windows.Forms.TextBox();
            this.txtPen11 = new System.Windows.Forms.TextBox();
            this.txtPen12 = new System.Windows.Forms.TextBox();
            this.txtPen13 = new System.Windows.Forms.TextBox();
            this.txtTotSacas = new System.Windows.Forms.TextBox();
            this.txtTotGramas = new System.Windows.Forms.TextBox();
            this.grp1a15 = new System.Windows.Forms.GroupBox();
            this.txtGramas13 = new System.Windows.Forms.TextBox();
            this.txtGramas12 = new System.Windows.Forms.TextBox();
            this.txtGramas11 = new System.Windows.Forms.TextBox();
            this.txtGramas10 = new System.Windows.Forms.TextBox();
            this.txtGramas9 = new System.Windows.Forms.TextBox();
            this.txtGramas8 = new System.Windows.Forms.TextBox();
            this.txtGramas7 = new System.Windows.Forms.TextBox();
            this.txtGramas6 = new System.Windows.Forms.TextBox();
            this.txtGramas4 = new System.Windows.Forms.TextBox();
            this.txtGramas5 = new System.Windows.Forms.TextBox();
            this.txtGramas3 = new System.Windows.Forms.TextBox();
            this.txtGramas2 = new System.Windows.Forms.TextBox();
            this.txtGramas1 = new System.Windows.Forms.TextBox();
            this.txtGramas14 = new System.Windows.Forms.TextBox();
            this.txtGramas15 = new System.Windows.Forms.TextBox();
            this.txtLotes13 = new System.Windows.Forms.TextBox();
            this.txtLotes12 = new System.Windows.Forms.TextBox();
            this.txtLotes11 = new System.Windows.Forms.TextBox();
            this.txtLotes10 = new System.Windows.Forms.TextBox();
            this.txtLotes9 = new System.Windows.Forms.TextBox();
            this.txtLotes8 = new System.Windows.Forms.TextBox();
            this.txtLotes7 = new System.Windows.Forms.TextBox();
            this.txtLotes6 = new System.Windows.Forms.TextBox();
            this.txtLotes4 = new System.Windows.Forms.TextBox();
            this.txtLotes5 = new System.Windows.Forms.TextBox();
            this.txtLotes3 = new System.Windows.Forms.TextBox();
            this.txtLotes2 = new System.Windows.Forms.TextBox();
            this.txtLotes1 = new System.Windows.Forms.TextBox();
            this.txtLotes14 = new System.Windows.Forms.TextBox();
            this.txtLotes15 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.grp16a30 = new System.Windows.Forms.GroupBox();
            this.txtPen17 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtGramas28 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtGramas27 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtGramas26 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtGramas25 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtGramas24 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtGramas23 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtGramas22 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtGramas21 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtGramas19 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtGramas20 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtGramas18 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtGramas17 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtGramas16 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtGramas29 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtGramas30 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtLotes28 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtLotes27 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.txtLotes26 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.txtLotes25 = new System.Windows.Forms.TextBox();
            this.txtPen16 = new System.Windows.Forms.TextBox();
            this.txtLotes24 = new System.Windows.Forms.TextBox();
            this.txtPen18 = new System.Windows.Forms.TextBox();
            this.txtLotes23 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.txtLotes22 = new System.Windows.Forms.TextBox();
            this.txtPen19 = new System.Windows.Forms.TextBox();
            this.txtLotes21 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.txtLotes19 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.txtLotes20 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.txtLotes18 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.txtLotes17 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.txtLotes16 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.txtLotes29 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.txtLotes30 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.grp31a45 = new System.Windows.Forms.GroupBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtGramas43 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtGramas42 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtGramas41 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtGramas40 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtGramas39 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtGramas38 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtGramas37 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtGramas36 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtGramas34 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.txtGramas35 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtGramas33 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtGramas32 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtGramas31 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.txtGramas44 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtGramas45 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txtLotes43 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.txtLotes42 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.txtLotes41 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.txtLotes40 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.txtLotes39 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.txtLotes38 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.txtLotes37 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.txtLotes36 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.txtLotes34 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.txtLotes35 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.txtLotes33 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.txtLotes32 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.txtLotes31 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.txtLotes44 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.txtLotes45 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.btnApagarTudo = new System.Windows.Forms.Button();
            this.btnImprimir = new System.Windows.Forms.Button();
            this.previewPrintLiga = new System.Windows.Forms.PrintPreviewDialog();
            this.printLiga = new System.Drawing.Printing.PrintDocument();
            this.grp1a15.SuspendLayout();
            this.grp16a30.SuspendLayout();
            this.grp31a45.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 371);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Total de Sacas:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 47;
            this.label3.Text = "Lote 12";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 59;
            this.label10.Text = "Lote 15";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(54, 396);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "Gramas:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 263);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 13);
            this.label14.TabIndex = 51;
            this.label14.Text = "Lote 13";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(3, 282);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 13);
            this.label16.TabIndex = 55;
            this.label16.Text = "Lote 14";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(3, 209);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(43, 13);
            this.label26.TabIndex = 39;
            this.label26.Text = "Lote 10";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(3, 190);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(37, 13);
            this.label27.TabIndex = 35;
            this.label27.Text = "Lote 9";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(3, 136);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(37, 13);
            this.label28.TabIndex = 23;
            this.label28.Text = "Lote 6";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(3, 171);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(37, 13);
            this.label32.TabIndex = 31;
            this.label32.Text = "Lote 8";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(3, 81);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(37, 13);
            this.label33.TabIndex = 8;
            this.label33.Text = "Lote 3";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(3, 154);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(37, 13);
            this.label39.TabIndex = 27;
            this.label39.Text = "Lote 7";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(3, 117);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(37, 13);
            this.label40.TabIndex = 19;
            this.label40.Text = "Lote 5";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(3, 98);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(37, 13);
            this.label41.TabIndex = 15;
            this.label41.Text = "Lote 4";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(3, 63);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(37, 13);
            this.label43.TabIndex = 4;
            this.label43.Text = "Lote 2";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(3, 44);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(37, 13);
            this.label44.TabIndex = 0;
            this.label44.Text = "Lote 1";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(143, 25);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(43, 13);
            this.label46.TabIndex = 3;
            this.label46.Text = "Gramas";
            this.label46.UseWaitCursor = true;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(100, 25);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(37, 13);
            this.label48.TabIndex = 2;
            this.label48.Text = "Sacas";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(54, 25);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(19, 13);
            this.label49.TabIndex = 1;
            this.label49.Text = "Nº";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(3, 228);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(43, 13);
            this.label50.TabIndex = 43;
            this.label50.Text = "Lote 11";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(12, 9);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(88, 13);
            this.label52.TabIndex = 0;
            this.label52.Text = "Número de Vias: ";
            // 
            // txtNVias
            // 
            this.txtNVias.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNVias.Location = new System.Drawing.Point(97, 6);
            this.txtNVias.Name = "txtNVias";
            this.txtNVias.Size = new System.Drawing.Size(51, 20);
            this.txtNVias.TabIndex = 1;
            this.txtNVias.Text = "0";
            this.txtNVias.TextChanged += new System.EventHandler(this.txtNVias_TextChanged);
            // 
            // txtPen15
            // 
            this.txtPen15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen15.ForeColor = System.Drawing.Color.Blue;
            this.txtPen15.Location = new System.Drawing.Point(57, 296);
            this.txtPen15.Name = "txtPen15";
            this.txtPen15.Size = new System.Drawing.Size(37, 20);
            this.txtPen15.TabIndex = 60;
            this.txtPen15.Text = "0";
            this.txtPen15.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // txtPen14
            // 
            this.txtPen14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen14.ForeColor = System.Drawing.Color.Blue;
            this.txtPen14.Location = new System.Drawing.Point(57, 279);
            this.txtPen14.Name = "txtPen14";
            this.txtPen14.Size = new System.Drawing.Size(37, 20);
            this.txtPen14.TabIndex = 56;
            this.txtPen14.Text = "0";
            // 
            // txtPen1
            // 
            this.txtPen1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen1.ForeColor = System.Drawing.Color.Blue;
            this.txtPen1.Location = new System.Drawing.Point(57, 41);
            this.txtPen1.Name = "txtPen1";
            this.txtPen1.Size = new System.Drawing.Size(37, 20);
            this.txtPen1.TabIndex = 5;
            this.txtPen1.Text = "0";
            // 
            // txtPen2
            // 
            this.txtPen2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen2.ForeColor = System.Drawing.Color.Blue;
            this.txtPen2.Location = new System.Drawing.Point(57, 60);
            this.txtPen2.Name = "txtPen2";
            this.txtPen2.Size = new System.Drawing.Size(37, 20);
            this.txtPen2.TabIndex = 9;
            this.txtPen2.Text = "0";
            // 
            // txtPen3
            // 
            this.txtPen3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen3.ForeColor = System.Drawing.Color.Blue;
            this.txtPen3.Location = new System.Drawing.Point(57, 78);
            this.txtPen3.Name = "txtPen3";
            this.txtPen3.Size = new System.Drawing.Size(37, 20);
            this.txtPen3.TabIndex = 12;
            this.txtPen3.Text = "0";
            // 
            // txtPen5
            // 
            this.txtPen5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen5.ForeColor = System.Drawing.Color.Blue;
            this.txtPen5.Location = new System.Drawing.Point(57, 114);
            this.txtPen5.Name = "txtPen5";
            this.txtPen5.Size = new System.Drawing.Size(37, 20);
            this.txtPen5.TabIndex = 20;
            this.txtPen5.Text = "0";
            // 
            // txtPen4
            // 
            this.txtPen4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen4.ForeColor = System.Drawing.Color.Blue;
            this.txtPen4.Location = new System.Drawing.Point(57, 95);
            this.txtPen4.Name = "txtPen4";
            this.txtPen4.Size = new System.Drawing.Size(37, 20);
            this.txtPen4.TabIndex = 16;
            this.txtPen4.Text = "0";
            // 
            // txtPen6
            // 
            this.txtPen6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen6.ForeColor = System.Drawing.Color.Blue;
            this.txtPen6.Location = new System.Drawing.Point(57, 133);
            this.txtPen6.Name = "txtPen6";
            this.txtPen6.Size = new System.Drawing.Size(37, 20);
            this.txtPen6.TabIndex = 24;
            this.txtPen6.Text = "0";
            // 
            // txtPen7
            // 
            this.txtPen7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen7.ForeColor = System.Drawing.Color.Blue;
            this.txtPen7.Location = new System.Drawing.Point(57, 151);
            this.txtPen7.Name = "txtPen7";
            this.txtPen7.Size = new System.Drawing.Size(37, 20);
            this.txtPen7.TabIndex = 28;
            this.txtPen7.Text = "0";
            // 
            // txtPen8
            // 
            this.txtPen8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen8.ForeColor = System.Drawing.Color.Blue;
            this.txtPen8.Location = new System.Drawing.Point(57, 168);
            this.txtPen8.Name = "txtPen8";
            this.txtPen8.Size = new System.Drawing.Size(37, 20);
            this.txtPen8.TabIndex = 32;
            this.txtPen8.Text = "0";
            this.txtPen8.TextChanged += new System.EventHandler(this.textBox35_TextChanged);
            // 
            // txtPen9
            // 
            this.txtPen9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen9.ForeColor = System.Drawing.Color.Blue;
            this.txtPen9.Location = new System.Drawing.Point(57, 187);
            this.txtPen9.Name = "txtPen9";
            this.txtPen9.Size = new System.Drawing.Size(37, 20);
            this.txtPen9.TabIndex = 36;
            this.txtPen9.Text = "0";
            // 
            // txtPen10
            // 
            this.txtPen10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen10.ForeColor = System.Drawing.Color.Blue;
            this.txtPen10.Location = new System.Drawing.Point(57, 206);
            this.txtPen10.Name = "txtPen10";
            this.txtPen10.Size = new System.Drawing.Size(37, 20);
            this.txtPen10.TabIndex = 40;
            this.txtPen10.Text = "0";
            // 
            // txtPen11
            // 
            this.txtPen11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen11.ForeColor = System.Drawing.Color.Blue;
            this.txtPen11.Location = new System.Drawing.Point(57, 225);
            this.txtPen11.Name = "txtPen11";
            this.txtPen11.Size = new System.Drawing.Size(37, 20);
            this.txtPen11.TabIndex = 44;
            this.txtPen11.Text = "0";
            // 
            // txtPen12
            // 
            this.txtPen12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen12.ForeColor = System.Drawing.Color.Blue;
            this.txtPen12.Location = new System.Drawing.Point(57, 243);
            this.txtPen12.Name = "txtPen12";
            this.txtPen12.Size = new System.Drawing.Size(37, 20);
            this.txtPen12.TabIndex = 48;
            this.txtPen12.Text = "0";
            // 
            // txtPen13
            // 
            this.txtPen13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPen13.ForeColor = System.Drawing.Color.Blue;
            this.txtPen13.Location = new System.Drawing.Point(57, 260);
            this.txtPen13.Name = "txtPen13";
            this.txtPen13.Size = new System.Drawing.Size(37, 20);
            this.txtPen13.TabIndex = 52;
            this.txtPen13.Text = "0";
            // 
            // txtTotSacas
            // 
            this.txtTotSacas.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtTotSacas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotSacas.Location = new System.Drawing.Point(106, 368);
            this.txtTotSacas.Name = "txtTotSacas";
            this.txtTotSacas.ReadOnly = true;
            this.txtTotSacas.Size = new System.Drawing.Size(61, 20);
            this.txtTotSacas.TabIndex = 6;
            this.txtTotSacas.TabStop = false;
            // 
            // txtTotGramas
            // 
            this.txtTotGramas.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtTotGramas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotGramas.Location = new System.Drawing.Point(106, 393);
            this.txtTotGramas.Name = "txtTotGramas";
            this.txtTotGramas.ReadOnly = true;
            this.txtTotGramas.Size = new System.Drawing.Size(61, 20);
            this.txtTotGramas.TabIndex = 8;
            this.txtTotGramas.TabStop = false;
            // 
            // grp1a15
            // 
            this.grp1a15.Controls.Add(this.txtPen2);
            this.grp1a15.Controls.Add(this.label3);
            this.grp1a15.Controls.Add(this.label10);
            this.grp1a15.Controls.Add(this.txtGramas13);
            this.grp1a15.Controls.Add(this.label14);
            this.grp1a15.Controls.Add(this.txtGramas12);
            this.grp1a15.Controls.Add(this.label16);
            this.grp1a15.Controls.Add(this.txtGramas11);
            this.grp1a15.Controls.Add(this.label26);
            this.grp1a15.Controls.Add(this.txtGramas10);
            this.grp1a15.Controls.Add(this.label27);
            this.grp1a15.Controls.Add(this.txtGramas9);
            this.grp1a15.Controls.Add(this.label28);
            this.grp1a15.Controls.Add(this.txtGramas8);
            this.grp1a15.Controls.Add(this.label32);
            this.grp1a15.Controls.Add(this.txtGramas7);
            this.grp1a15.Controls.Add(this.label33);
            this.grp1a15.Controls.Add(this.txtGramas6);
            this.grp1a15.Controls.Add(this.label39);
            this.grp1a15.Controls.Add(this.txtGramas4);
            this.grp1a15.Controls.Add(this.label40);
            this.grp1a15.Controls.Add(this.txtGramas5);
            this.grp1a15.Controls.Add(this.label41);
            this.grp1a15.Controls.Add(this.txtGramas3);
            this.grp1a15.Controls.Add(this.label43);
            this.grp1a15.Controls.Add(this.txtGramas2);
            this.grp1a15.Controls.Add(this.label44);
            this.grp1a15.Controls.Add(this.txtGramas1);
            this.grp1a15.Controls.Add(this.label46);
            this.grp1a15.Controls.Add(this.txtGramas14);
            this.grp1a15.Controls.Add(this.label48);
            this.grp1a15.Controls.Add(this.txtGramas15);
            this.grp1a15.Controls.Add(this.label49);
            this.grp1a15.Controls.Add(this.txtLotes13);
            this.grp1a15.Controls.Add(this.label50);
            this.grp1a15.Controls.Add(this.txtLotes12);
            this.grp1a15.Controls.Add(this.txtPen15);
            this.grp1a15.Controls.Add(this.txtLotes11);
            this.grp1a15.Controls.Add(this.txtPen14);
            this.grp1a15.Controls.Add(this.txtLotes10);
            this.grp1a15.Controls.Add(this.txtPen1);
            this.grp1a15.Controls.Add(this.txtLotes9);
            this.grp1a15.Controls.Add(this.txtPen3);
            this.grp1a15.Controls.Add(this.txtLotes8);
            this.grp1a15.Controls.Add(this.txtPen5);
            this.grp1a15.Controls.Add(this.txtLotes7);
            this.grp1a15.Controls.Add(this.txtPen4);
            this.grp1a15.Controls.Add(this.txtLotes6);
            this.grp1a15.Controls.Add(this.txtPen6);
            this.grp1a15.Controls.Add(this.txtLotes4);
            this.grp1a15.Controls.Add(this.txtPen7);
            this.grp1a15.Controls.Add(this.txtLotes5);
            this.grp1a15.Controls.Add(this.txtPen8);
            this.grp1a15.Controls.Add(this.txtLotes3);
            this.grp1a15.Controls.Add(this.txtPen9);
            this.grp1a15.Controls.Add(this.txtLotes2);
            this.grp1a15.Controls.Add(this.txtPen10);
            this.grp1a15.Controls.Add(this.txtLotes1);
            this.grp1a15.Controls.Add(this.txtPen11);
            this.grp1a15.Controls.Add(this.txtLotes14);
            this.grp1a15.Controls.Add(this.txtPen12);
            this.grp1a15.Controls.Add(this.txtLotes15);
            this.grp1a15.Controls.Add(this.txtPen13);
            this.grp1a15.Location = new System.Drawing.Point(15, 35);
            this.grp1a15.Name = "grp1a15";
            this.grp1a15.Size = new System.Drawing.Size(207, 327);
            this.grp1a15.TabIndex = 2;
            this.grp1a15.TabStop = false;
            this.grp1a15.Text = "Lotes de 1 a 15";
            // 
            // txtGramas13
            // 
            this.txtGramas13.AllowDrop = true;
            this.txtGramas13.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas13.CausesValidation = false;
            this.txtGramas13.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas13.HideSelection = false;
            this.txtGramas13.Location = new System.Drawing.Point(143, 260);
            this.txtGramas13.Name = "txtGramas13";
            this.txtGramas13.ReadOnly = true;
            this.txtGramas13.Size = new System.Drawing.Size(58, 20);
            this.txtGramas13.TabIndex = 54;
            this.txtGramas13.TabStop = false;
            this.txtGramas13.Text = "0";
            this.txtGramas13.UseWaitCursor = true;
            // 
            // txtGramas12
            // 
            this.txtGramas12.AllowDrop = true;
            this.txtGramas12.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas12.CausesValidation = false;
            this.txtGramas12.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas12.HideSelection = false;
            this.txtGramas12.Location = new System.Drawing.Point(143, 243);
            this.txtGramas12.Name = "txtGramas12";
            this.txtGramas12.ReadOnly = true;
            this.txtGramas12.Size = new System.Drawing.Size(58, 20);
            this.txtGramas12.TabIndex = 50;
            this.txtGramas12.TabStop = false;
            this.txtGramas12.Text = "0";
            this.txtGramas12.UseWaitCursor = true;
            // 
            // txtGramas11
            // 
            this.txtGramas11.AllowDrop = true;
            this.txtGramas11.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas11.CausesValidation = false;
            this.txtGramas11.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas11.HideSelection = false;
            this.txtGramas11.Location = new System.Drawing.Point(143, 225);
            this.txtGramas11.Name = "txtGramas11";
            this.txtGramas11.ReadOnly = true;
            this.txtGramas11.Size = new System.Drawing.Size(58, 20);
            this.txtGramas11.TabIndex = 46;
            this.txtGramas11.TabStop = false;
            this.txtGramas11.Text = "0";
            this.txtGramas11.UseWaitCursor = true;
            // 
            // txtGramas10
            // 
            this.txtGramas10.AllowDrop = true;
            this.txtGramas10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas10.CausesValidation = false;
            this.txtGramas10.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas10.HideSelection = false;
            this.txtGramas10.Location = new System.Drawing.Point(143, 206);
            this.txtGramas10.Name = "txtGramas10";
            this.txtGramas10.ReadOnly = true;
            this.txtGramas10.Size = new System.Drawing.Size(58, 20);
            this.txtGramas10.TabIndex = 42;
            this.txtGramas10.TabStop = false;
            this.txtGramas10.Text = "0";
            this.txtGramas10.UseWaitCursor = true;
            // 
            // txtGramas9
            // 
            this.txtGramas9.AllowDrop = true;
            this.txtGramas9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas9.CausesValidation = false;
            this.txtGramas9.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas9.HideSelection = false;
            this.txtGramas9.Location = new System.Drawing.Point(143, 187);
            this.txtGramas9.Name = "txtGramas9";
            this.txtGramas9.ReadOnly = true;
            this.txtGramas9.Size = new System.Drawing.Size(58, 20);
            this.txtGramas9.TabIndex = 38;
            this.txtGramas9.TabStop = false;
            this.txtGramas9.Text = "0";
            this.txtGramas9.UseWaitCursor = true;
            // 
            // txtGramas8
            // 
            this.txtGramas8.AllowDrop = true;
            this.txtGramas8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas8.CausesValidation = false;
            this.txtGramas8.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas8.HideSelection = false;
            this.txtGramas8.Location = new System.Drawing.Point(143, 168);
            this.txtGramas8.Name = "txtGramas8";
            this.txtGramas8.ReadOnly = true;
            this.txtGramas8.Size = new System.Drawing.Size(58, 20);
            this.txtGramas8.TabIndex = 34;
            this.txtGramas8.TabStop = false;
            this.txtGramas8.Text = "0";
            this.txtGramas8.UseWaitCursor = true;
            // 
            // txtGramas7
            // 
            this.txtGramas7.AllowDrop = true;
            this.txtGramas7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas7.CausesValidation = false;
            this.txtGramas7.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas7.HideSelection = false;
            this.txtGramas7.Location = new System.Drawing.Point(143, 151);
            this.txtGramas7.Name = "txtGramas7";
            this.txtGramas7.ReadOnly = true;
            this.txtGramas7.Size = new System.Drawing.Size(58, 20);
            this.txtGramas7.TabIndex = 30;
            this.txtGramas7.TabStop = false;
            this.txtGramas7.Text = "0";
            this.txtGramas7.UseWaitCursor = true;
            // 
            // txtGramas6
            // 
            this.txtGramas6.AllowDrop = true;
            this.txtGramas6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas6.CausesValidation = false;
            this.txtGramas6.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas6.HideSelection = false;
            this.txtGramas6.Location = new System.Drawing.Point(143, 133);
            this.txtGramas6.Name = "txtGramas6";
            this.txtGramas6.ReadOnly = true;
            this.txtGramas6.Size = new System.Drawing.Size(58, 20);
            this.txtGramas6.TabIndex = 26;
            this.txtGramas6.TabStop = false;
            this.txtGramas6.Text = "0";
            this.txtGramas6.UseWaitCursor = true;
            // 
            // txtGramas4
            // 
            this.txtGramas4.AllowDrop = true;
            this.txtGramas4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas4.CausesValidation = false;
            this.txtGramas4.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas4.HideSelection = false;
            this.txtGramas4.Location = new System.Drawing.Point(143, 95);
            this.txtGramas4.Name = "txtGramas4";
            this.txtGramas4.ReadOnly = true;
            this.txtGramas4.Size = new System.Drawing.Size(58, 20);
            this.txtGramas4.TabIndex = 18;
            this.txtGramas4.TabStop = false;
            this.txtGramas4.Text = "0";
            this.txtGramas4.UseWaitCursor = true;
            // 
            // txtGramas5
            // 
            this.txtGramas5.AllowDrop = true;
            this.txtGramas5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas5.CausesValidation = false;
            this.txtGramas5.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas5.HideSelection = false;
            this.txtGramas5.Location = new System.Drawing.Point(143, 114);
            this.txtGramas5.Name = "txtGramas5";
            this.txtGramas5.ReadOnly = true;
            this.txtGramas5.Size = new System.Drawing.Size(58, 20);
            this.txtGramas5.TabIndex = 22;
            this.txtGramas5.TabStop = false;
            this.txtGramas5.Text = "0";
            this.txtGramas5.UseWaitCursor = true;
            // 
            // txtGramas3
            // 
            this.txtGramas3.AllowDrop = true;
            this.txtGramas3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas3.CausesValidation = false;
            this.txtGramas3.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas3.HideSelection = false;
            this.txtGramas3.Location = new System.Drawing.Point(143, 78);
            this.txtGramas3.Name = "txtGramas3";
            this.txtGramas3.ReadOnly = true;
            this.txtGramas3.Size = new System.Drawing.Size(58, 20);
            this.txtGramas3.TabIndex = 14;
            this.txtGramas3.TabStop = false;
            this.txtGramas3.Text = "0";
            this.txtGramas3.UseWaitCursor = true;
            // 
            // txtGramas2
            // 
            this.txtGramas2.AllowDrop = true;
            this.txtGramas2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas2.CausesValidation = false;
            this.txtGramas2.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas2.HideSelection = false;
            this.txtGramas2.Location = new System.Drawing.Point(143, 60);
            this.txtGramas2.Name = "txtGramas2";
            this.txtGramas2.ReadOnly = true;
            this.txtGramas2.Size = new System.Drawing.Size(58, 20);
            this.txtGramas2.TabIndex = 11;
            this.txtGramas2.TabStop = false;
            this.txtGramas2.Text = "0";
            this.txtGramas2.UseWaitCursor = true;
            this.txtGramas2.TextChanged += new System.EventHandler(this.txtGramas2_TextChanged);
            // 
            // txtGramas1
            // 
            this.txtGramas1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas1.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas1.Location = new System.Drawing.Point(143, 41);
            this.txtGramas1.Name = "txtGramas1";
            this.txtGramas1.Size = new System.Drawing.Size(58, 20);
            this.txtGramas1.TabIndex = 7;
            this.txtGramas1.TabStop = false;
            this.txtGramas1.Text = "0";
            this.txtGramas1.UseWaitCursor = true;
            this.txtGramas1.TextChanged += new System.EventHandler(this.txtGramas1_TextChanged);
            // 
            // txtGramas14
            // 
            this.txtGramas14.AllowDrop = true;
            this.txtGramas14.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas14.CausesValidation = false;
            this.txtGramas14.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas14.HideSelection = false;
            this.txtGramas14.Location = new System.Drawing.Point(143, 279);
            this.txtGramas14.Name = "txtGramas14";
            this.txtGramas14.ReadOnly = true;
            this.txtGramas14.Size = new System.Drawing.Size(58, 20);
            this.txtGramas14.TabIndex = 58;
            this.txtGramas14.TabStop = false;
            this.txtGramas14.Text = "0";
            this.txtGramas14.UseWaitCursor = true;
            // 
            // txtGramas15
            // 
            this.txtGramas15.AllowDrop = true;
            this.txtGramas15.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas15.CausesValidation = false;
            this.txtGramas15.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.txtGramas15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramas15.HideSelection = false;
            this.txtGramas15.Location = new System.Drawing.Point(143, 296);
            this.txtGramas15.Name = "txtGramas15";
            this.txtGramas15.ReadOnly = true;
            this.txtGramas15.Size = new System.Drawing.Size(58, 20);
            this.txtGramas15.TabIndex = 62;
            this.txtGramas15.TabStop = false;
            this.txtGramas15.Text = "0";
            this.txtGramas15.UseWaitCursor = true;
            // 
            // txtLotes13
            // 
            this.txtLotes13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes13.ForeColor = System.Drawing.Color.Red;
            this.txtLotes13.Location = new System.Drawing.Point(100, 260);
            this.txtLotes13.Name = "txtLotes13";
            this.txtLotes13.Size = new System.Drawing.Size(37, 20);
            this.txtLotes13.TabIndex = 53;
            this.txtLotes13.Text = "0";
            this.txtLotes13.TextChanged += new System.EventHandler(this.txtLotes13_TextChanged);
            // 
            // txtLotes12
            // 
            this.txtLotes12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes12.ForeColor = System.Drawing.Color.Red;
            this.txtLotes12.Location = new System.Drawing.Point(100, 243);
            this.txtLotes12.Name = "txtLotes12";
            this.txtLotes12.Size = new System.Drawing.Size(37, 20);
            this.txtLotes12.TabIndex = 49;
            this.txtLotes12.Text = "0";
            this.txtLotes12.TextChanged += new System.EventHandler(this.txtLotes12_TextChanged);
            // 
            // txtLotes11
            // 
            this.txtLotes11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes11.ForeColor = System.Drawing.Color.Red;
            this.txtLotes11.Location = new System.Drawing.Point(100, 225);
            this.txtLotes11.Name = "txtLotes11";
            this.txtLotes11.Size = new System.Drawing.Size(37, 20);
            this.txtLotes11.TabIndex = 45;
            this.txtLotes11.Text = "0";
            this.txtLotes11.TextChanged += new System.EventHandler(this.txtLotes11_TextChanged);
            // 
            // txtLotes10
            // 
            this.txtLotes10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes10.ForeColor = System.Drawing.Color.Red;
            this.txtLotes10.Location = new System.Drawing.Point(100, 206);
            this.txtLotes10.Name = "txtLotes10";
            this.txtLotes10.Size = new System.Drawing.Size(37, 20);
            this.txtLotes10.TabIndex = 41;
            this.txtLotes10.Text = "0";
            this.txtLotes10.TextChanged += new System.EventHandler(this.txtLotes10_TextChanged);
            // 
            // txtLotes9
            // 
            this.txtLotes9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes9.ForeColor = System.Drawing.Color.Red;
            this.txtLotes9.Location = new System.Drawing.Point(100, 187);
            this.txtLotes9.Name = "txtLotes9";
            this.txtLotes9.Size = new System.Drawing.Size(37, 20);
            this.txtLotes9.TabIndex = 37;
            this.txtLotes9.Text = "0";
            this.txtLotes9.TextChanged += new System.EventHandler(this.txtLotes9_TextChanged);
            // 
            // txtLotes8
            // 
            this.txtLotes8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes8.ForeColor = System.Drawing.Color.Red;
            this.txtLotes8.Location = new System.Drawing.Point(100, 168);
            this.txtLotes8.Name = "txtLotes8";
            this.txtLotes8.Size = new System.Drawing.Size(37, 20);
            this.txtLotes8.TabIndex = 33;
            this.txtLotes8.Text = "0";
            this.txtLotes8.TextChanged += new System.EventHandler(this.txtLotes8_TextChanged);
            // 
            // txtLotes7
            // 
            this.txtLotes7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes7.ForeColor = System.Drawing.Color.Red;
            this.txtLotes7.Location = new System.Drawing.Point(100, 151);
            this.txtLotes7.Name = "txtLotes7";
            this.txtLotes7.Size = new System.Drawing.Size(37, 20);
            this.txtLotes7.TabIndex = 29;
            this.txtLotes7.Text = "0";
            this.txtLotes7.TextChanged += new System.EventHandler(this.txtLotes7_TextChanged);
            // 
            // txtLotes6
            // 
            this.txtLotes6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes6.ForeColor = System.Drawing.Color.Red;
            this.txtLotes6.Location = new System.Drawing.Point(100, 133);
            this.txtLotes6.Name = "txtLotes6";
            this.txtLotes6.Size = new System.Drawing.Size(37, 20);
            this.txtLotes6.TabIndex = 25;
            this.txtLotes6.Text = "0";
            this.txtLotes6.TextChanged += new System.EventHandler(this.txtLotes6_TextChanged);
            // 
            // txtLotes4
            // 
            this.txtLotes4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes4.ForeColor = System.Drawing.Color.Red;
            this.txtLotes4.Location = new System.Drawing.Point(100, 95);
            this.txtLotes4.Name = "txtLotes4";
            this.txtLotes4.Size = new System.Drawing.Size(37, 20);
            this.txtLotes4.TabIndex = 17;
            this.txtLotes4.Text = "0";
            this.txtLotes4.TextChanged += new System.EventHandler(this.txtLotes4_TextChanged);
            // 
            // txtLotes5
            // 
            this.txtLotes5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes5.ForeColor = System.Drawing.Color.Red;
            this.txtLotes5.Location = new System.Drawing.Point(100, 114);
            this.txtLotes5.Name = "txtLotes5";
            this.txtLotes5.Size = new System.Drawing.Size(37, 20);
            this.txtLotes5.TabIndex = 21;
            this.txtLotes5.Text = "0";
            this.txtLotes5.TextChanged += new System.EventHandler(this.txtLotes5_TextChanged);
            // 
            // txtLotes3
            // 
            this.txtLotes3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes3.ForeColor = System.Drawing.Color.Red;
            this.txtLotes3.Location = new System.Drawing.Point(100, 78);
            this.txtLotes3.Name = "txtLotes3";
            this.txtLotes3.Size = new System.Drawing.Size(37, 20);
            this.txtLotes3.TabIndex = 13;
            this.txtLotes3.Text = "0";
            this.txtLotes3.TextChanged += new System.EventHandler(this.txtLotes3_TextChanged);
            // 
            // txtLotes2
            // 
            this.txtLotes2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes2.ForeColor = System.Drawing.Color.Red;
            this.txtLotes2.Location = new System.Drawing.Point(100, 60);
            this.txtLotes2.Name = "txtLotes2";
            this.txtLotes2.Size = new System.Drawing.Size(37, 20);
            this.txtLotes2.TabIndex = 10;
            this.txtLotes2.Text = "0";
            this.txtLotes2.TextChanged += new System.EventHandler(this.txtLotes2_TextChanged);
            // 
            // txtLotes1
            // 
            this.txtLotes1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes1.ForeColor = System.Drawing.Color.Red;
            this.txtLotes1.Location = new System.Drawing.Point(100, 41);
            this.txtLotes1.Name = "txtLotes1";
            this.txtLotes1.Size = new System.Drawing.Size(37, 20);
            this.txtLotes1.TabIndex = 6;
            this.txtLotes1.Text = "0";
            this.txtLotes1.TextChanged += new System.EventHandler(this.txtLotes1_TextChanged);
            // 
            // txtLotes14
            // 
            this.txtLotes14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes14.ForeColor = System.Drawing.Color.Red;
            this.txtLotes14.Location = new System.Drawing.Point(100, 279);
            this.txtLotes14.Name = "txtLotes14";
            this.txtLotes14.Size = new System.Drawing.Size(37, 20);
            this.txtLotes14.TabIndex = 57;
            this.txtLotes14.Text = "0";
            this.txtLotes14.TextChanged += new System.EventHandler(this.txtLotes14_TextChanged);
            // 
            // txtLotes15
            // 
            this.txtLotes15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLotes15.ForeColor = System.Drawing.Color.Red;
            this.txtLotes15.Location = new System.Drawing.Point(100, 296);
            this.txtLotes15.Name = "txtLotes15";
            this.txtLotes15.Size = new System.Drawing.Size(37, 20);
            this.txtLotes15.TabIndex = 61;
            this.txtLotes15.Text = "0";
            this.txtLotes15.TextChanged += new System.EventHandler(this.txtLotes15_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(183, 371);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "&Resultado";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // grp16a30
            // 
            this.grp16a30.Controls.Add(this.txtPen17);
            this.grp16a30.Controls.Add(this.label2);
            this.grp16a30.Controls.Add(this.label4);
            this.grp16a30.Controls.Add(this.txtGramas28);
            this.grp16a30.Controls.Add(this.label5);
            this.grp16a30.Controls.Add(this.txtGramas27);
            this.grp16a30.Controls.Add(this.label6);
            this.grp16a30.Controls.Add(this.txtGramas26);
            this.grp16a30.Controls.Add(this.label7);
            this.grp16a30.Controls.Add(this.txtGramas25);
            this.grp16a30.Controls.Add(this.label8);
            this.grp16a30.Controls.Add(this.txtGramas24);
            this.grp16a30.Controls.Add(this.label9);
            this.grp16a30.Controls.Add(this.txtGramas23);
            this.grp16a30.Controls.Add(this.label11);
            this.grp16a30.Controls.Add(this.txtGramas22);
            this.grp16a30.Controls.Add(this.label12);
            this.grp16a30.Controls.Add(this.txtGramas21);
            this.grp16a30.Controls.Add(this.label15);
            this.grp16a30.Controls.Add(this.txtGramas19);
            this.grp16a30.Controls.Add(this.label17);
            this.grp16a30.Controls.Add(this.txtGramas20);
            this.grp16a30.Controls.Add(this.label18);
            this.grp16a30.Controls.Add(this.txtGramas18);
            this.grp16a30.Controls.Add(this.label19);
            this.grp16a30.Controls.Add(this.txtGramas17);
            this.grp16a30.Controls.Add(this.label20);
            this.grp16a30.Controls.Add(this.txtGramas16);
            this.grp16a30.Controls.Add(this.label21);
            this.grp16a30.Controls.Add(this.txtGramas29);
            this.grp16a30.Controls.Add(this.label22);
            this.grp16a30.Controls.Add(this.txtGramas30);
            this.grp16a30.Controls.Add(this.label23);
            this.grp16a30.Controls.Add(this.txtLotes28);
            this.grp16a30.Controls.Add(this.label24);
            this.grp16a30.Controls.Add(this.txtLotes27);
            this.grp16a30.Controls.Add(this.textBox19);
            this.grp16a30.Controls.Add(this.txtLotes26);
            this.grp16a30.Controls.Add(this.textBox21);
            this.grp16a30.Controls.Add(this.txtLotes25);
            this.grp16a30.Controls.Add(this.txtPen16);
            this.grp16a30.Controls.Add(this.txtLotes24);
            this.grp16a30.Controls.Add(this.txtPen18);
            this.grp16a30.Controls.Add(this.txtLotes23);
            this.grp16a30.Controls.Add(this.textBox27);
            this.grp16a30.Controls.Add(this.txtLotes22);
            this.grp16a30.Controls.Add(this.txtPen19);
            this.grp16a30.Controls.Add(this.txtLotes21);
            this.grp16a30.Controls.Add(this.textBox31);
            this.grp16a30.Controls.Add(this.txtLotes19);
            this.grp16a30.Controls.Add(this.textBox33);
            this.grp16a30.Controls.Add(this.txtLotes20);
            this.grp16a30.Controls.Add(this.textBox35);
            this.grp16a30.Controls.Add(this.txtLotes18);
            this.grp16a30.Controls.Add(this.textBox37);
            this.grp16a30.Controls.Add(this.txtLotes17);
            this.grp16a30.Controls.Add(this.textBox39);
            this.grp16a30.Controls.Add(this.txtLotes16);
            this.grp16a30.Controls.Add(this.textBox41);
            this.grp16a30.Controls.Add(this.txtLotes29);
            this.grp16a30.Controls.Add(this.textBox43);
            this.grp16a30.Controls.Add(this.txtLotes30);
            this.grp16a30.Controls.Add(this.textBox45);
            this.grp16a30.Location = new System.Drawing.Point(228, 35);
            this.grp16a30.Name = "grp16a30";
            this.grp16a30.Size = new System.Drawing.Size(207, 327);
            this.grp16a30.TabIndex = 3;
            this.grp16a30.TabStop = false;
            this.grp16a30.Text = "Lotes de 16 a 30";
            // 
            // txtPen17
            // 
            this.txtPen17.Location = new System.Drawing.Point(57, 60);
            this.txtPen17.Name = "txtPen17";
            this.txtPen17.Size = new System.Drawing.Size(37, 20);
            this.txtPen17.TabIndex = 8;
            this.txtPen17.TabStop = false;
            this.txtPen17.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 47;
            this.label2.Text = "Lote 27";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 299);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 59;
            this.label4.Text = "Lote 30";
            // 
            // txtGramas28
            // 
            this.txtGramas28.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas28.Enabled = false;
            this.txtGramas28.Location = new System.Drawing.Point(143, 260);
            this.txtGramas28.Name = "txtGramas28";
            this.txtGramas28.ReadOnly = true;
            this.txtGramas28.Size = new System.Drawing.Size(58, 20);
            this.txtGramas28.TabIndex = 54;
            this.txtGramas28.TabStop = false;
            this.txtGramas28.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 263);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 51;
            this.label5.Text = "Lote 28";
            // 
            // txtGramas27
            // 
            this.txtGramas27.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas27.Enabled = false;
            this.txtGramas27.Location = new System.Drawing.Point(143, 243);
            this.txtGramas27.Name = "txtGramas27";
            this.txtGramas27.ReadOnly = true;
            this.txtGramas27.Size = new System.Drawing.Size(58, 20);
            this.txtGramas27.TabIndex = 50;
            this.txtGramas27.TabStop = false;
            this.txtGramas27.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 55;
            this.label6.Text = "Lote 29";
            // 
            // txtGramas26
            // 
            this.txtGramas26.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas26.Enabled = false;
            this.txtGramas26.Location = new System.Drawing.Point(143, 225);
            this.txtGramas26.Name = "txtGramas26";
            this.txtGramas26.ReadOnly = true;
            this.txtGramas26.Size = new System.Drawing.Size(58, 20);
            this.txtGramas26.TabIndex = 46;
            this.txtGramas26.TabStop = false;
            this.txtGramas26.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 209);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 39;
            this.label7.Text = "Lote 25";
            // 
            // txtGramas25
            // 
            this.txtGramas25.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas25.Enabled = false;
            this.txtGramas25.Location = new System.Drawing.Point(143, 206);
            this.txtGramas25.Name = "txtGramas25";
            this.txtGramas25.ReadOnly = true;
            this.txtGramas25.Size = new System.Drawing.Size(58, 20);
            this.txtGramas25.TabIndex = 42;
            this.txtGramas25.TabStop = false;
            this.txtGramas25.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 190);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 35;
            this.label8.Text = "Lote 24";
            // 
            // txtGramas24
            // 
            this.txtGramas24.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas24.Enabled = false;
            this.txtGramas24.Location = new System.Drawing.Point(143, 187);
            this.txtGramas24.Name = "txtGramas24";
            this.txtGramas24.ReadOnly = true;
            this.txtGramas24.Size = new System.Drawing.Size(58, 20);
            this.txtGramas24.TabIndex = 38;
            this.txtGramas24.TabStop = false;
            this.txtGramas24.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Lote 21";
            // 
            // txtGramas23
            // 
            this.txtGramas23.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas23.Enabled = false;
            this.txtGramas23.Location = new System.Drawing.Point(143, 168);
            this.txtGramas23.Name = "txtGramas23";
            this.txtGramas23.ReadOnly = true;
            this.txtGramas23.Size = new System.Drawing.Size(58, 20);
            this.txtGramas23.TabIndex = 34;
            this.txtGramas23.TabStop = false;
            this.txtGramas23.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 171);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 13);
            this.label11.TabIndex = 31;
            this.label11.Text = "Lote 23";
            // 
            // txtGramas22
            // 
            this.txtGramas22.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas22.Enabled = false;
            this.txtGramas22.Location = new System.Drawing.Point(143, 151);
            this.txtGramas22.Name = "txtGramas22";
            this.txtGramas22.ReadOnly = true;
            this.txtGramas22.Size = new System.Drawing.Size(58, 20);
            this.txtGramas22.TabIndex = 30;
            this.txtGramas22.TabStop = false;
            this.txtGramas22.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 81);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Lote 18";
            // 
            // txtGramas21
            // 
            this.txtGramas21.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas21.Enabled = false;
            this.txtGramas21.Location = new System.Drawing.Point(143, 133);
            this.txtGramas21.Name = "txtGramas21";
            this.txtGramas21.ReadOnly = true;
            this.txtGramas21.Size = new System.Drawing.Size(58, 20);
            this.txtGramas21.TabIndex = 26;
            this.txtGramas21.TabStop = false;
            this.txtGramas21.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 154);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 13);
            this.label15.TabIndex = 27;
            this.label15.Text = "Lote 22";
            // 
            // txtGramas19
            // 
            this.txtGramas19.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas19.Enabled = false;
            this.txtGramas19.Location = new System.Drawing.Point(143, 95);
            this.txtGramas19.Name = "txtGramas19";
            this.txtGramas19.ReadOnly = true;
            this.txtGramas19.Size = new System.Drawing.Size(58, 20);
            this.txtGramas19.TabIndex = 18;
            this.txtGramas19.TabStop = false;
            this.txtGramas19.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 117);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 13);
            this.label17.TabIndex = 19;
            this.label17.Text = "Lote 20";
            // 
            // txtGramas20
            // 
            this.txtGramas20.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas20.Enabled = false;
            this.txtGramas20.Location = new System.Drawing.Point(143, 114);
            this.txtGramas20.Name = "txtGramas20";
            this.txtGramas20.ReadOnly = true;
            this.txtGramas20.Size = new System.Drawing.Size(58, 20);
            this.txtGramas20.TabIndex = 22;
            this.txtGramas20.TabStop = false;
            this.txtGramas20.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 98);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 13);
            this.label18.TabIndex = 15;
            this.label18.Text = "Lote 19";
            // 
            // txtGramas18
            // 
            this.txtGramas18.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas18.Enabled = false;
            this.txtGramas18.Location = new System.Drawing.Point(143, 78);
            this.txtGramas18.Name = "txtGramas18";
            this.txtGramas18.ReadOnly = true;
            this.txtGramas18.Size = new System.Drawing.Size(58, 20);
            this.txtGramas18.TabIndex = 14;
            this.txtGramas18.TabStop = false;
            this.txtGramas18.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 63);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 13);
            this.label19.TabIndex = 7;
            this.label19.Text = "Lote 17";
            // 
            // txtGramas17
            // 
            this.txtGramas17.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas17.Enabled = false;
            this.txtGramas17.Location = new System.Drawing.Point(143, 60);
            this.txtGramas17.Name = "txtGramas17";
            this.txtGramas17.ReadOnly = true;
            this.txtGramas17.Size = new System.Drawing.Size(58, 20);
            this.txtGramas17.TabIndex = 10;
            this.txtGramas17.TabStop = false;
            this.txtGramas17.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(3, 44);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "Lote 16";
            // 
            // txtGramas16
            // 
            this.txtGramas16.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas16.Enabled = false;
            this.txtGramas16.Location = new System.Drawing.Point(143, 41);
            this.txtGramas16.Name = "txtGramas16";
            this.txtGramas16.ReadOnly = true;
            this.txtGramas16.Size = new System.Drawing.Size(58, 20);
            this.txtGramas16.TabIndex = 6;
            this.txtGramas16.TabStop = false;
            this.txtGramas16.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(143, 25);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Gramas";
            // 
            // txtGramas29
            // 
            this.txtGramas29.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas29.Enabled = false;
            this.txtGramas29.Location = new System.Drawing.Point(143, 279);
            this.txtGramas29.Name = "txtGramas29";
            this.txtGramas29.ReadOnly = true;
            this.txtGramas29.Size = new System.Drawing.Size(58, 20);
            this.txtGramas29.TabIndex = 58;
            this.txtGramas29.TabStop = false;
            this.txtGramas29.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(100, 25);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(37, 13);
            this.label22.TabIndex = 2;
            this.label22.Text = "Sacas";
            // 
            // txtGramas30
            // 
            this.txtGramas30.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas30.Enabled = false;
            this.txtGramas30.Location = new System.Drawing.Point(143, 296);
            this.txtGramas30.Name = "txtGramas30";
            this.txtGramas30.ReadOnly = true;
            this.txtGramas30.Size = new System.Drawing.Size(58, 20);
            this.txtGramas30.TabIndex = 62;
            this.txtGramas30.TabStop = false;
            this.txtGramas30.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(54, 25);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 13);
            this.label23.TabIndex = 1;
            this.label23.Text = "Pen.";
            // 
            // txtLotes28
            // 
            this.txtLotes28.Location = new System.Drawing.Point(100, 260);
            this.txtLotes28.Name = "txtLotes28";
            this.txtLotes28.Size = new System.Drawing.Size(37, 20);
            this.txtLotes28.TabIndex = 53;
            this.txtLotes28.Text = "0";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(3, 228);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(43, 13);
            this.label24.TabIndex = 43;
            this.label24.Text = "Lote 26";
            // 
            // txtLotes27
            // 
            this.txtLotes27.Location = new System.Drawing.Point(100, 243);
            this.txtLotes27.Name = "txtLotes27";
            this.txtLotes27.Size = new System.Drawing.Size(37, 20);
            this.txtLotes27.TabIndex = 49;
            this.txtLotes27.Text = "0";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(57, 296);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(37, 20);
            this.textBox19.TabIndex = 60;
            this.textBox19.TabStop = false;
            this.textBox19.Text = "0";
            // 
            // txtLotes26
            // 
            this.txtLotes26.Location = new System.Drawing.Point(100, 225);
            this.txtLotes26.Name = "txtLotes26";
            this.txtLotes26.Size = new System.Drawing.Size(37, 20);
            this.txtLotes26.TabIndex = 45;
            this.txtLotes26.Text = "0";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(57, 279);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(37, 20);
            this.textBox21.TabIndex = 56;
            this.textBox21.TabStop = false;
            this.textBox21.Text = "0";
            // 
            // txtLotes25
            // 
            this.txtLotes25.Location = new System.Drawing.Point(100, 206);
            this.txtLotes25.Name = "txtLotes25";
            this.txtLotes25.Size = new System.Drawing.Size(37, 20);
            this.txtLotes25.TabIndex = 41;
            this.txtLotes25.Text = "0";
            // 
            // txtPen16
            // 
            this.txtPen16.Location = new System.Drawing.Point(57, 41);
            this.txtPen16.Name = "txtPen16";
            this.txtPen16.Size = new System.Drawing.Size(37, 20);
            this.txtPen16.TabIndex = 4;
            this.txtPen16.TabStop = false;
            this.txtPen16.Text = "0";
            // 
            // txtLotes24
            // 
            this.txtLotes24.Location = new System.Drawing.Point(100, 187);
            this.txtLotes24.Name = "txtLotes24";
            this.txtLotes24.Size = new System.Drawing.Size(37, 20);
            this.txtLotes24.TabIndex = 37;
            this.txtLotes24.Text = "0";
            // 
            // txtPen18
            // 
            this.txtPen18.Location = new System.Drawing.Point(57, 78);
            this.txtPen18.Name = "txtPen18";
            this.txtPen18.Size = new System.Drawing.Size(37, 20);
            this.txtPen18.TabIndex = 12;
            this.txtPen18.TabStop = false;
            this.txtPen18.Text = "0";
            // 
            // txtLotes23
            // 
            this.txtLotes23.Location = new System.Drawing.Point(100, 168);
            this.txtLotes23.Name = "txtLotes23";
            this.txtLotes23.Size = new System.Drawing.Size(37, 20);
            this.txtLotes23.TabIndex = 33;
            this.txtLotes23.Text = "0";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(57, 114);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(37, 20);
            this.textBox27.TabIndex = 20;
            this.textBox27.TabStop = false;
            this.textBox27.Text = "0";
            // 
            // txtLotes22
            // 
            this.txtLotes22.Location = new System.Drawing.Point(100, 151);
            this.txtLotes22.Name = "txtLotes22";
            this.txtLotes22.Size = new System.Drawing.Size(37, 20);
            this.txtLotes22.TabIndex = 29;
            this.txtLotes22.Text = "0";
            // 
            // txtPen19
            // 
            this.txtPen19.Location = new System.Drawing.Point(57, 95);
            this.txtPen19.Name = "txtPen19";
            this.txtPen19.Size = new System.Drawing.Size(37, 20);
            this.txtPen19.TabIndex = 16;
            this.txtPen19.TabStop = false;
            this.txtPen19.Text = "0";
            // 
            // txtLotes21
            // 
            this.txtLotes21.Location = new System.Drawing.Point(100, 133);
            this.txtLotes21.Name = "txtLotes21";
            this.txtLotes21.Size = new System.Drawing.Size(37, 20);
            this.txtLotes21.TabIndex = 25;
            this.txtLotes21.Text = "0";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(57, 133);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(37, 20);
            this.textBox31.TabIndex = 24;
            this.textBox31.TabStop = false;
            this.textBox31.Text = "0";
            // 
            // txtLotes19
            // 
            this.txtLotes19.Location = new System.Drawing.Point(100, 95);
            this.txtLotes19.Name = "txtLotes19";
            this.txtLotes19.Size = new System.Drawing.Size(37, 20);
            this.txtLotes19.TabIndex = 17;
            this.txtLotes19.Text = "0";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(57, 151);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(37, 20);
            this.textBox33.TabIndex = 28;
            this.textBox33.TabStop = false;
            this.textBox33.Text = "0";
            // 
            // txtLotes20
            // 
            this.txtLotes20.Location = new System.Drawing.Point(100, 114);
            this.txtLotes20.Name = "txtLotes20";
            this.txtLotes20.Size = new System.Drawing.Size(37, 20);
            this.txtLotes20.TabIndex = 21;
            this.txtLotes20.Text = "0";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(57, 168);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(37, 20);
            this.textBox35.TabIndex = 32;
            this.textBox35.TabStop = false;
            this.textBox35.Text = "0";
            // 
            // txtLotes18
            // 
            this.txtLotes18.Location = new System.Drawing.Point(100, 78);
            this.txtLotes18.Name = "txtLotes18";
            this.txtLotes18.Size = new System.Drawing.Size(37, 20);
            this.txtLotes18.TabIndex = 13;
            this.txtLotes18.Text = "0";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(57, 187);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(37, 20);
            this.textBox37.TabIndex = 36;
            this.textBox37.TabStop = false;
            this.textBox37.Text = "0";
            // 
            // txtLotes17
            // 
            this.txtLotes17.Location = new System.Drawing.Point(100, 60);
            this.txtLotes17.Name = "txtLotes17";
            this.txtLotes17.Size = new System.Drawing.Size(37, 20);
            this.txtLotes17.TabIndex = 9;
            this.txtLotes17.Text = "0";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(57, 206);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(37, 20);
            this.textBox39.TabIndex = 40;
            this.textBox39.TabStop = false;
            this.textBox39.Text = "0";
            // 
            // txtLotes16
            // 
            this.txtLotes16.Location = new System.Drawing.Point(100, 41);
            this.txtLotes16.Name = "txtLotes16";
            this.txtLotes16.Size = new System.Drawing.Size(37, 20);
            this.txtLotes16.TabIndex = 5;
            this.txtLotes16.Text = "0";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(57, 225);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(37, 20);
            this.textBox41.TabIndex = 44;
            this.textBox41.TabStop = false;
            this.textBox41.Text = "0";
            // 
            // txtLotes29
            // 
            this.txtLotes29.Location = new System.Drawing.Point(100, 279);
            this.txtLotes29.Name = "txtLotes29";
            this.txtLotes29.Size = new System.Drawing.Size(37, 20);
            this.txtLotes29.TabIndex = 57;
            this.txtLotes29.Text = "0";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(57, 243);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(37, 20);
            this.textBox43.TabIndex = 48;
            this.textBox43.TabStop = false;
            this.textBox43.Text = "0";
            // 
            // txtLotes30
            // 
            this.txtLotes30.Location = new System.Drawing.Point(100, 296);
            this.txtLotes30.Name = "txtLotes30";
            this.txtLotes30.Size = new System.Drawing.Size(37, 20);
            this.txtLotes30.TabIndex = 61;
            this.txtLotes30.Text = "0";
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(57, 260);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(37, 20);
            this.textBox45.TabIndex = 52;
            this.textBox45.TabStop = false;
            this.textBox45.Text = "0";
            // 
            // grp31a45
            // 
            this.grp31a45.Controls.Add(this.textBox46);
            this.grp31a45.Controls.Add(this.label25);
            this.grp31a45.Controls.Add(this.label29);
            this.grp31a45.Controls.Add(this.txtGramas43);
            this.grp31a45.Controls.Add(this.label30);
            this.grp31a45.Controls.Add(this.txtGramas42);
            this.grp31a45.Controls.Add(this.label31);
            this.grp31a45.Controls.Add(this.txtGramas41);
            this.grp31a45.Controls.Add(this.label34);
            this.grp31a45.Controls.Add(this.txtGramas40);
            this.grp31a45.Controls.Add(this.label35);
            this.grp31a45.Controls.Add(this.txtGramas39);
            this.grp31a45.Controls.Add(this.label36);
            this.grp31a45.Controls.Add(this.txtGramas38);
            this.grp31a45.Controls.Add(this.label37);
            this.grp31a45.Controls.Add(this.txtGramas37);
            this.grp31a45.Controls.Add(this.label38);
            this.grp31a45.Controls.Add(this.txtGramas36);
            this.grp31a45.Controls.Add(this.label42);
            this.grp31a45.Controls.Add(this.txtGramas34);
            this.grp31a45.Controls.Add(this.label45);
            this.grp31a45.Controls.Add(this.txtGramas35);
            this.grp31a45.Controls.Add(this.label47);
            this.grp31a45.Controls.Add(this.txtGramas33);
            this.grp31a45.Controls.Add(this.label51);
            this.grp31a45.Controls.Add(this.txtGramas32);
            this.grp31a45.Controls.Add(this.label53);
            this.grp31a45.Controls.Add(this.txtGramas31);
            this.grp31a45.Controls.Add(this.label54);
            this.grp31a45.Controls.Add(this.txtGramas44);
            this.grp31a45.Controls.Add(this.label55);
            this.grp31a45.Controls.Add(this.txtGramas45);
            this.grp31a45.Controls.Add(this.label56);
            this.grp31a45.Controls.Add(this.txtLotes43);
            this.grp31a45.Controls.Add(this.label57);
            this.grp31a45.Controls.Add(this.txtLotes42);
            this.grp31a45.Controls.Add(this.textBox64);
            this.grp31a45.Controls.Add(this.txtLotes41);
            this.grp31a45.Controls.Add(this.textBox66);
            this.grp31a45.Controls.Add(this.txtLotes40);
            this.grp31a45.Controls.Add(this.textBox68);
            this.grp31a45.Controls.Add(this.txtLotes39);
            this.grp31a45.Controls.Add(this.textBox70);
            this.grp31a45.Controls.Add(this.txtLotes38);
            this.grp31a45.Controls.Add(this.textBox72);
            this.grp31a45.Controls.Add(this.txtLotes37);
            this.grp31a45.Controls.Add(this.textBox74);
            this.grp31a45.Controls.Add(this.txtLotes36);
            this.grp31a45.Controls.Add(this.textBox76);
            this.grp31a45.Controls.Add(this.txtLotes34);
            this.grp31a45.Controls.Add(this.textBox78);
            this.grp31a45.Controls.Add(this.txtLotes35);
            this.grp31a45.Controls.Add(this.textBox80);
            this.grp31a45.Controls.Add(this.txtLotes33);
            this.grp31a45.Controls.Add(this.textBox82);
            this.grp31a45.Controls.Add(this.txtLotes32);
            this.grp31a45.Controls.Add(this.textBox84);
            this.grp31a45.Controls.Add(this.txtLotes31);
            this.grp31a45.Controls.Add(this.textBox86);
            this.grp31a45.Controls.Add(this.txtLotes44);
            this.grp31a45.Controls.Add(this.textBox88);
            this.grp31a45.Controls.Add(this.txtLotes45);
            this.grp31a45.Controls.Add(this.textBox90);
            this.grp31a45.Location = new System.Drawing.Point(441, 35);
            this.grp31a45.Name = "grp31a45";
            this.grp31a45.Size = new System.Drawing.Size(207, 327);
            this.grp31a45.TabIndex = 4;
            this.grp31a45.TabStop = false;
            this.grp31a45.Text = "Lotes de 31 a 45";
            this.grp31a45.Enter += new System.EventHandler(this.grp31a45_Enter);
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(57, 60);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(37, 20);
            this.textBox46.TabIndex = 9;
            this.textBox46.TabStop = false;
            this.textBox46.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(3, 246);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(43, 13);
            this.label25.TabIndex = 47;
            this.label25.Text = "Lote 42";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(3, 299);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(43, 13);
            this.label29.TabIndex = 59;
            this.label29.Text = "Lote 45";
            // 
            // txtGramas43
            // 
            this.txtGramas43.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas43.Location = new System.Drawing.Point(143, 260);
            this.txtGramas43.Name = "txtGramas43";
            this.txtGramas43.ReadOnly = true;
            this.txtGramas43.Size = new System.Drawing.Size(58, 20);
            this.txtGramas43.TabIndex = 54;
            this.txtGramas43.TabStop = false;
            this.txtGramas43.Text = "0";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(3, 263);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(43, 13);
            this.label30.TabIndex = 51;
            this.label30.Text = "Lote 43";
            // 
            // txtGramas42
            // 
            this.txtGramas42.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas42.Location = new System.Drawing.Point(143, 243);
            this.txtGramas42.Name = "txtGramas42";
            this.txtGramas42.ReadOnly = true;
            this.txtGramas42.Size = new System.Drawing.Size(58, 20);
            this.txtGramas42.TabIndex = 50;
            this.txtGramas42.TabStop = false;
            this.txtGramas42.Text = "0";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(3, 282);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(43, 13);
            this.label31.TabIndex = 55;
            this.label31.Text = "Lote 44";
            // 
            // txtGramas41
            // 
            this.txtGramas41.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas41.Location = new System.Drawing.Point(143, 225);
            this.txtGramas41.Name = "txtGramas41";
            this.txtGramas41.ReadOnly = true;
            this.txtGramas41.Size = new System.Drawing.Size(58, 20);
            this.txtGramas41.TabIndex = 46;
            this.txtGramas41.TabStop = false;
            this.txtGramas41.Text = "0";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(3, 209);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(43, 13);
            this.label34.TabIndex = 39;
            this.label34.Text = "Lote 40";
            // 
            // txtGramas40
            // 
            this.txtGramas40.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas40.Location = new System.Drawing.Point(143, 206);
            this.txtGramas40.Name = "txtGramas40";
            this.txtGramas40.ReadOnly = true;
            this.txtGramas40.Size = new System.Drawing.Size(58, 20);
            this.txtGramas40.TabIndex = 42;
            this.txtGramas40.TabStop = false;
            this.txtGramas40.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(3, 190);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(43, 13);
            this.label35.TabIndex = 35;
            this.label35.Text = "Lote 39";
            // 
            // txtGramas39
            // 
            this.txtGramas39.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas39.Location = new System.Drawing.Point(143, 187);
            this.txtGramas39.Name = "txtGramas39";
            this.txtGramas39.ReadOnly = true;
            this.txtGramas39.Size = new System.Drawing.Size(58, 20);
            this.txtGramas39.TabIndex = 38;
            this.txtGramas39.TabStop = false;
            this.txtGramas39.Text = "0";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(3, 136);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(43, 13);
            this.label36.TabIndex = 23;
            this.label36.Text = "Lote 36";
            // 
            // txtGramas38
            // 
            this.txtGramas38.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas38.Location = new System.Drawing.Point(143, 168);
            this.txtGramas38.Name = "txtGramas38";
            this.txtGramas38.ReadOnly = true;
            this.txtGramas38.Size = new System.Drawing.Size(58, 20);
            this.txtGramas38.TabIndex = 34;
            this.txtGramas38.TabStop = false;
            this.txtGramas38.Text = "0";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(3, 171);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(43, 13);
            this.label37.TabIndex = 31;
            this.label37.Text = "Lote 38";
            // 
            // txtGramas37
            // 
            this.txtGramas37.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas37.Location = new System.Drawing.Point(143, 151);
            this.txtGramas37.Name = "txtGramas37";
            this.txtGramas37.ReadOnly = true;
            this.txtGramas37.Size = new System.Drawing.Size(58, 20);
            this.txtGramas37.TabIndex = 30;
            this.txtGramas37.TabStop = false;
            this.txtGramas37.Text = "0";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(3, 81);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(43, 13);
            this.label38.TabIndex = 8;
            this.label38.Text = "Lote 33";
            // 
            // txtGramas36
            // 
            this.txtGramas36.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas36.Location = new System.Drawing.Point(143, 133);
            this.txtGramas36.Name = "txtGramas36";
            this.txtGramas36.ReadOnly = true;
            this.txtGramas36.Size = new System.Drawing.Size(58, 20);
            this.txtGramas36.TabIndex = 26;
            this.txtGramas36.TabStop = false;
            this.txtGramas36.Text = "0";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(3, 154);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(43, 13);
            this.label42.TabIndex = 27;
            this.label42.Text = "Lote 37";
            // 
            // txtGramas34
            // 
            this.txtGramas34.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas34.Location = new System.Drawing.Point(143, 95);
            this.txtGramas34.Name = "txtGramas34";
            this.txtGramas34.ReadOnly = true;
            this.txtGramas34.Size = new System.Drawing.Size(58, 20);
            this.txtGramas34.TabIndex = 18;
            this.txtGramas34.TabStop = false;
            this.txtGramas34.Text = "0";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(3, 117);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(43, 13);
            this.label45.TabIndex = 19;
            this.label45.Text = "Lote 35";
            // 
            // txtGramas35
            // 
            this.txtGramas35.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas35.Location = new System.Drawing.Point(143, 114);
            this.txtGramas35.Name = "txtGramas35";
            this.txtGramas35.ReadOnly = true;
            this.txtGramas35.Size = new System.Drawing.Size(58, 20);
            this.txtGramas35.TabIndex = 22;
            this.txtGramas35.TabStop = false;
            this.txtGramas35.Text = "0";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(3, 98);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(43, 13);
            this.label47.TabIndex = 15;
            this.label47.Text = "Lote 34";
            // 
            // txtGramas33
            // 
            this.txtGramas33.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas33.Location = new System.Drawing.Point(143, 78);
            this.txtGramas33.Name = "txtGramas33";
            this.txtGramas33.ReadOnly = true;
            this.txtGramas33.Size = new System.Drawing.Size(58, 20);
            this.txtGramas33.TabIndex = 14;
            this.txtGramas33.TabStop = false;
            this.txtGramas33.Text = "0";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(3, 63);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(43, 13);
            this.label51.TabIndex = 4;
            this.label51.Text = "Lote 32";
            // 
            // txtGramas32
            // 
            this.txtGramas32.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas32.Location = new System.Drawing.Point(143, 60);
            this.txtGramas32.Name = "txtGramas32";
            this.txtGramas32.ReadOnly = true;
            this.txtGramas32.Size = new System.Drawing.Size(58, 20);
            this.txtGramas32.TabIndex = 11;
            this.txtGramas32.TabStop = false;
            this.txtGramas32.Text = "0";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(3, 44);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(43, 13);
            this.label53.TabIndex = 0;
            this.label53.Text = "Lote 31";
            // 
            // txtGramas31
            // 
            this.txtGramas31.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas31.Location = new System.Drawing.Point(143, 41);
            this.txtGramas31.Name = "txtGramas31";
            this.txtGramas31.ReadOnly = true;
            this.txtGramas31.Size = new System.Drawing.Size(58, 20);
            this.txtGramas31.TabIndex = 7;
            this.txtGramas31.TabStop = false;
            this.txtGramas31.Text = "0";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(143, 25);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(43, 13);
            this.label54.TabIndex = 3;
            this.label54.Text = "Gramas";
            // 
            // txtGramas44
            // 
            this.txtGramas44.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas44.Location = new System.Drawing.Point(143, 279);
            this.txtGramas44.Name = "txtGramas44";
            this.txtGramas44.ReadOnly = true;
            this.txtGramas44.Size = new System.Drawing.Size(58, 20);
            this.txtGramas44.TabIndex = 58;
            this.txtGramas44.TabStop = false;
            this.txtGramas44.Text = "0";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(100, 25);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(37, 13);
            this.label55.TabIndex = 2;
            this.label55.Text = "Sacas";
            // 
            // txtGramas45
            // 
            this.txtGramas45.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtGramas45.Location = new System.Drawing.Point(143, 296);
            this.txtGramas45.Name = "txtGramas45";
            this.txtGramas45.ReadOnly = true;
            this.txtGramas45.Size = new System.Drawing.Size(58, 20);
            this.txtGramas45.TabIndex = 62;
            this.txtGramas45.TabStop = false;
            this.txtGramas45.Text = "0";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(54, 25);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(29, 13);
            this.label56.TabIndex = 1;
            this.label56.Text = "Pen.";
            // 
            // txtLotes43
            // 
            this.txtLotes43.Location = new System.Drawing.Point(100, 260);
            this.txtLotes43.Name = "txtLotes43";
            this.txtLotes43.Size = new System.Drawing.Size(37, 20);
            this.txtLotes43.TabIndex = 53;
            this.txtLotes43.Text = "0";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(3, 228);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(43, 13);
            this.label57.TabIndex = 43;
            this.label57.Text = "Lote 41";
            // 
            // txtLotes42
            // 
            this.txtLotes42.Location = new System.Drawing.Point(100, 243);
            this.txtLotes42.Name = "txtLotes42";
            this.txtLotes42.Size = new System.Drawing.Size(37, 20);
            this.txtLotes42.TabIndex = 49;
            this.txtLotes42.Text = "0";
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(57, 296);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(37, 20);
            this.textBox64.TabIndex = 60;
            this.textBox64.TabStop = false;
            this.textBox64.Text = "0";
            // 
            // txtLotes41
            // 
            this.txtLotes41.Location = new System.Drawing.Point(100, 225);
            this.txtLotes41.Name = "txtLotes41";
            this.txtLotes41.Size = new System.Drawing.Size(37, 20);
            this.txtLotes41.TabIndex = 45;
            this.txtLotes41.Text = "0";
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(57, 279);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(37, 20);
            this.textBox66.TabIndex = 56;
            this.textBox66.TabStop = false;
            this.textBox66.Text = "0";
            // 
            // txtLotes40
            // 
            this.txtLotes40.Location = new System.Drawing.Point(100, 206);
            this.txtLotes40.Name = "txtLotes40";
            this.txtLotes40.Size = new System.Drawing.Size(37, 20);
            this.txtLotes40.TabIndex = 41;
            this.txtLotes40.Text = "0";
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(57, 41);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(37, 20);
            this.textBox68.TabIndex = 5;
            this.textBox68.TabStop = false;
            this.textBox68.Text = "0";
            // 
            // txtLotes39
            // 
            this.txtLotes39.Location = new System.Drawing.Point(100, 187);
            this.txtLotes39.Name = "txtLotes39";
            this.txtLotes39.Size = new System.Drawing.Size(37, 20);
            this.txtLotes39.TabIndex = 37;
            this.txtLotes39.Text = "0";
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(57, 78);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(37, 20);
            this.textBox70.TabIndex = 12;
            this.textBox70.TabStop = false;
            this.textBox70.Text = "0";
            // 
            // txtLotes38
            // 
            this.txtLotes38.Location = new System.Drawing.Point(100, 168);
            this.txtLotes38.Name = "txtLotes38";
            this.txtLotes38.Size = new System.Drawing.Size(37, 20);
            this.txtLotes38.TabIndex = 33;
            this.txtLotes38.Text = "0";
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(57, 114);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(37, 20);
            this.textBox72.TabIndex = 20;
            this.textBox72.TabStop = false;
            this.textBox72.Text = "0";
            // 
            // txtLotes37
            // 
            this.txtLotes37.Location = new System.Drawing.Point(100, 151);
            this.txtLotes37.Name = "txtLotes37";
            this.txtLotes37.Size = new System.Drawing.Size(37, 20);
            this.txtLotes37.TabIndex = 29;
            this.txtLotes37.Text = "0";
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(57, 95);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(37, 20);
            this.textBox74.TabIndex = 16;
            this.textBox74.TabStop = false;
            this.textBox74.Text = "0";
            // 
            // txtLotes36
            // 
            this.txtLotes36.Location = new System.Drawing.Point(100, 133);
            this.txtLotes36.Name = "txtLotes36";
            this.txtLotes36.Size = new System.Drawing.Size(37, 20);
            this.txtLotes36.TabIndex = 25;
            this.txtLotes36.Text = "0";
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(57, 133);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(37, 20);
            this.textBox76.TabIndex = 24;
            this.textBox76.TabStop = false;
            this.textBox76.Text = "0";
            // 
            // txtLotes34
            // 
            this.txtLotes34.Location = new System.Drawing.Point(100, 95);
            this.txtLotes34.Name = "txtLotes34";
            this.txtLotes34.Size = new System.Drawing.Size(37, 20);
            this.txtLotes34.TabIndex = 17;
            this.txtLotes34.Text = "0";
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(57, 151);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(37, 20);
            this.textBox78.TabIndex = 28;
            this.textBox78.TabStop = false;
            this.textBox78.Text = "0";
            // 
            // txtLotes35
            // 
            this.txtLotes35.Location = new System.Drawing.Point(100, 114);
            this.txtLotes35.Name = "txtLotes35";
            this.txtLotes35.Size = new System.Drawing.Size(37, 20);
            this.txtLotes35.TabIndex = 21;
            this.txtLotes35.Text = "0";
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(57, 168);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(37, 20);
            this.textBox80.TabIndex = 32;
            this.textBox80.TabStop = false;
            this.textBox80.Text = "0";
            // 
            // txtLotes33
            // 
            this.txtLotes33.Location = new System.Drawing.Point(100, 78);
            this.txtLotes33.Name = "txtLotes33";
            this.txtLotes33.Size = new System.Drawing.Size(37, 20);
            this.txtLotes33.TabIndex = 13;
            this.txtLotes33.Text = "0";
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(57, 187);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(37, 20);
            this.textBox82.TabIndex = 36;
            this.textBox82.TabStop = false;
            this.textBox82.Text = "0";
            // 
            // txtLotes32
            // 
            this.txtLotes32.Location = new System.Drawing.Point(100, 60);
            this.txtLotes32.Name = "txtLotes32";
            this.txtLotes32.Size = new System.Drawing.Size(37, 20);
            this.txtLotes32.TabIndex = 10;
            this.txtLotes32.Text = "0";
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(57, 206);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(37, 20);
            this.textBox84.TabIndex = 40;
            this.textBox84.TabStop = false;
            this.textBox84.Text = "0";
            // 
            // txtLotes31
            // 
            this.txtLotes31.Location = new System.Drawing.Point(100, 41);
            this.txtLotes31.Name = "txtLotes31";
            this.txtLotes31.Size = new System.Drawing.Size(37, 20);
            this.txtLotes31.TabIndex = 6;
            this.txtLotes31.Text = "0";
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(57, 225);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(37, 20);
            this.textBox86.TabIndex = 44;
            this.textBox86.TabStop = false;
            this.textBox86.Text = "0";
            // 
            // txtLotes44
            // 
            this.txtLotes44.Location = new System.Drawing.Point(100, 279);
            this.txtLotes44.Name = "txtLotes44";
            this.txtLotes44.Size = new System.Drawing.Size(37, 20);
            this.txtLotes44.TabIndex = 57;
            this.txtLotes44.Text = "0";
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(57, 243);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(37, 20);
            this.textBox88.TabIndex = 48;
            this.textBox88.TabStop = false;
            this.textBox88.Text = "0";
            // 
            // txtLotes45
            // 
            this.txtLotes45.Location = new System.Drawing.Point(100, 296);
            this.txtLotes45.Name = "txtLotes45";
            this.txtLotes45.Size = new System.Drawing.Size(37, 20);
            this.txtLotes45.TabIndex = 61;
            this.txtLotes45.Text = "0";
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(57, 260);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(37, 20);
            this.textBox90.TabIndex = 52;
            this.textBox90.TabStop = false;
            this.textBox90.Text = "0";
            // 
            // btnApagarTudo
            // 
            this.btnApagarTudo.Image = global::ControleDeVendas.Properties.Resources.Edit_RedoHS;
            this.btnApagarTudo.Location = new System.Drawing.Point(161, 4);
            this.btnApagarTudo.Name = "btnApagarTudo";
            this.btnApagarTudo.Size = new System.Drawing.Size(38, 23);
            this.btnApagarTudo.TabIndex = 12;
            this.btnApagarTudo.UseVisualStyleBackColor = true;
            this.btnApagarTudo.Click += new System.EventHandler(this.btnApagarTudo_Click);
            // 
            // btnImprimir
            // 
            this.btnImprimir.Image = global::ControleDeVendas.Properties.Resources.PrintHS;
            this.btnImprimir.Location = new System.Drawing.Point(205, 5);
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(38, 23);
            this.btnImprimir.TabIndex = 13;
            this.btnImprimir.UseVisualStyleBackColor = true;
            this.btnImprimir.Click += new System.EventHandler(this.btnImprimir_Click);
            // 
            // previewPrintLiga
            // 
            this.previewPrintLiga.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.previewPrintLiga.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.previewPrintLiga.ClientSize = new System.Drawing.Size(400, 300);
            this.previewPrintLiga.Document = this.printLiga;
            this.previewPrintLiga.Enabled = true;
            this.previewPrintLiga.Icon = ((System.Drawing.Icon)(resources.GetObject("previewPrintLiga.Icon")));
            this.previewPrintLiga.Name = "previewPrintLiga";
            this.previewPrintLiga.Visible = false;
            // 
            // printLiga
            // 
            this.printLiga.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printLiga_PrintPage);
            // 
            // frmLiga
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 429);
            this.Controls.Add(this.grp31a45);
            this.Controls.Add(this.grp16a30);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnApagarTudo);
            this.Controls.Add(this.btnImprimir);
            this.Controls.Add(this.grp1a15);
            this.Controls.Add(this.txtTotGramas);
            this.Controls.Add(this.txtTotSacas);
            this.Controls.Add(this.txtNVias);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmLiga";
            this.Text = "LIGA de Amostras";
            this.Load += new System.EventHandler(this.frmLiga_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmLiga_KeyDown);
            this.grp1a15.ResumeLayout(false);
            this.grp1a15.PerformLayout();
            this.grp16a30.ResumeLayout(false);
            this.grp16a30.PerformLayout();
            this.grp31a45.ResumeLayout(false);
            this.grp31a45.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtNVias;
        private System.Windows.Forms.TextBox txtPen15;
        private System.Windows.Forms.TextBox txtPen14;
        private System.Windows.Forms.TextBox txtPen1;
        private System.Windows.Forms.TextBox txtPen2;
        private System.Windows.Forms.TextBox txtPen3;
        private System.Windows.Forms.TextBox txtPen5;
        private System.Windows.Forms.TextBox txtPen4;
        private System.Windows.Forms.TextBox txtPen6;
        private System.Windows.Forms.TextBox txtPen7;
        private System.Windows.Forms.TextBox txtPen8;
        private System.Windows.Forms.TextBox txtPen9;
        private System.Windows.Forms.TextBox txtPen10;
        private System.Windows.Forms.TextBox txtPen11;
        private System.Windows.Forms.TextBox txtPen12;
        private System.Windows.Forms.TextBox txtPen13;
        private System.Windows.Forms.TextBox txtTotSacas;
        private System.Windows.Forms.TextBox txtTotGramas;
        private System.Windows.Forms.GroupBox grp1a15;
        private System.Windows.Forms.TextBox txtLotes13;
        private System.Windows.Forms.TextBox txtLotes12;
        private System.Windows.Forms.TextBox txtLotes11;
        private System.Windows.Forms.TextBox txtLotes10;
        private System.Windows.Forms.TextBox txtLotes9;
        private System.Windows.Forms.TextBox txtLotes8;
        private System.Windows.Forms.TextBox txtLotes7;
        private System.Windows.Forms.TextBox txtLotes6;
        private System.Windows.Forms.TextBox txtLotes4;
        private System.Windows.Forms.TextBox txtLotes5;
        private System.Windows.Forms.TextBox txtLotes3;
        private System.Windows.Forms.TextBox txtLotes2;
        private System.Windows.Forms.TextBox txtLotes1;
        private System.Windows.Forms.TextBox txtLotes14;
        private System.Windows.Forms.TextBox txtLotes15;
        private System.Windows.Forms.TextBox txtGramas13;
        private System.Windows.Forms.TextBox txtGramas12;
        private System.Windows.Forms.TextBox txtGramas11;
        private System.Windows.Forms.TextBox txtGramas10;
        private System.Windows.Forms.TextBox txtGramas9;
        private System.Windows.Forms.TextBox txtGramas8;
        private System.Windows.Forms.TextBox txtGramas7;
        private System.Windows.Forms.TextBox txtGramas6;
        private System.Windows.Forms.TextBox txtGramas4;
        private System.Windows.Forms.TextBox txtGramas5;
        private System.Windows.Forms.TextBox txtGramas3;
        private System.Windows.Forms.TextBox txtGramas2;
        private System.Windows.Forms.TextBox txtGramas1;
        private System.Windows.Forms.TextBox txtGramas14;
        private System.Windows.Forms.TextBox txtGramas15;
        private System.Windows.Forms.Button btnImprimir;
        private System.Windows.Forms.Button btnApagarTudo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox grp16a30;
        private System.Windows.Forms.TextBox txtPen17;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtGramas28;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtGramas27;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtGramas26;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtGramas25;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtGramas24;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtGramas23;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtGramas22;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtGramas21;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtGramas19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtGramas20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtGramas18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtGramas17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtGramas16;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtGramas29;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtGramas30;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtLotes28;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtLotes27;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox txtLotes26;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox txtLotes25;
        private System.Windows.Forms.TextBox txtPen16;
        private System.Windows.Forms.TextBox txtLotes24;
        private System.Windows.Forms.TextBox txtPen18;
        private System.Windows.Forms.TextBox txtLotes23;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox txtLotes22;
        private System.Windows.Forms.TextBox txtPen19;
        private System.Windows.Forms.TextBox txtLotes21;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox txtLotes19;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox txtLotes20;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox txtLotes18;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox txtLotes17;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox txtLotes16;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox txtLotes29;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox txtLotes30;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.GroupBox grp31a45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtGramas43;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtGramas42;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtGramas41;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtGramas40;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtGramas39;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtGramas38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtGramas37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtGramas36;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtGramas34;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtGramas35;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtGramas33;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtGramas32;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtGramas31;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtGramas44;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtGramas45;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtLotes43;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txtLotes42;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox txtLotes41;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox txtLotes40;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox txtLotes39;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox txtLotes38;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox txtLotes37;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox txtLotes36;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox txtLotes34;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox txtLotes35;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox txtLotes33;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox txtLotes32;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox txtLotes31;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox txtLotes44;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox txtLotes45;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.PrintPreviewDialog previewPrintLiga;
        private System.Drawing.Printing.PrintDocument printLiga;
    }
}