﻿namespace ControleDeVendas.Relatórios
{
    partial class Fechamentos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reportConsultaFech = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.cachedMesFechamento1 = new ControleDeVendas.Relatórios.CachedMesFechamento();
            ((System.ComponentModel.ISupportInitialize)(this.errErro)).BeginInit();
            this.SuspendLayout();
            // 
            // reportConsultaFech
            // 
            this.reportConsultaFech.ActiveViewIndex = -1;
            this.reportConsultaFech.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.reportConsultaFech.DisplayGroupTree = false;
            this.reportConsultaFech.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportConsultaFech.Location = new System.Drawing.Point(0, 0);
            this.reportConsultaFech.Name = "reportConsultaFech";
            this.reportConsultaFech.SelectionFormula = "";
            this.reportConsultaFech.ShowCloseButton = false;
            this.reportConsultaFech.ShowGroupTreeButton = false;
            this.reportConsultaFech.ShowRefreshButton = false;
            this.reportConsultaFech.Size = new System.Drawing.Size(544, 441);
            this.reportConsultaFech.TabIndex = 0;
            this.reportConsultaFech.ViewTimeSelectionFormula = "";
            // 
            // Fechamentos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.ClientSize = new System.Drawing.Size(544, 441);
            this.Controls.Add(this.reportConsultaFech);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Fechamentos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmPrintdaConsulta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errErro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CachedMesFechamento cachedMesFechamento1;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer reportConsultaFech;


    }
}
