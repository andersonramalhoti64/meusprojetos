using System;
using System.Text;
using System.Data;
using DllControleDeVendas.Sistema.Globais;

namespace DllControleDeVendas.Sistema.Negocio
{
    public class clnPedido
    {
        private int _ped_id;

        public int ped_id
        {
            get
            {
                return _ped_id;
            }
            set
            {
                _ped_id = value;
            }
        }
        private clnCliente _clnCliente;

        public clnCliente clnCliente
        {
            get
            {
                return _clnCliente;
            }
            set
            {
                _clnCliente = value;
            }
        }
        private DateTime _ped_DtEncomenda;

        public DateTime ped_DtEncomenta
        {
            get
            {
                return _ped_DtEncomenda;
            }
            set
            {
                _ped_DtEncomenda = value;
            }
        }
        private decimal _ped_Valor;

        public decimal ped_Valor
        {
            get
            {
                return _ped_Valor;
            }
            set
            {
                _ped_Valor = value;
            }
        }
        private char _ped_Status;

        public char ped_Status
        {
            get
            {
                return _ped_Status;
            }
            set
            {
                _ped_Status = value;
            }
        }

        public int Gravar()
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" INSERT INTO pedido ");
            strQuery.Append(" ( ");
            strQuery.Append(" cli_Id ");
            strQuery.Append(", ped_DtEncomenda ");
            strQuery.Append(", ped_Valor ");
            strQuery.Append(", ped_Status ");
            strQuery.Append(" ) ");
            strQuery.Append(" VALUES ( ");
            strQuery.Append(" '" + _clnCliente.cli_Id + "' ");
            strQuery.Append(", '" + _ped_DtEncomenda + "' ");
            strQuery.Append(", '" + _ped_Valor + "' ");
            strQuery.Append(", '" + _ped_Status + "' ");
            strQuery.Append(" ); ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.ExecutaComandoRetorno(strQuery.ToString());
        }
    }
}