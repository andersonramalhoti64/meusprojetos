using System.Data;
using System.Data.OleDb;
using System.Text;
using System;
using DllControleDeVendas.Sistema.Globais;

namespace DllControleDeVendas.Sistema.Negocio
{
    public class clnCliente
    {
        private int _cli_Id;

        public int cli_Id
        {
            get
            {
                return _cli_Id;
            }
            set
            {
                _cli_Id = value;
            }
        }
        private string _cli_NomeRazao;

        public string cli_NomeRazao
        {
            get
            {
                return _cli_NomeRazao;
            }
            set
            {
                _cli_NomeRazao = value;
            }
        }
        private string _cli_CNPJCPF;

        public string cli_CNPJCPF
        {
            get
            {
                return _cli_CNPJCPF;
            }
            set
            {
                _cli_CNPJCPF = value;
            }
        }
        private string _cli_Logradouro;

        public string cli_Logradouro
        {
            get
            {
                return _cli_Logradouro;
            }
            set
            {
                _cli_Logradouro = value;
            }
        }
        private string _cli_Bairro;

        public string cli_Bairro
        {
            get
            {
                return _cli_Bairro;
            }
            set
            {
                _cli_Bairro = value;
            }
        }
        private string _cli_Cidade;

        public string cli_Cidade
        {
            get
            {
                return _cli_Cidade;
            }
            set
            {
                _cli_Cidade = value;
            }
        }
        private string _cli_Uf;

        public string cli_Uf
        {
            get
            {
                return _cli_Uf;
            }
            set
            {
                _cli_Uf = value;
            }
        }
        private string _cli_CEP;

        public string cli_CEP
        {
            get
            {
                return _cli_CEP;
            }
            set
            {
                _cli_CEP = value;
            }
        }
        private string _cli_Email;

        public string cli_Email
        {
            get
            {
                return _cli_Email;
            }
            set
            {
                _cli_Email = value;
            }
        }
        private string _cli_Fones;

        public string cli_Fones
        {
            get
            {
                return _cli_Fones;
            }
            set
            {
                _cli_Fones = value;
            }
        }
        private DateTime _cli_DtCadastro;

        public DateTime cli_DtCadastro
        {
            get
            {
                return _cli_DtCadastro;
            }
            set
            {
                _cli_DtCadastro = value;
            }
        }

        public void Gravar()
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" INSERT INTO cliente ");
            strQuery.Append(" ( ");
            strQuery.Append(" cli_NomeRazao ");
            strQuery.Append(", cli_CNPJCPF ");
            strQuery.Append(", cli_Logradouro ");
            strQuery.Append(", cli_Bairro ");
            strQuery.Append(", cli_Cidade ");
            strQuery.Append(", cli_Uf ");
            strQuery.Append(", cli_CEP ");
            strQuery.Append(", cli_Email ");
            strQuery.Append(", cli_Fones ");
            strQuery.Append(", cli_DtCadastro ");
            strQuery.Append(" ) ");
            strQuery.Append(" VALUES ( ");
            strQuery.Append(" '" + cli_NomeRazao + "' ");
            strQuery.Append(", '" + _cli_CNPJCPF + "' ");
            strQuery.Append(", '" + _cli_Logradouro + "' ");
            strQuery.Append(", '" + _cli_Bairro + "' ");
            strQuery.Append(", '" + _cli_Cidade + "' ");
            strQuery.Append(", '" + _cli_Uf + "' ");
            strQuery.Append(", '" + _cli_CEP + "' ");
            strQuery.Append(", '" + _cli_Email + "' ");
            strQuery.Append(", '" + _cli_Fones + "' ");
            strQuery.Append(", '" + _cli_DtCadastro + "' ");
            strQuery.Append(" ); ");
            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public void Alterar()
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" UPDATE cliente ");
            strQuery.Append(" SET ");
            strQuery.Append(" cli_NomeRazao = '" + _cli_NomeRazao + "' ");
            strQuery.Append(", cli_CNPJCPF = '" + _cli_CNPJCPF + "' ");
            strQuery.Append(", cli_Logradouro = '" + _cli_Logradouro + "' ");
            strQuery.Append(", cli_Bairro = '" + _cli_Bairro + "' ");
            strQuery.Append(", cli_Cidade = '" + _cli_Cidade + "' ");
            strQuery.Append(", cli_Uf = '" + _cli_Uf + "' ");
            strQuery.Append(", cli_CEP = '" + _cli_CEP + "' ");
            strQuery.Append(", cli_Email = '" + _cli_Email + "' ");
            strQuery.Append(", cli_Fones = '" + _cli_Fones + "' ");
            strQuery.Append(" WHERE ");
            strQuery.Append(" cli_ID = " + _cli_Id + " ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public DataSet Listar(string strDescricao)
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" SELECT cli_Id as Codigo, cli_NomeRazao as Descricao ");
            strQuery.Append(" FROM cliente ");

            if (!(strDescricao.Equals(string.Empty)))
            {
                strQuery.Append(" WHERE cli_NomeRazao like '%" + strDescricao + "%' ");
            }

            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataSet(strQuery.ToString());
        }

        public void Excluir(int intCodigo)
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" DELETE FROM cliente ");
            strQuery.Append(" WHERE cli_id = " + intCodigo + "");

            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public OleDbDataReader ListarCliente(int intCodigo)
        {

            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" SELECT cli_NomeRazao, cli_CNPJCPF, cli_Logradouro, cli_Bairro, cli_Cidade, cli_Uf, cli_CEP, cli_Email, cli_Fones ");
            strQuery.Append(" FROM cliente ");
            strQuery.Append(" WHERE cli_id = " + intCodigo + " ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataReader(strQuery.ToString());
        }
    }
}