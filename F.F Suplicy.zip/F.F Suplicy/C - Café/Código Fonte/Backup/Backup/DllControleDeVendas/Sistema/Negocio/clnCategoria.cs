
// Adiciona as Namespaces necess�rias nesta classe
using System.Data;
using System.Data.OleDb;
using System.Text;
using DllControleDeVendas.Sistema.Globais;

namespace DllControleDeVendas.Sistema.Negocio
{
    public class clnCategoria
    {
        //Cria todos os m�todos internos e propriedades externas com os mesmos atributos do banco de dados

        private int _cat_ID;

        public int cat_ID
        {
            get
            {
                return _cat_ID;
            }
            set
            {
                _cat_ID = value;
            }
        }
        private string _cat_Descricao;

        public string cat_Descricao
        {
            get
            {
                return _cat_Descricao;
            }
            set
            {
                _cat_Descricao = value;
            }
        }

        // Fun��o utilizada para retornar um DataSet com o select indicado

        public DataSet Listar(string strDescricao)
        {
            // Cria um StringBuilder para concatenar a Query Sql

            StringBuilder strQuery = new StringBuilder();
            strQuery.Append(" SELECT cat_Id as Codigo, cat_Descricao as Descricao ");
            strQuery.Append(" FROM Categoria ");

            // Adiciona o filtro do par�metro
            if (!(strDescricao.Equals(string.Empty)))
            {
                strQuery.Append(" WHERE cat_Descricao like '%" + strDescricao + "%' ");
            }
            // Executa o m�todo RetornaDataSet da classe de banco de dados e retorna o DataSet
            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataSet(strQuery.ToString());
        }

        public void Excluir(int intCodigo)
        {
            // Cria um StringBuilder para concatenar a Query Sql
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" DELETE FROM categoria ");
            strQuery.Append(" WHERE cat_id = " + intCodigo + "");

            // Executa o m�todo ExecutaComando da classe de banco de dados 
            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public void Gravar()
        {

            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" INSERT INTO categoria ");
            strQuery.Append(" ( ");
            strQuery.Append(" cat_Descricao ");
            strQuery.Append(" ) ");
            strQuery.Append(" VALUES ( ");
            strQuery.Append(" '" + cat_Descricao + "' ");
            strQuery.Append(" ); ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public void Alterar()
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" UPDATE categoria ");
            strQuery.Append(" SET ");
            strQuery.Append(" cat_Descricao = '" + _cat_Descricao + "' ");
            strQuery.Append(" WHERE ");
            strQuery.Append(" cat_ID = " + _cat_ID + " ");

            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public OleDbDataReader ListarCategoria(int intCodigo)
        {
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" SELECT cat_Descricao ");
            strQuery.Append(" FROM categoria ");
            strQuery.Append(" WHERE cat_id = " + intCodigo + " ");
            cldBancoDados cldBancoDados = new cldBancoDados();

            return cldBancoDados.RetornaDataReader(strQuery.ToString());
        }
    }
}