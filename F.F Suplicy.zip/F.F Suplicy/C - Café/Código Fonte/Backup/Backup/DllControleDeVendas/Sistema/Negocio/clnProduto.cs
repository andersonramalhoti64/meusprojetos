using System.Data;
using System.Data.OleDb; 
using System.Text;
using DllControleDeVendas.Sistema.Globais;

namespace DllControleDeVendas.Sistema.Negocio
{
    public class clnProduto
    {
        // Cria todos os m�todos internos e propriedades externas com os mesmos atributos do banco de dados
        private int _pro_id;

        public int pro_id
        {
            get
            {
                return _pro_id;
            }
            set
            {
                _pro_id = value;
            }
        }
        private clnCategoria _clnCategoria;

        public clnCategoria clnCategoria
        {
            get
            {
                return _clnCategoria;
            }
            set
            {
                _clnCategoria = value;
            }
        }
        private string _pro_Descricao;

        public string pro_Descricao
        {
            get
            {
                return _pro_Descricao;
            }
            set
            {
                _pro_Descricao = value;
            }
        }
        private int _pro_QtdeEstoque;

        public int pro_QtdeEstoque
        {
            get
            {
                return _pro_QtdeEstoque;
            }
            set
            {
                _pro_QtdeEstoque = value;
            }
        }
        private decimal _pro_Valor;

        public decimal pro_Valor
        {
            get
            {
                return _pro_Valor;
            }
            set
            {
                _pro_Valor = value;
            }
        }
        private bool _pro_Ativo;

        public bool pro_Ativo
        {
            get
            {
                return _pro_Ativo;
            }
            set
            {
                _pro_Ativo = value;
            }
        }

        public void Gravar()
        {
            // Cria um StringBuilder para concatenar a Query Sql
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" INSERT INTO produto ");
            strQuery.Append(" ( ");
            strQuery.Append(" cat_Id ");
            strQuery.Append(", pro_Descricao ");
            strQuery.Append(", pro_QtdeEstoque ");
            strQuery.Append(", pro_Valor ");
            strQuery.Append(", pro_Ativo ");
            strQuery.Append(" ) ");
            strQuery.Append(" VALUES ( ");
            strQuery.Append(" '" + _clnCategoria.cat_ID + "' ");
            strQuery.Append(", '" + _pro_Descricao + "' ");
            strQuery.Append(", '" + _pro_QtdeEstoque + "' ");
            strQuery.Append(", '" + _pro_Valor + "' ");
            strQuery.Append(", " + _pro_Ativo + " ");
            strQuery.Append(" ); ");

            // Executa o m�todo ExecutaComando da classe de banco de dados 
            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public DataSet Listar(string strDescricao)
        {
            // Cria um StringBuilder para concatenar a Query Sql
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" SELECT pro_Id as Codigo, pro_Descricao as Descricao ");
            strQuery.Append(" FROM produto ");

            // Adiciona o filtro do parametro
            if (!(strDescricao.Equals(string.Empty)))
            {
                strQuery.Append(" WHERE pro_Descricao like '%" + strDescricao + "%' ");
            }

            // Executa o m�todo RetornaDataSet da classe de banco de dados e retorna o DataSet
            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataSet(strQuery.ToString());
        }

        public void Excluir(int intCodigo)
        {
            // Cria um StringBuilder para concatenar a Query Sql
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" DELETE FROM produto ");
            strQuery.Append(" WHERE pro_id = " + intCodigo + "");

            // Executa o m�todo ExecutaComando da classe de banco de dados
            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public void Alterar()
        {
            // Cria um StringBuilder para concatenar a Query Sql
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" UPDATE produto ");
            strQuery.Append(" SET ");
            strQuery.Append(" cat_Id = '" + _clnCategoria.cat_ID + "' ");
            strQuery.Append(", pro_Descricao = '" + _pro_Descricao + "' ");
            strQuery.Append(", pro_QtdeEstoque = '" + _pro_QtdeEstoque + "' ");
            strQuery.Append(", pro_Valor = '" + _pro_Valor + "' ");
            strQuery.Append(", pro_Ativo = " + _pro_Ativo + " ");
            strQuery.Append(" WHERE ");
            strQuery.Append(" pro_ID = " + _pro_id + " ");

            // Executa o m�todo ExecutaComando da classe de banco de dados
            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public OleDbDataReader ListarProduto(int intCodigo)
        {
            // Cria um StringBuilder para concatenar a Query Sql
            StringBuilder strQuery = new StringBuilder();

            strQuery.Append(" SELECT cat_Id, pro_Descricao, pro_QtdeEstoque, pro_Valor, pro_Ativo ");
            strQuery.Append(" FROM produto ");
            strQuery.Append(" WHERE pro_id = " + intCodigo + " ");

            // Executa o m�todo RetornaDataReader da classe de banco de dados e retorna o DataReader
            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataReader(strQuery.ToString());
        }
    }
}