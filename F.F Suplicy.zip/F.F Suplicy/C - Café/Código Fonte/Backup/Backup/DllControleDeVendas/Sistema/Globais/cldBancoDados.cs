// Adiciona as Namespaces necess�rias nesta classe
using System;
using System.Data.OleDb;
using System.Data;
using System.Configuration;



namespace DllControleDeVendas.Sistema.Globais
{

    public class cldBancoDados
    {
        // Passa para vari�vel StringConexao o valor do arquivo de configura��o

        //string StringConexao = (string)["Conexao"];
        string StringConexao = Properties.Settings.Default.Conexao;

        // Fun��o utilizada para abrir a conex�o com o banco de dados
        private OleDbConnection AbreBanco()
        {
            OleDbConnection Conn = new OleDbConnection();
            // Passa o valor da String de Conex�o e abre o banco de dados
            Conn.ConnectionString = StringConexao;
            Conn.Open();
            return Conn;
        }

        //  Rotina utilizada para fechar a conex�o com o banco de dados
        private void FechaBanco(OleDbConnection Conn)
        {
            // Verifica se a conex�o do banco de dados est� aberta
            if (Conn.State == ConnectionState.Open)
            {
                Conn.Close();
            }
        }

        // Fun��o utilizada para executar comandos no banco de dados
        public void ExecutaComando(string strQuery)
        {
            OleDbConnection Conn = new OleDbConnection();
            // Cria o objeto de conex�o
            try
            {
                // Abre o banco da dados
                Conn = AbreBanco();

                // Cria o objeto de comando
                OleDbCommand cmdComando = new OleDbCommand();
                
                // Passa os valores da Query SQL, tipo do comando, conex�o e executa o comando
                cmdComando.CommandText = strQuery;
                cmdComando.CommandType = CommandType.Text;
                cmdComando.Connection = Conn;
                cmdComando.ExecuteNonQuery();

            }
            // Tratamento de excess�es
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {   
                // Em caso de erro ou n�o, o finally � executado para fechar a conex�o com  o banco de dados
                FechaBanco(Conn);
            }
        }
            
        // Fun��o utilizada para executar comandos com algum retorno do tipo Integer
        public int ExecutaComandoRetorno(string strQuery)
        {
             // Cria o objeto de conex�o
            OleDbConnection Conn = new OleDbConnection();
            
            // Declara um novo DataReader
            OleDbDataReader dr;
            try
            {
                // Abre a conex�o com o banco de dados
                Conn = AbreBanco();
                
                // Cria o objeto de comando
                OleDbCommand cmdComando = new OleDbCommand();
                
                // Passa os valores da Query SQL, tipo do comando, conex�o e executa o comando
                cmdComando.CommandText = strQuery;
                cmdComando.CommandType = CommandType.Text;
                cmdComando.Connection = Conn;
                cmdComando.ExecuteNonQuery();
                
                // Cria uma nova Query, que busca o valor do Identity gerado pelo banco de dados
                cmdComando.CommandText = "Select @@Identity;";
                
                // Executa a leitura do comando
                dr = cmdComando.ExecuteReader();
                
                // L� o DataReader
                dr.Read();
                
                // Retorna o valor
                return (int)dr[0];
            }
            // Tratamento de exce��es
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // Em caso de erro ou n�o, o finally � executado para fechar a conex�o com  o banco de dados
                FechaBanco(Conn);
            }
        }

        // Fun��o utilizada para retornar um DataSet a partir de uma Query Sql
        public DataSet RetornaDataSet(string strQuery)
        {
            // Cria o objeto de conex�o
            OleDbConnection Conn = new OleDbConnection();
            try
            {
                // Abre a conex�o com o banco de dados
                Conn = AbreBanco();

                
                // Cria o objeto de comando
                OleDbCommand cmdComando = new OleDbCommand();

                // Passa os valores da Query SQL, tipo do comando, conex�o e executa o comando
                cmdComando.CommandText = strQuery;
                cmdComando.CommandType = CommandType.Text;
                cmdComando.Connection = Conn;
                
                // Declara um DataAdapter
                OleDbDataAdapter daAdaptador = new OleDbDataAdapter();
                
                // Declara um DataSet
                DataSet dsDataSet = new DataSet();

                // Passa o comando a ser executado pelo DataAdapter
                daAdaptador.SelectCommand = cmdComando;
                
                // O DataAdapter faz o conex�o com o banco de dados, carrega o DataSet e fecha a conex�o
                daAdaptador.Fill(dsDataSet);
                
                // Retorna o DataSet carregado
                return dsDataSet;
            }
            // tratamento de exce��es
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // Em caso de erro ou n�o, o finally � executado para fechar a conex�o com  o banco de dados
                FechaBanco(Conn);
            }
        }

        // Fun��o utilizada para retornar um DataReader a partir de uma Query Sql
        public OleDbDataReader RetornaDataReader(string strQuery)
        {
            // Cria o objeto de conex�o
            OleDbConnection Conn = new OleDbConnection();
            try
            {
                Conn = AbreBanco();
                OleDbCommand cmdComando = new OleDbCommand();
                cmdComando.CommandText = strQuery;
                cmdComando.CommandType = CommandType.Text;
                cmdComando.Connection = Conn;
                return cmdComando.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}