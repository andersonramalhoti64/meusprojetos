namespace DllControleDeVendas.Sistema.Globais
{
    public class clnFuncoesGerais
    {
        public enum Operacao
        {
            Inclusao,
            Alteracao
        }
    }
}