using System;
using System.Text;
using System.Data;
using DllControleDeVendas.Sistema.Globais;

namespace DllControleDeVendas.Sistema.Negocio
{
    public class clnItem
    {
        private int _ite_Id;

        public int ite_Id
        {
            get
            {
                return _ite_Id;
            }
            set
            {
                _ite_Id = value;
            }
        }
        private clnPedido _clnPedido;

        public clnPedido clnPedido
        {
            get
            {
                return _clnPedido;
            }
            set
            {
                _clnPedido = value;
            }
        }
        private clnProduto _clnProduto;

        public clnProduto clnProduto
        {
            get
            {
                return _clnProduto;
            }
            set
            {
                _clnProduto = value;
            }
        }
        private int _ite_Qtde;

        public int ite_Qtde
        {
            get
            {
                return _ite_Qtde;
            }
            set
            {
                _ite_Qtde = value;
            }
        }
        private decimal _ite_Valor;

        public decimal ite_Valor
        {
            get
            {
                return _ite_Valor;
            }
            set
            {
                _ite_Valor = value;
            }
        }

        public void Gravar()
        {
            StringBuilder strQuery = new StringBuilder();
            strQuery.Append(" INSERT INTO item ");
            strQuery.Append(" ( ");
            strQuery.Append(" ped_Id ");
            strQuery.Append(", pro_Id ");
            strQuery.Append(", ite_Qtde ");
            strQuery.Append(", ite_Valor ");
            strQuery.Append(" ) ");
            strQuery.Append(" VALUES ( ");
            strQuery.Append(" '" + _clnPedido.ped_id + "' ");
            strQuery.Append(", '" + _clnProduto.pro_id + "' ");
            strQuery.Append(", '" + _ite_Qtde + "' ");
            strQuery.Append(", '" + _ite_Valor + "' ");
            strQuery.Append(" ); ");
            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }

        public DataSet Listar(int ped_Id)
        {
            StringBuilder strQuery = new StringBuilder();
            strQuery.Append(" SELECT ite_Id as Codigo, ped_Id as Pedido, pro_Id as Produto, ite_Qtde as Qtdade, ite_Valor as Valor");
            strQuery.Append(" FROM item ");
            strQuery.Append(" WHERE ped_Id = " + ped_Id + " ");
            cldBancoDados cldBancoDados = new cldBancoDados();
            return cldBancoDados.RetornaDataSet(strQuery.ToString());
        }

        public void Excluir(int ite_ID)
        {
            StringBuilder strQuery = new StringBuilder();
            strQuery.Append(" DELETE FROM item ");
            strQuery.Append(" WHERE ite_ID = " + ite_Id + " ; ");
            cldBancoDados cldBancoDados = new cldBancoDados();
            cldBancoDados.ExecutaComando(strQuery.ToString());
        }
    }
}