using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Negocio;

namespace ControleDeVendas.Formul�rios.Sistema
{
    public partial class frmPedido : ControleDeVendas.Formul�rios.Modelos.frmModeloCadastro
    {
        int CodigoCliente;
        int CodigoPedido;
        int CodigoProduto;
        
        public frmPedido()
        {
            InitializeComponent();
        }

       
        private void frmPedido_Load(object sender, EventArgs e)
        {
            
        }

        private void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            frmConsulta frmConsulta = new frmConsulta();
            frmConsulta.Text = "Consulta de Cliente";
            frmConsulta.ConsultaTipo = frmConsulta.TipoConsulta.Cliente;
            frmConsulta.ShowDialog();

            
            CodigoCliente = frmConsulta.CodigoRetorno;
            txtCliente.Text = frmConsulta.DescricaoRetorno;
            
        }

        private void btnBuscarProduto_Click(object sender, EventArgs e)
        {
            frmConsulta frmConsulta = new frmConsulta();
            frmConsulta.Text = "Consulta de Produgto";
            frmConsulta.ConsultaTipo = frmConsulta.TipoConsulta.Produto;
            frmConsulta.ShowDialog();


            CodigoProduto = frmConsulta.CodigoRetorno;
            txtProduto.Text = frmConsulta.DescricaoRetorno;
            
        }

        private void dgvItem_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (txtCliente.Text == String.Empty)
            {
                errErro.SetError(txtCliente, "Selecione um cliente");
            }
            else
            {
                errErro.SetError(txtCliente, "");
            }

            clnCliente clnCliente = new clnCliente();
            clnCliente.cli_Id = CodigoCliente;

            clnPedido clnPedido = new clnPedido();
            clnPedido.clnCliente = clnCliente;
            clnPedido.ped_DtEncomenta = dtpData.Value;
            clnPedido.ped_Valor = 0;
            clnPedido.ped_Status = 'A';
            CodigoPedido = clnPedido.Gravar();

            MessageBox.Show("Pedido adicionado com sucesso");
            grbItem.Enabled = true;
            grbPedido.Enabled = true;


        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            

        }

        private void btnAdicionarItem_Click(object sender, EventArgs e)
        {
            if (txtProduto.Text == String.Empty)
            {
                errErro.SetError(txtProduto, "Selecione um produto");
            }
            else
            {
                errErro.SetError(txtProduto, "");
            }

            if (txtQuantidade.Text == String.Empty)
            {
                errErro.SetError(txtQuantidade, "Informe a quantidade");
            }
            else
            {
                errErro.SetError(txtQuantidade, "");
            }

            if (txtValor.Text == String.Empty)
            {
                errErro.SetError(txtValor, "Informe o valor!");
            }
            else
            {
                errErro.SetError(txtValor, "");
            }

            clnPedido clnPedido = new clnPedido();
            clnPedido.ped_id = CodigoPedido;

            clnProduto clnProduto = new clnProduto();
            clnProduto.pro_id = CodigoProduto;

            clnItem clnItem = new clnItem();
            clnItem.clnPedido = clnPedido;
            clnItem.clnProduto = clnProduto;
            clnItem.ite_Qtde = Convert.ToInt16(txtQuantidade.Text);
            clnItem.ite_Valor = Convert.ToDecimal(txtValor.Text);
            clnItem.Gravar();

            MessageBox.Show("Item adicionado com sucesso!");
            
            txtQuantidade.Text = "";
            txtValor.Text = "";
            txtProduto.Text = "";
            CodigoProduto = 0;

            CarregaGridItem();

        }

        private void CarregaGridItem()
        {
            DataSet ds = new DataSet();
            clnItem clnItem = new clnItem();

            ds = clnItem.Listar(CodigoPedido);
            dgvItem.DataSource = ds.Tables[0];
        }

        private void btnRemoverItem_Click(object sender, EventArgs e)
        {
            clnItem clnItem = new clnItem();
            clnItem.Excluir(Convert.ToInt16(dgvItem.CurrentRow.Cells[0].Value));

            MessageBox.Show("Item exclu�do com sucesso!");

            CarregaGridItem();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }


        
    }
}

