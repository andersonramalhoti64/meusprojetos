using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Globais;
using DllControleDeVendas.Sistema.Negocio;

namespace ControleDeVendas.Formul�rios.Cadastros.Categoria
{
    public partial class frmCategoriaCadastro : ControleDeVendas.Formul�rios.Modelos.frmModeloCadastro
    {
        public frmCategoriaCadastro()
        {
            InitializeComponent();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (txtNome.Text.Equals(string.Empty))
            {
                errErro.SetError(txtNome, "Digite um NOME");
                return;
            }
            else
            {
                errErro.SetError(txtNome, "");
            }

            clnCategoria cldCategoria = new clnCategoria();
            cldCategoria.cat_Descricao = txtNome.Text;
                      
            if (Operacao == clnFuncoesGerais.Operacao.Inclusao)
            {
                cldCategoria.Gravar();
            }
            else if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
            {
                cldCategoria.cat_ID = Codigo;
                cldCategoria.Alterar();
            }
            MessageBox.Show("Registro gravado com sucesso", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
            
        }

        private void frmCategoriaCadastro_Load(object sender, EventArgs e)
        {
            if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
            {
                clnCategoria clnCategoria = new clnCategoria();
                System.Data.OleDb.OleDbDataReader drDados;
                drDados = clnCategoria.ListarCategoria(Codigo);
                if (drDados.HasRows)
                {
                    drDados.Read();
                    txtNome.Text = drDados["cat_Descricao"].ToString();                    
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}

