using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Globais;

namespace ControleDeVendas.Formul�rios.Modelos
{
    public partial class frmModeloCadastro : ControleDeVendas.Formul�rios.Modelos.frmModelo
    {
        public frmModeloCadastro()
        {
            InitializeComponent();
        }

        clnFuncoesGerais.Operacao _Operacao;

        public clnFuncoesGerais.Operacao Operacao
        {
            get
            {
                return _Operacao;
            }
            set
            {
                _Operacao = value;
            }
        }

        int _Codigo;

        public int Codigo
        {
            get
            {
                return _Codigo;
            }
            set
            {
                _Codigo = value;
            }
        }


        private void btnSair_Click(object sender, EventArgs e)
        {

        }
    }
}

