using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Negocio;

namespace ControleDeVendas.Formul�rios.Sistema
{
    public partial class frmConsulta : ControleDeVendas.Formul�rios.Modelos.frmModeloConsulta
    {
        public frmConsulta()
        {
            InitializeComponent();
        }

        private void CarregaGrid()
        {
            DataSet dsConsulta = new DataSet();
            if (_ConsultaTipo == TipoConsulta.Cliente)
            {
                clnCliente clnCliente = new clnCliente();
                dsConsulta = clnCliente.Listar(txtDescricao.Text);
            }
            else if (_ConsultaTipo == TipoConsulta.Produto)
            {
                clnProduto clnProduto = new clnProduto();
                dsConsulta = clnProduto.Listar(txtDescricao.Text);
            }
            dgdGrid.DataSource = dsConsulta.Tables[0];
        }

        public enum TipoConsulta
        {
            Cliente,
            Produto
        }

        private TipoConsulta _ConsultaTipo;

        public TipoConsulta ConsultaTipo
        {
            get
            {
                return _ConsultaTipo;
            }
            set
            {
                _ConsultaTipo = value;
            }
        }
        private int _CodigoRetorno;

        public int CodigoRetorno
        {
            get
            {
                return _CodigoRetorno;
            }
            set
            {
                _CodigoRetorno = value;
            }
        }
        private string _DescricaoRetorno;

        public string DescricaoRetorno
        {
            get
            {
                return _DescricaoRetorno;
            }
            set
            {
                _DescricaoRetorno = value;
            }
        }

        private void btnSelecionar_Click(object sender, EventArgs e)
        {
            _CodigoRetorno = Convert.ToInt16(dgdGrid.CurrentRow.Cells[0].Value);
            _DescricaoRetorno = (dgdGrid.CurrentRow.Cells[0].Value.ToString());

            Close();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            CarregaGrid();
        }


    }
}

