using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Negocio;
using DllControleDeVendas.Sistema.Globais;

namespace ControleDeVendas.Formul�rios.Cadastros.Cliente
{
    public partial class frmClienteCadastro : ControleDeVendas.Formul�rios.Modelos.frmModeloCadastro
    {
        public frmClienteCadastro()
        {
            InitializeComponent();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (txtNome.Text.Equals(string.Empty))
            {
                errErro.SetError(txtNome, "Digite um nome");
                return;
            }
            else
            {
                errErro.SetError(txtNome, "");
            }
            if (txtCpfCnpj.Text.Equals(string.Empty))
            {
                errErro.SetError(txtCpfCnpj, "Digite um CPF/CNPJ");
                return;
            }
            else
            {
                errErro.SetError(txtCpfCnpj, "");
            }
            if (txtLogradouro.Text.Equals(string.Empty))
            {
                errErro.SetError(txtLogradouro, "Digite um logradouro");
                return;
            }
            else
            {
                errErro.SetError(txtLogradouro, "");
            }
            if (txtBairro.Text.Equals(string.Empty))
            {
                errErro.SetError(txtBairro, "Digite um bairro");
                return;
            }
            else
            {
                errErro.SetError(txtBairro, "");
            }
            if (txtCidade.Text.Equals(string.Empty))
            {
                errErro.SetError(txtCidade, "Digite uma cidade");
                return;
            }
            else
            {
                errErro.SetError(txtCidade, "");
            }
            if (cboUf.Text.Equals(string.Empty))
            {
                errErro.SetError(cboUf, "Selecione uma UF");
                return;
            }
            else
            {
                errErro.SetError(cboUf, "");
            }
            if (txtCep.Text.Equals(string.Empty))
            {
                errErro.SetError(txtCep, "Digite um CEP");
                return;
            }
            else
            {
                errErro.SetError(txtCep, "");
            }
            
            clnCliente cldCliente = new clnCliente();
            cldCliente.cli_Bairro = txtBairro.Text;
            cldCliente.cli_CEP = txtCep.Text;
            cldCliente.cli_Cidade = txtCidade.Text;
            cldCliente.cli_CNPJCPF = txtCpfCnpj.Text;
            cldCliente.cli_DtCadastro = DateTime.Now;
            cldCliente.cli_Email = txtEmail.Text;
            cldCliente.cli_Fones = txtTelefone.Text;
            cldCliente.cli_Logradouro = txtLogradouro.Text;
            cldCliente.cli_NomeRazao = txtNome.Text;
            cldCliente.cli_Uf = cboUf.Text;
            if (Operacao == clnFuncoesGerais.Operacao.Inclusao)
            {
                cldCliente.Gravar();
            }
            else if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
            {
                cldCliente.cli_Id = Codigo;
                cldCliente.Alterar();
            }
            MessageBox.Show("Registro gravado com sucesso", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void frmClienteCadastro_Load(object sender, EventArgs e)
        {
            if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
            {
                clnCliente clncliente = new clnCliente();
                System.Data.OleDb.OleDbDataReader drDados;
                drDados = clncliente.ListarCliente(Codigo);
                if (drDados.HasRows)
                {
                    drDados.Read();
                    txtNome.Text = drDados["cli_NomeRazao"].ToString();
                    txtCpfCnpj.Text = drDados["cli_CNPJCPF"].ToString();
                    txtLogradouro.Text = drDados["cli_Logradouro"].ToString();
                    txtBairro.Text = drDados["cli_Bairro"].ToString();
                    txtCidade.Text = drDados["cli_Cidade"].ToString();
                    cboUf.Text = drDados["cli_Uf"].ToString();
                    txtCep.Text = drDados["cli_CEP"].ToString();
                    txtEmail.Text = drDados["cli_Email"].ToString();
                    txtTelefone.Text = drDados["cli_Fones"].ToString();
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

