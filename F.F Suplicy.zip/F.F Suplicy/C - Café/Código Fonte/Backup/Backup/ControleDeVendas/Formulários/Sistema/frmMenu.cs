using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ControleDeVendas.Formul�rios.Cadastros.Cliente;
using ControleDeVendas.Formul�rios.Cadastros.Categoria;
using ControleDeVendas.Formul�rios.Cadastros.Produto;

namespace ControleDeVendas.Formul�rios.Sistema
{
    public partial class frmMenu : ControleDeVendas.Formul�rios.Modelos.frmModelo
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmClienteConsulta frmCliente = new frmClienteConsulta();
            frmCliente.ShowDialog();
        }

        private void categoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCategoriaConsulta frmCategoria = new frmCategoriaConsulta();
            frmCategoria.ShowDialog();
        }

        private void produtoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProdutoConsulta frmProduto = new frmProdutoConsulta();
            frmProduto.ShowDialog();
        }

        private void vendasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPedido frmPedido = new frmPedido();
            frmPedido.ShowDialog();
        }
    }
}

