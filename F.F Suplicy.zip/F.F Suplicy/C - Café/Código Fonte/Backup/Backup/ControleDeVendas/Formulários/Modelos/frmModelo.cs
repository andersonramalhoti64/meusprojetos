﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ControleDeVendas.Formulários.Modelos
{
    public partial class frmModelo : Form
    {
        public frmModelo()
        {
            InitializeComponent();
        }
    }
}