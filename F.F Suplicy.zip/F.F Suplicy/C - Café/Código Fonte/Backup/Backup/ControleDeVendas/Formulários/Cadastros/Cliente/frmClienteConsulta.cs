using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Globais;
using DllControleDeVendas.Sistema.Negocio;

namespace ControleDeVendas.Formul�rios.Cadastros.Cliente
{
    public partial class frmClienteConsulta : ControleDeVendas.Formul�rios.Modelos.frmModeloConsulta
    {
        public frmClienteConsulta()
        {
            InitializeComponent();
        }

        

        private void CarregaGrid()
        {
            clnCliente cldCliente = new clnCliente();
            dgdGrid.DataSource = cldCliente.Listar(txtDescricao.Text).Tables[0];
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            CarregaGrid();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            frmClienteCadastro frmCliente = new frmClienteCadastro();
            
            frmCliente.Operacao = clnFuncoesGerais.Operacao.Inclusao;
            frmCliente.ShowDialog();
            CarregaGrid();

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show("Deseja excluir o registro?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No))
            {
                return;
            }
            clnCliente cldCliente = new clnCliente();
            cldCliente.Excluir((int)(dgdGrid.CurrentRow.Cells[0].Value));
            
            MessageBox.Show("Registro exclu�do com sucesso", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            CarregaGrid();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            frmClienteCadastro frmCliente = new frmClienteCadastro();
            frmCliente.Operacao = clnFuncoesGerais.Operacao.Alteracao;
            frmCliente.Codigo = (int)dgdGrid.CurrentRow.Cells[0].Value;
            frmCliente.ShowDialog();
            CarregaGrid();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

