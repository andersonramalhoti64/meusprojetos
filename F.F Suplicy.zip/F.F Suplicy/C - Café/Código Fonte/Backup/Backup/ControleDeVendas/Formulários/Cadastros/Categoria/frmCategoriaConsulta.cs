using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Globais;
using DllControleDeVendas.Sistema.Negocio;

namespace ControleDeVendas.Formul�rios.Cadastros.Categoria
{
    public partial class frmCategoriaConsulta : ControleDeVendas.Formul�rios.Modelos.frmModeloConsulta
    {
        public frmCategoriaConsulta()
        {
            InitializeComponent();
        }

        private void CarregaGrid()
        {
            clnCategoria cldCategoria = new clnCategoria();
            dgdGrid.DataSource = cldCategoria.Listar(txtDescricao.Text).Tables[0];
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            frmCategoriaCadastro frmCategoria = new frmCategoriaCadastro();

            frmCategoria.Operacao = clnFuncoesGerais.Operacao.Inclusao;
            frmCategoria.ShowDialog();
            CarregaGrid();

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show("Deseja excluir o registro?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No))
            {
                return;
            }
            clnCategoria cldCategoria = new clnCategoria();
            cldCategoria.Excluir((int)(dgdGrid.CurrentRow.Cells[0].Value));

            MessageBox.Show("Registro exclu�do com sucesso", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            CarregaGrid();
     
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            frmCategoriaCadastro frmCategoria = new frmCategoriaCadastro();
            frmCategoria.Operacao = clnFuncoesGerais.Operacao.Alteracao;
            frmCategoria.Codigo = (int)dgdGrid.CurrentRow.Cells[0].Value;
            frmCategoria.ShowDialog();
            CarregaGrid();
        
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            CarregaGrid();
        }

    }
}

