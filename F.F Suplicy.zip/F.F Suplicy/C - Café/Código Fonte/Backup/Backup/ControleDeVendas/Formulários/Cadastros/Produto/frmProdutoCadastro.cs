using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Globais;
using DllControleDeVendas.Sistema.Negocio;

namespace ControleDeVendas.Formul�rios.Cadastros.Produto
{
    public partial class frmProdutoCadastro : ControleDeVendas.Formul�rios.Modelos.frmModeloCadastro
    {
        public frmProdutoCadastro()
        {
            InitializeComponent();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (cboCategoria.Text.Equals(string.Empty))
            {
                errErro.SetError(cboCategoria, "Informe uma Categoria");
                return;
            }
            else
            {
                errErro.SetError(cboCategoria, "");
            }
            if (txtDescricao.Text.Equals(string.Empty))
            {
                errErro.SetError(txtDescricao, "Digite uma Descri��o");
                return;
            }
            else
            {
                errErro.SetError(txtDescricao, "");
            }
            if (nudQuantidade.Text.Equals(string.Empty))
            {
                errErro.SetError(nudQuantidade, "Digite uma Quantidade");
                return;
            }
            else
            {
                errErro.SetError(nudQuantidade, "");
            }
            if (txtValor.Text.Equals(string.Empty))
            {
                errErro.SetError(txtValor, "Digite um Valor");
                return;
            }
            else
            {
                errErro.SetError(txtValor, "");
            }


            clnCategoria clnCategoria = new clnCategoria();
            clnCategoria.cat_ID = int.Parse(cboCategoria.SelectedValue.ToString());
            
            clnProduto clnProduto = new clnProduto();
            clnProduto.clnCategoria = clnCategoria; 
            
            clnProduto.pro_Descricao = txtDescricao.Text;
            clnProduto.pro_QtdeEstoque = Convert.ToInt16(nudQuantidade.Text);
            clnProduto.pro_Valor = Convert.ToDecimal(txtValor.Text);
            clnProduto.pro_Ativo = optSim.Checked;


            if (Operacao == clnFuncoesGerais.Operacao.Inclusao)
            {
                clnProduto.Gravar();
            }
            else if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
            {
                clnProduto.pro_id = Codigo;
                clnProduto.Alterar();
            }
            MessageBox.Show("Registro gravado com sucesso", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void frmProdutoCadastro_Load(object sender, EventArgs e)
        {
            clnCategoria clnCategoria = new clnCategoria();
            DataSet dsCategoria = new DataSet();
            dsCategoria = clnCategoria.Listar("");
            cboCategoria.DataSource = dsCategoria.Tables[0];
            cboCategoria.DisplayMember = "Descricao";
            cboCategoria.ValueMember = "Codigo";
            if (Operacao == clnFuncoesGerais.Operacao.Alteracao)
            {
                clnProduto clnProduto = new clnProduto();
                System.Data.OleDb.OleDbDataReader drDados;
                drDados = clnProduto.ListarProduto(Codigo);
                if (drDados.HasRows)
                {
                    drDados.Read(); 
                    cboCategoria.SelectedValue = drDados["cat_Codigo"].ToString();
                    txtDescricao.Text = drDados["pro_Descricao"].ToString();
                    nudQuantidade.Text = drDados["pro_QtdeEstoque"].ToString();
                    txtValor.Text = drDados["pro_Valor"].ToString();
                    if (drDados["pro_Ativo"].ToString() == "true")
                    {
                        optSim.Checked = true;
                    }
                    else
                    {
                        optNao.Checked = true;
                    }
                }
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

