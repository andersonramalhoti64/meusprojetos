using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DllControleDeVendas.Sistema.Negocio;
using DllControleDeVendas.Sistema.Globais;

namespace ControleDeVendas.Formul�rios.Cadastros.Produto
{
    public partial class frmProdutoConsulta : ControleDeVendas.Formul�rios.Modelos.frmModeloConsulta
    {
        public frmProdutoConsulta()
        {
            InitializeComponent();
        }

        private void CarregaGrid()
        {
            clnProduto cldProduto = new clnProduto();
            dgdGrid.DataSource = cldProduto.Listar(txtDescricao.Text).Tables[0];
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            CarregaGrid();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            frmProdutoCadastro frmProduto = new frmProdutoCadastro();

            frmProduto.Operacao = clnFuncoesGerais.Operacao.Inclusao;
            frmProduto.ShowDialog();
            CarregaGrid();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            frmProdutoCadastro frmProduto = new frmProdutoCadastro();
            frmProduto.Operacao = clnFuncoesGerais.Operacao.Alteracao;
            frmProduto.Codigo = (int)dgdGrid.CurrentRow.Cells[0].Value;
            frmProduto.ShowDialog();
            CarregaGrid();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if ((MessageBox.Show("Deseja excluir o registro?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No))
            {
                return;
            }
            clnProduto cldProduto = new clnProduto();
            cldProduto.Excluir((int)(dgdGrid.CurrentRow.Cells[0].Value));

            MessageBox.Show("Registro exclu�do com sucesso", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            CarregaGrid();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

