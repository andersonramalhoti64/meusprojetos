﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Modelos;
using CamadaAcessoDados;
using CamadaNegocio;
using System.IO;

namespace WindowsApp
{
    public partial class frmPrincipal : Form
    {
        string nome = null;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            preencher_ListView();
            preencher_cboClasse();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
            Dispose();
        }
        private void btnNovo_Click(object sender, EventArgs e)
        {
            pnInformacoes.Enabled = true;
            btnLimpar_Click(sender, e);
            txtNome.Focus();
        }
        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnSalvar.Visible = false;
            pnInformacoes.Enabled = true;
            btnEditarSalvar.Visible = true;
            txtNome.Focus();
        }
        private void preencher_ListView()
        {
            AlunoNegocio aluno = new AlunoNegocio();
            foreach (string nome in aluno.Listar_Alunos())
            {
                lstAlunos.Items.Add(nome);
            }

        }
        private void excluirToolStripMenuItesm_Click(object sender, EventArgs e)
        {
           
        }
        private void lstAlunos_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (ListViewItem item in lstAlunos.SelectedItems)
            {
                nome = item.Text;
            }
            EditarAluno();
        }
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                AlunoNegocio alunoNegocio = new AlunoNegocio();
                Aluno aluno = new Aluno();

                File.Copy(picFotoAtual.ImageLocation, @"c:\escola\imagens\" + txtNome.Text + ".jpg", true);
                aluno.codigo_classe = (int)cboClasse.SelectedValue;
                aluno.nome = txtNome.Text;
                aluno.endereco = txtEndereco.Text;
                aluno.mae = txtMae.Text;
                aluno.pai = txtPai.Text;
                aluno.telefone_mae = txtTelefoneMae.Text;
                aluno.telefone_pai = txtTelefonePai.Text;
                aluno.nascimento = dtNascimento.Value;
                aluno.matricula = dtMatricula.Value;
                aluno.desligamento = dtDesligamento.Text;
                aluno.observacoes = txtObservacoes.Text;
                aluno.foto_crianca = @"c:\escola\imagens\" + txtNome.Text + ".jpg";

                if (MessageBox.Show("Deseja Salvar as Informacões?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
                {
                    alunoNegocio.Novo_Aluno(aluno);
                    MessageBox.Show("Aluno Cadastrado com sucesso", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    lstAlunos.Items.Clear();
                    btnNovo.Focus();
                    btnLimpar_Click(sender, e);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Pelo menos um nome e uma foto devem ser preenchidos." + ex.Message);
                lstAlunos.Items.Clear();
            }
            
            preencher_ListView();
        }
        private void preencher_cboClasse()
        {
            ClasseNegocio classes = new ClasseNegocio();
            cboClasse.DataSource = classes.ListarClasses();
            cboClasse.DisplayMember = "Nome";
            cboClasse.ValueMember = "Codigo";
        }
        private void EditarAluno()
        {
            preencher_cboClasse();

            AlunoNegocio alunoNegocio = new AlunoNegocio();
            Aluno aluno = new Aluno();

            alunoNegocio.Ler_Aluno(nome, aluno);
            cboClasse.SelectedValue = (int)aluno.codigo_classe;
            txtNome.Text = aluno.nome;
            txtEndereco.Text = aluno.endereco;
            dtNascimento.Value = aluno.nascimento;
            txtMae.Text = aluno.mae;
            txtPai.Text = aluno.pai;
            txtTelefoneMae.Text = aluno.telefone_mae;
            txtTelefonePai.Text = aluno.telefone_pai;
            txtObservacoes.Text = aluno.observacoes;
            dtMatricula.Value = aluno.matricula;
            dtDesligamento.Text = aluno.desligamento;
            picFotoAtual.ImageLocation = @"c:\escola\imagens\" + aluno.nome + ".jpg";

        }
        private void picFotoAtual_Click(object sender, EventArgs e)
        {
            OpenFileDialog cxaDialogo = new OpenFileDialog();
            cxaDialogo.Filter = "Imagens JPEG|*.jpg|Imagens PNG|*.png|Bitmap|*.bmp |Todos os Arquivos|*.*";
            cxaDialogo.ShowDialog();

            picFotoAtual.ImageLocation = cxaDialogo.FileName;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            lstAlunos.Focus();
            pnInformacoes.Enabled = false;
            btnEditarSalvar.Visible = false;
            btnSalvar.Visible = true;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Focus();
            picFotoAtual.Image = null;

            dtMatricula.Value = DateTime.Now;
            dtNascimento.Value = DateTime.Now;

            foreach (Control cxasDeTexto in tabInformacoes.TabPages[0].Controls)
            {
                if (cxasDeTexto is TextBox)
                    cxasDeTexto.Text = "";
            }

            foreach (Control cxasDeTexto in tabInformacoes.TabPages[1].Controls)
            {
                if (cxasDeTexto is TextBox)
                    cxasDeTexto.Text = "";
            }
            txtTelefoneMae.Text = " ";
            txtTelefonePai.Text = " ";
            dtDesligamento.Text = " ";
        }

        private void txtPesquisar_Enter(object sender, EventArgs e)
        {
            txtPesquisar.Text = "";
            txtPesquisar.ForeColor = Color.Black;
        }

        private void txtPesquisar_Leave(object sender, EventArgs e)
        {
            txtPesquisar.Text = "Digite o nome do aluno";
            txtPesquisar.ForeColor = Color.Gray;
        }

        private void txtPesquisar_TextChanged(object sender, EventArgs e)
        {
            ListViewItem nome_pesquisado = lstAlunos.FindItemWithText(txtPesquisar.Text);
            if (nome_pesquisado != null)
            {
                nome = nome_pesquisado.Text;
                EditarAluno();
            }
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
      
        }

        private void mnuAluno_Opening(object sender, CancelEventArgs e)
        {

        }

        private void fotoNomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lstAlunos.View = View.LargeIcon;
        }

        private void nomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void btnImprimirTurmas_Click(object sender, EventArgs e)
        {
            new frmImprimirTurmas().Show();;
        }

        private void frmPrincipal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                SendKeys.Send("{Tab}");

            if (btnSalvar.Enabled == true)
            {
                if (e.KeyCode == Keys.F2)
                    btnSalvar_Click(sender, e);
            }

            if (btnCancelar.Enabled == true)
            {
                if (e.KeyCode == Keys.F4)
                    btnCancelar_Click(sender, e);
            }

            if (btnLimpar.Enabled == true)
            {
                if (e.KeyCode == Keys.F3)
                    btnLimpar_Click(sender, e);
            }

            if (btnEditarSalvar.Visible == true) 
            {
                if (e.KeyCode == Keys.F5)
                    btnEditarSalvar_Click(sender, e);
            }
        }

        private void btnEditarSalvar_Click(object sender, EventArgs e)
        {
            string nome = String.Empty;
            foreach(ListViewItem item in lstAlunos.SelectedItems)
            {
                nome = item.Text;
            }
            try
            {
                AlunoNegocio alunoNegocio = new AlunoNegocio();
                Aluno aluno = new Aluno();
                if (picFotoAtual.ImageLocation == String.Empty)
                    MessageBox.Show("Voce deve selecionar uma foto");
                else
                    File.Copy(picFotoAtual.ImageLocation, @"c:\escola\imagens\" + txtNome.Text + ".jpg", true);

                aluno.codigo_classe = (int)cboClasse.SelectedValue;
                aluno.nome = txtNome.Text;
                aluno.endereco = txtEndereco.Text;
                aluno.mae = txtMae.Text;
                aluno.pai = txtPai.Text;
                aluno.telefone_mae = txtTelefoneMae.Text;
                aluno.telefone_pai = txtTelefonePai.Text;
                aluno.nascimento = dtNascimento.Value;
                aluno.matricula = dtMatricula.Value;
                aluno.desligamento = dtDesligamento.Text;
                aluno.observacoes = txtObservacoes.Text;
                aluno.foto_crianca = @"c:\escola\imagens\" + txtNome.Text + ".jpg";

                if (MessageBox.Show("Deseja Salvar as Alteracões?", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.Yes)
                {
                    alunoNegocio.Atualizar_Aluno(aluno,nome);
                    MessageBox.Show("Aluno Alterado com sucesso", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    lstAlunos.Items.Clear();
                    btnCancelar_Click(sender, e);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Pelo menos um nome e uma foto devem ser preenchidos." + ex.Message);
                lstAlunos.Items.Clear();
            }

            preencher_ListView();
        }

        private void excluirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AlunoNegocio aluno = new AlunoNegocio();
            if (MessageBox.Show("Deseja realmente excluir os dados do aluno selecionado?", "Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                foreach (ListViewItem item in lstAlunos.SelectedItems)
                {
                    aluno.Excluir_Aluno(item.Text);
                    preencher_ListView();
                }
                MessageBox.Show("Dados Excluidos com sucesso", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnLimpar_Click(sender, e);
                btnNovo.Focus();
                lstAlunos.Items.Clear();
                preencher_ListView();
            }
            else
            {
                MessageBox.Show("Exclusão Cancelada", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
    }
}
