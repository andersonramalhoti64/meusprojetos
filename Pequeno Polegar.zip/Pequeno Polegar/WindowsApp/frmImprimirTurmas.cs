﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Modelos;
using CamadaAcessoDados;
using CamadaNegocio;
using System.IO;

namespace WindowsApp
{
    public partial class frmImprimirTurmas : Form
    {
        public frmImprimirTurmas()
        {
            InitializeComponent();
        }

        private void frmImprimirTurmas_Load(object sender, EventArgs e)
        {
            Listar_Classes();
        }

        private void Listar_Classes()
        {
            ClasseNegocio classe = new ClasseNegocio();
            cboClasse.DataSource = classe.ListarClasses();
            cboClasse.DisplayMember = "Nome";
            cboClasse.ValueMember = "Codigo";
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            //lstAlunosPorClasse.Clear();
            AlunoNegocio alunoNegocio = new AlunoNegocio();
            ListViewItem aluno;
           
            lstAlunosPorClasse.Items.Clear();
            foreach (Aluno dadosAluno in alunoNegocio.Listar_Alunos_Por_Classe((int)cboClasse.SelectedValue))
            {
                aluno = new ListViewItem(dadosAluno.nome);
                aluno.SubItems.Add(dadosAluno.nascimento.ToShortDateString());

                lstAlunosPorClasse.Items.Add(aluno);
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog preview = new PrintPreviewDialog();
            preview.Document = printDocument1;
            preview.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            preview.Show();
        }
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //Variaveis usadas para definir configuracoes de impressão
            float linhasPorPagina = 0;
            float yPosicao = 0;
            float margemEsquerda = e.MarginBounds.Left;
            float margemSuperior = e.MarginBounds.Top;
            Font fonteImpressao = new Font(FontFamily.GenericSansSerif,16f, FontStyle.Regular);
            SolidBrush caneta = new SolidBrush(Color.Black);
            //Quadro do timbre
            Rectangle quadro = new Rectangle();
            quadro.Width = 100;
            quadro.Height = 100;
            quadro.X = 50;
            quadro.Y = 30;

            //Define o numero de linhas por Pagina, usando Margin Bounds
            linhasPorPagina = e.MarginBounds.Height / fonteImpressao.GetHeight(e.Graphics);

            //Timbre
            e.Graphics.DrawImage(Image.FromFile(@"c:\escola\imagens\logo.jpg"), quadro);
            
            //Nome
            e.Graphics.DrawString("Núcleo de Recreação Infantil Pequeno Polegar", new Font(FontFamily.GenericSansSerif, 18f, FontStyle.Bold),
                                                        new SolidBrush(Color.Black), 180f, 50f, new StringFormat());
            //Lista de Classes
            e.Graphics.DrawString(cboClasse.Text, new Font(FontFamily.GenericSansSerif, 18f, FontStyle.Underline),
                                                        new SolidBrush(Color.Black),350f ,120f , new StringFormat());
           
            //Itera Sobre a string usando StringReader, imprimindo cada linha
            for(int i=0;i<lstAlunosPorClasse.Items.Count;i++)
            {
                //Calcula a posicao da proxima linha baseada
                //na altura da fonte de acordo com o dispositivo  de impressao
                yPosicao = margemSuperior + ((i + 3) * fonteImpressao.GetHeight(e.Graphics));

                //Lista os Alunos na Pagina
                e.Graphics.DrawString(lstAlunosPorClasse.Items[i].Text, fonteImpressao, caneta, 50f, yPosicao, new StringFormat());
            }
            caneta.Dispose();
        }

    }
}



