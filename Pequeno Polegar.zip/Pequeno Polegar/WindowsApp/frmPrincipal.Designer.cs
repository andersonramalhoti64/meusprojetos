﻿namespace WindowsApp
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mnuAluno = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnNovo = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnInformacoes = new System.Windows.Forms.Panel();
            this.btnEditarSalvar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.tabInformacoes = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtTelefoneMae = new System.Windows.Forms.MaskedTextBox();
            this.txtTelefonePai = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMae = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPai = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtEndereco = new System.Windows.Forms.TextBox();
            this.dtNascimento = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.cboClasse = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.picFotoAtual = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dtDesligamento = new System.Windows.Forms.MaskedTextBox();
            this.txtObservacoes = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dtMatricula = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.txtPesquisar = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnImprimirTurmas = new System.Windows.Forms.Button();
            this.lstAlunos = new System.Windows.Forms.ListView();
            this.clNome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.mnuAluno.SuspendLayout();
            this.pnInformacoes.SuspendLayout();
            this.tabInformacoes.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFotoAtual)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuAluno
            // 
            this.mnuAluno.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editarToolStripMenuItem,
            this.excluirToolStripMenuItem});
            this.mnuAluno.Name = "mnuAluno";
            this.mnuAluno.Size = new System.Drawing.Size(153, 70);
            this.mnuAluno.Opening += new System.ComponentModel.CancelEventHandler(this.mnuAluno_Opening);
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.editarToolStripMenuItem.Text = "Editar";
            this.editarToolStripMenuItem.Click += new System.EventHandler(this.editarToolStripMenuItem_Click);
            // 
            // excluirToolStripMenuItem
            // 
            this.excluirToolStripMenuItem.Name = "excluirToolStripMenuItem";
            this.excluirToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.excluirToolStripMenuItem.Text = "Excluir";
            this.excluirToolStripMenuItem.Click += new System.EventHandler(this.excluirToolStripMenuItem_Click);
            // 
            // btnNovo
            // 
            this.btnNovo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNovo.Location = new System.Drawing.Point(144, 23);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(75, 39);
            this.btnNovo.TabIndex = 1;
            this.btnNovo.Text = "Novo";
            this.btnNovo.UseVisualStyleBackColor = true;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // btnSair
            // 
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSair.Location = new System.Drawing.Point(753, 411);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 39);
            this.btnSair.TabIndex = 2;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(12, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Alunos:";
            // 
            // pnInformacoes
            // 
            this.pnInformacoes.Controls.Add(this.btnEditarSalvar);
            this.pnInformacoes.Controls.Add(this.btnLimpar);
            this.pnInformacoes.Controls.Add(this.btnCancelar);
            this.pnInformacoes.Controls.Add(this.btnSalvar);
            this.pnInformacoes.Controls.Add(this.tabInformacoes);
            this.pnInformacoes.Enabled = false;
            this.pnInformacoes.Location = new System.Drawing.Point(226, 10);
            this.pnInformacoes.Name = "pnInformacoes";
            this.pnInformacoes.Size = new System.Drawing.Size(602, 383);
            this.pnInformacoes.TabIndex = 4;
            // 
            // btnEditarSalvar
            // 
            this.btnEditarSalvar.Location = new System.Drawing.Point(7, 315);
            this.btnEditarSalvar.Name = "btnEditarSalvar";
            this.btnEditarSalvar.Size = new System.Drawing.Size(93, 49);
            this.btnEditarSalvar.TabIndex = 8;
            this.btnEditarSalvar.Text = "Salvar";
            this.btnEditarSalvar.UseVisualStyleBackColor = true;
            this.btnEditarSalvar.Visible = false;
            this.btnEditarSalvar.Click += new System.EventHandler(this.btnEditarSalvar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(396, 315);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(93, 49);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(495, 315);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(93, 49);
            this.btnCancelar.TabIndex = 6;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(297, 315);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(93, 49);
            this.btnSalvar.TabIndex = 5;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // tabInformacoes
            // 
            this.tabInformacoes.Controls.Add(this.tabPage1);
            this.tabInformacoes.Controls.Add(this.tabPage2);
            this.tabInformacoes.Location = new System.Drawing.Point(3, 18);
            this.tabInformacoes.Name = "tabInformacoes";
            this.tabInformacoes.SelectedIndex = 0;
            this.tabInformacoes.Size = new System.Drawing.Size(589, 278);
            this.tabInformacoes.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txtTelefoneMae);
            this.tabPage1.Controls.Add(this.txtTelefonePai);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtMae);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtPai);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtEndereco);
            this.tabPage1.Controls.Add(this.dtNascimento);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.cboClasse);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtNome);
            this.tabPage1.Controls.Add(this.picFotoAtual);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(581, 252);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Informações Pessoais";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtTelefoneMae
            // 
            this.txtTelefoneMae.Location = new System.Drawing.Point(413, 200);
            this.txtTelefoneMae.Mask = "(99) 00000-0000";
            this.txtTelefoneMae.Name = "txtTelefoneMae";
            this.txtTelefoneMae.Size = new System.Drawing.Size(151, 20);
            this.txtTelefoneMae.TabIndex = 17;
            // 
            // txtTelefonePai
            // 
            this.txtTelefonePai.Location = new System.Drawing.Point(413, 170);
            this.txtTelefonePai.Mask = "(99) 00000-0000";
            this.txtTelefonePai.Name = "txtTelefonePai";
            this.txtTelefonePai.Size = new System.Drawing.Size(151, 20);
            this.txtTelefonePai.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(321, 203);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Telefone da Mãe:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(321, 170);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Telefone do Pai:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Mãe:";
            // 
            // txtMae
            // 
            this.txtMae.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMae.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMae.Location = new System.Drawing.Point(38, 201);
            this.txtMae.Name = "txtMae";
            this.txtMae.Size = new System.Drawing.Size(263, 20);
            this.txtMae.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Pai:";
            // 
            // txtPai
            // 
            this.txtPai.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPai.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPai.Location = new System.Drawing.Point(38, 168);
            this.txtPai.Name = "txtPai";
            this.txtPai.Size = new System.Drawing.Size(263, 20);
            this.txtPai.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(128, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Endereço:";
            // 
            // txtEndereco
            // 
            this.txtEndereco.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEndereco.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEndereco.Location = new System.Drawing.Point(190, 86);
            this.txtEndereco.Multiline = true;
            this.txtEndereco.Name = "txtEndereco";
            this.txtEndereco.Size = new System.Drawing.Size(374, 50);
            this.txtEndereco.TabIndex = 4;
            // 
            // dtNascimento
            // 
            this.dtNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNascimento.Location = new System.Drawing.Point(200, 142);
            this.dtNascimento.Name = "dtNascimento";
            this.dtNascimento.Size = new System.Drawing.Size(101, 20);
            this.dtNascimento.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(128, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Nascimento:";
            // 
            // cboClasse
            // 
            this.cboClasse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboClasse.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cboClasse.FormattingEnabled = true;
            this.cboClasse.Location = new System.Drawing.Point(277, 19);
            this.cboClasse.Name = "cboClasse";
            this.cboClasse.Size = new System.Drawing.Size(121, 21);
            this.cboClasse.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(128, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Nome:";
            // 
            // txtNome
            // 
            this.txtNome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNome.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNome.Location = new System.Drawing.Point(172, 60);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(392, 20);
            this.txtNome.TabIndex = 2;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // picFotoAtual
            // 
            this.picFotoAtual.BackColor = System.Drawing.Color.Transparent;
            this.picFotoAtual.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picFotoAtual.Location = new System.Drawing.Point(4, 7);
            this.picFotoAtual.Name = "picFotoAtual";
            this.picFotoAtual.Size = new System.Drawing.Size(110, 135);
            this.picFotoAtual.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFotoAtual.TabIndex = 0;
            this.picFotoAtual.TabStop = false;
            this.picFotoAtual.Click += new System.EventHandler(this.picFotoAtual_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dtDesligamento);
            this.tabPage2.Controls.Add(this.txtObservacoes);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.dtMatricula);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(581, 252);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Outras Informações";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dtDesligamento
            // 
            this.dtDesligamento.Location = new System.Drawing.Point(137, 40);
            this.dtDesligamento.Mask = "00/00/0000";
            this.dtDesligamento.Name = "dtDesligamento";
            this.dtDesligamento.Size = new System.Drawing.Size(133, 20);
            this.dtDesligamento.TabIndex = 6;
            this.dtDesligamento.ValidatingType = typeof(System.DateTime);
            // 
            // txtObservacoes
            // 
            this.txtObservacoes.Location = new System.Drawing.Point(137, 79);
            this.txtObservacoes.Multiline = true;
            this.txtObservacoes.Name = "txtObservacoes";
            this.txtObservacoes.Size = new System.Drawing.Size(315, 136);
            this.txtObservacoes.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(48, 82);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Observações:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Data de Desligamento:";
            // 
            // dtMatricula
            // 
            this.dtMatricula.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtMatricula.Location = new System.Drawing.Point(137, 13);
            this.dtMatricula.Name = "dtMatricula";
            this.dtMatricula.Size = new System.Drawing.Size(133, 20);
            this.dtMatricula.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(37, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Data de Matricula:";
            // 
            // txtPesquisar
            // 
            this.txtPesquisar.ForeColor = System.Drawing.Color.Gray;
            this.txtPesquisar.Location = new System.Drawing.Point(75, 424);
            this.txtPesquisar.Name = "txtPesquisar";
            this.txtPesquisar.Size = new System.Drawing.Size(232, 20);
            this.txtPesquisar.TabIndex = 5;
            this.txtPesquisar.Text = "Digite o nome do Aluno";
            this.txtPesquisar.TextChanged += new System.EventHandler(this.txtPesquisar_TextChanged);
            this.txtPesquisar.Enter += new System.EventHandler(this.txtPesquisar_Enter);
            this.txtPesquisar.Leave += new System.EventHandler(this.txtPesquisar_Leave);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 427);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Pesquisar:";
            // 
            // btnImprimirTurmas
            // 
            this.btnImprimirTurmas.Location = new System.Drawing.Point(640, 411);
            this.btnImprimirTurmas.Name = "btnImprimirTurmas";
            this.btnImprimirTurmas.Size = new System.Drawing.Size(93, 39);
            this.btnImprimirTurmas.TabIndex = 7;
            this.btnImprimirTurmas.Text = "Imprimir Turmas";
            this.btnImprimirTurmas.UseVisualStyleBackColor = true;
            this.btnImprimirTurmas.Click += new System.EventHandler(this.btnImprimirTurmas_Click);
            // 
            // lstAlunos
            // 
            this.lstAlunos.AllowColumnReorder = true;
            this.lstAlunos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clNome});
            this.lstAlunos.ContextMenuStrip = this.mnuAluno;
            this.lstAlunos.FullRowSelect = true;
            this.lstAlunos.GridLines = true;
            this.lstAlunos.Location = new System.Drawing.Point(16, 69);
            this.lstAlunos.Name = "lstAlunos";
            this.lstAlunos.Size = new System.Drawing.Size(203, 324);
            this.lstAlunos.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.lstAlunos.TabIndex = 8;
            this.lstAlunos.UseCompatibleStateImageBehavior = false;
            this.lstAlunos.View = System.Windows.Forms.View.Details;
            this.lstAlunos.SelectedIndexChanged += new System.EventHandler(this.lstAlunos_SelectedIndexChanged);
            // 
            // clNome
            // 
            this.clNome.Text = "Nome";
            this.clNome.Width = 195;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 461);
            this.Controls.Add(this.lstAlunos);
            this.Controls.Add(this.btnImprimirTurmas);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtPesquisar);
            this.Controls.Add(this.pnInformacoes);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnNovo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "frmPrincipal";
            this.ShowIcon = false;
            this.Text = "Nrei Pequeno Polegar - Sistema de Cadastro de Alunos";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmPrincipal_KeyDown);
            this.mnuAluno.ResumeLayout(false);
            this.pnInformacoes.ResumeLayout(false);
            this.tabInformacoes.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFotoAtual)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip mnuAluno;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excluirToolStripMenuItem;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnInformacoes;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.TabControl tabInformacoes;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMae;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPai;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtEndereco;
        private System.Windows.Forms.DateTimePicker dtNascimento;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboClasse;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.PictureBox picFotoAtual;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtObservacoes;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtMatricula;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox txtTelefoneMae;
        private System.Windows.Forms.MaskedTextBox txtTelefonePai;
        private System.Windows.Forms.MaskedTextBox dtDesligamento;
        private System.Windows.Forms.TextBox txtPesquisar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnImprimirTurmas;
        private System.Windows.Forms.ListView lstAlunos;
        private System.Windows.Forms.ColumnHeader clNome;
        private System.Windows.Forms.Button btnEditarSalvar;
    }
}

