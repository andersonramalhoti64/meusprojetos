﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Modelos;
using CamadaAcessoDados;

namespace CamadaNegocio
{
    public class ClasseNegocio
    {
        public DataTable ListarClasses()
        {
            ClasseDados classe = new ClasseDados();

            return classe.ListarClasses();

        }
    }
}
