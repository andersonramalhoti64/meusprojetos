﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Modelos;
using System.Data;
using CamadaAcessoDados;
using System.Data.SqlClient;

namespace CamadaNegocio
{
    public class AlunoNegocio
    {
        public DataTable Lista_Alunos() 
        {
            AlunoDados aluno = new AlunoDados();

            return aluno.Lista_Alunos();
        }

        public int Contar_Alunos() 
        {
            AlunoDados aluno = new AlunoDados();

            return aluno.Contar_Alunos();
        }

        public bool Novo_Aluno(Aluno aluno) 
        {
            AlunoDados alunoDados = new AlunoDados();

            return alunoDados.Novo_Aluno(aluno);
        }
        public SqlDataReader Ler_Aluno(string nome, Aluno aluno) 
        {
            return new AlunoDados().Ler_Aluno(nome, aluno);
        }
        public bool Excluir_Aluno(string nome) 
        {
            AlunoDados aluno = new AlunoDados();
            return aluno.Excluir_Aluno(nome);
        }
        public List<string> Listar_Alunos() 
        {
            return new AlunoDados().Listar_Alunos();
        }
        public List<Aluno> Listar_Alunos_Por_Classe(int codigo_classe)
        {
            return new AlunoDados().Listar_Alunos_Por_Classe(codigo_classe);
        }
        public bool Atualizar_Aluno(Aluno aluno, string nome)
        {
            return new AlunoDados().Atualizar_Aluno(aluno,nome);
        }
    }
}
