﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modelos
{
	public class Aluno
	{
        public int codigo{ get; set; }
        public int codigo_classe { get; set; }
        public string nome { get; set; }
        public string foto_crianca { get; set; }
        public DateTime nascimento { get; set; }
        public DateTime matricula { get; set; }
        public string desligamento { get; set; }
        public string endereco { get; set; }
        public string pai { get; set; }
        public string mae { get; set; }
        public string telefone_pai { get; set; }
        public string telefone_mae { get; set; }
        public string observacoes { get; set; }
	}
}
