﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modelos
{
    public class Classe
    {

        public int codigo { get; set; }
        public int nome { get; set; }
    }
}
