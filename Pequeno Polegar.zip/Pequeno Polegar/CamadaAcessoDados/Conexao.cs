﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CamadaAcessoDados
{
    public class Conexao
    {
        public static string stringConexao() 
        {
            return @"Server=.\SQLEXPRESS;DATABASE=ESCOLA;INTEGRATED SECURITY=TRUE";
        }
    }
}
