﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CamadaAcessoDados
{
    public class ClasseDados
    {
       private SqlConnection cnn;
       private SqlDataAdapter da;

       public DataTable ListarClasses() 
       {
           DataTable dt = new DataTable();
           cnn = new SqlConnection(Conexao.stringConexao());
           da = new SqlDataAdapter("LISTAR_CLASSES", cnn);
           da.Fill(dt);

           return dt;
       }
    }
}
