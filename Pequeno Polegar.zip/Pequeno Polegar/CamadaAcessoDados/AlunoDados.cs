﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Modelos;
using System.Data;
using System.Data.SqlClient;

namespace CamadaAcessoDados
{
    public class AlunoDados
    {
        private SqlConnection conexao;
        private SqlCommand comando_alunos;

        public DataTable Lista_Alunos() 
        {
            conexao = new SqlConnection(Conexao.stringConexao());
            
            DataTable lista_alunos = new DataTable();
            SqlDataAdapter adapter_alunos = new SqlDataAdapter("LISTAR_ALUNOS", conexao);
            adapter_alunos.Fill(lista_alunos);

            return lista_alunos;
        }

        public int Contar_Alunos()
        {
            int quantidade = 0;
            conexao = new SqlConnection(Conexao.stringConexao());
            
            comando_alunos = new SqlCommand();
            comando_alunos.Connection = conexao;
            
            conexao.Open();
            comando_alunos.CommandText = "CONTAR_ALUNOS";

            quantidade = (int)comando_alunos.ExecuteScalar();

            conexao.Close();
            conexao.Dispose();

            return quantidade;
        }

        public bool Novo_Aluno(Aluno aluno)
        {
            bool executou = false;
            conexao = new SqlConnection(Conexao.stringConexao());
            comando_alunos = new SqlCommand("NOVO_ALUNO", conexao);
            comando_alunos.CommandType = CommandType.StoredProcedure;
            
            comando_alunos.Parameters.AddWithValue("@Codigo_Classe", aluno.codigo_classe);
            comando_alunos.Parameters.AddWithValue("@Nome",aluno.nome);
            comando_alunos.Parameters.AddWithValue("@Foto_Crianca",aluno.foto_crianca);
            comando_alunos.Parameters.AddWithValue("@DataNascimento",aluno.nascimento);
            comando_alunos.Parameters.AddWithValue("@DataMatricula",aluno.matricula);
            comando_alunos.Parameters.AddWithValue("@DataDesligamento",aluno.desligamento);
            comando_alunos.Parameters.AddWithValue("@Endereco",aluno.endereco);
            comando_alunos.Parameters.AddWithValue("@Pai",aluno.pai);
            comando_alunos.Parameters.AddWithValue("@Mae",aluno.mae);
            comando_alunos.Parameters.AddWithValue("@Telefone_Pai",aluno.telefone_pai);
            comando_alunos.Parameters.AddWithValue("@Telefone_Mae",aluno.telefone_mae);
            comando_alunos.Parameters.AddWithValue("@Observacoes_Aluno",aluno.observacoes);

            try
            {

                conexao.Open();
                comando_alunos.ExecuteNonQuery();
                executou = true;
            }
            catch (SqlException s)
            {
                throw s;
                
            }
            finally 
            {
                conexao.Close();

                
            }

            return executou;
        }

        public SqlDataReader Ler_Aluno(string nomePesquisa, Aluno aluno) 
        {
            SqlDataReader reader_alunos = null;
            conexao = new SqlConnection(Conexao.stringConexao());
            comando_alunos = new SqlCommand("LER_ALUNO", conexao);
            comando_alunos.CommandType = CommandType.StoredProcedure;
            comando_alunos.Parameters.AddWithValue("@Nome", nomePesquisa);

            try
            {
                conexao.Open();
                reader_alunos = comando_alunos.ExecuteReader();

                while (reader_alunos.Read()) 
                {
                    aluno.codigo_classe = int.Parse(reader_alunos["CODIGO_CLASSE"].ToString());
                    aluno.nome = reader_alunos["NOME"].ToString();
                    aluno.foto_crianca = reader_alunos["FOTO_CRIANCA"].ToString();
                    aluno.nascimento = DateTime.Parse(reader_alunos["DATANASCIMENTO"].ToString());
                    aluno.matricula = DateTime.Parse(reader_alunos["DATAMATRICULA"].ToString());
                    aluno.desligamento = reader_alunos["DATADESLIGAMENTO"].ToString();
                    aluno.endereco = reader_alunos["ENDERECO"].ToString();
                    aluno.pai = reader_alunos["PAI"].ToString();
                    aluno.telefone_pai = reader_alunos["TELEFONE_PAI"].ToString();
                    aluno.mae = reader_alunos["MAE"].ToString();
                    aluno.telefone_mae = reader_alunos["TELEFONE_MAE"].ToString();
                    aluno.observacoes = reader_alunos["OBSERVACOES_ALUNO"].ToString();
                }

            }
            catch (Exception ex)
            {
              throw ex;
            }
            finally
            {
                conexao.Close();
            }
            return reader_alunos;
        }

        public bool Excluir_Aluno(string nome) 
        {
            bool executou = false;
            conexao = new SqlConnection(Conexao.stringConexao());
            comando_alunos = new SqlCommand("EXCLUIR_ALUNO", conexao);
            comando_alunos.CommandType = CommandType.StoredProcedure;
            comando_alunos.Parameters.AddWithValue("@NOME", nome);

            try
            {
                conexao.Open();
                comando_alunos.ExecuteNonQuery();
                executou = true;
            }
            catch(Exception ex)
            { 
                throw ex;
            }
            finally
            {
                conexao.Close();
                conexao.Dispose();
            }

            return executou;
        }

        public List<string> Listar_Alunos()
        {
            List<string> alunos = new List<string>(); ;

            using (conexao = new SqlConnection(Conexao.stringConexao()))
            {
                conexao.Open();
                comando_alunos = new SqlCommand("PREENCHER_LISTA", conexao);
                comando_alunos.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = comando_alunos.ExecuteReader();
                while (dr.Read())
                {
                    alunos.Add(dr[0].ToString());
                }
            }
            return alunos;
        }

        public List<Aluno> Listar_Alunos_Por_Classe(int codigo_classe)
        {
            List<Aluno> alunosPorClasse = new List<Aluno>();
            Aluno aluno;
            using (conexao = new SqlConnection(Conexao.stringConexao()))
            {
                comando_alunos = new SqlCommand();
                comando_alunos.Connection = conexao;
                comando_alunos.CommandType = CommandType.StoredProcedure;
                comando_alunos.CommandText = "LISTAR_ALUNOS_POR_CLASSE";
                comando_alunos.Parameters.AddWithValue("@CODIGO_CLASSE",codigo_classe);
                conexao.Open();
                SqlDataReader dr = comando_alunos.ExecuteReader();
                while (dr.Read())
                {
                    aluno = new Aluno();
                    aluno.nome = dr["NOME"].ToString();
                    aluno.nascimento = DateTime.Parse(dr["DataNascimento"].ToString());
                    alunosPorClasse.Add(aluno);
                }
            }
            return alunosPorClasse;
        }

        public bool Atualizar_Aluno(Aluno aluno, string nome)
        {
            bool executou = false;
            conexao = new SqlConnection(Conexao.stringConexao());
            comando_alunos = new SqlCommand("ATUALIZAR_ALUNO", conexao);
            comando_alunos.CommandType = CommandType.StoredProcedure;

            comando_alunos.Parameters.AddWithValue("@Nome_Pesquisa",nome);
            comando_alunos.Parameters.AddWithValue("@Codigo_Classe", aluno.codigo_classe);
            comando_alunos.Parameters.AddWithValue("@Nome", aluno.nome);
            comando_alunos.Parameters.AddWithValue("@Foto_Crianca", aluno.foto_crianca);
            comando_alunos.Parameters.AddWithValue("@DataNascimento", aluno.nascimento);
            comando_alunos.Parameters.AddWithValue("@DataMatricula", aluno.matricula);
            comando_alunos.Parameters.AddWithValue("@DataDesligamento", aluno.desligamento);
            comando_alunos.Parameters.AddWithValue("@Endereco", aluno.endereco);
            comando_alunos.Parameters.AddWithValue("@Pai", aluno.pai);
            comando_alunos.Parameters.AddWithValue("@Mae", aluno.mae);
            comando_alunos.Parameters.AddWithValue("@Telefone_Pai", aluno.telefone_pai);
            comando_alunos.Parameters.AddWithValue("@Telefone_Mae", aluno.telefone_mae);
            comando_alunos.Parameters.AddWithValue("@Observacoes_Aluno", aluno.observacoes);

            try
            {

                conexao.Open();
                comando_alunos.ExecuteNonQuery();
                executou = true;
            }
            catch (SqlException s)
            {
                throw s;

            }
            finally
            {
                conexao.Close();


            }

            return executou;
        }
    }
}
